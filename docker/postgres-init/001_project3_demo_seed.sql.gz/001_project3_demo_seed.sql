--
-- PostgreSQL database dump
--

\restrict ayGTck4BQzry0ebazzhyHNLBf72I6mLpdeISi1rwHfroxBXefoPubPwnzB8rys6

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app_security; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA app_security;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: can_read_catalog_entry(uuid); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.can_read_catalog_entry(candidate_entry_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT EXISTS (
        SELECT 1
        FROM catalog_entries ce
        JOIN source_catalog sc ON sc.source_id = ce.source_id
        WHERE ce.entry_id = candidate_entry_id
          AND ce.is_active
          AND sc.is_active
          AND app_security.can_read_scope(ce.permission_scope_key)
    )
$$;


--
-- Name: can_read_document_chunk(uuid); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.can_read_document_chunk(candidate_chunk_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT EXISTS (
        SELECT 1
        FROM document_chunks dc
        WHERE dc.chunk_id = candidate_chunk_id
          AND dc.is_active
          AND app_security.can_read_catalog_entry(dc.catalog_entry_id)
          AND app_security.can_read_scope(dc.permission_scope_key)
    )
$$;


--
-- Name: can_read_resource_key(text); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.can_read_resource_key(candidate_resource_key text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT candidate_resource_key = ANY(app_security.current_permission_resource_keys())
$$;


--
-- Name: can_read_scope(text); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.can_read_scope(scope_key text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT scope_key = ANY(app_security.current_permission_scope_keys())
$$;


--
-- Name: can_read_structured_resource(uuid); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.can_read_structured_resource(candidate_resource_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT EXISTS (
        SELECT 1
        FROM structured_resources sr
        WHERE sr.resource_id = candidate_resource_id
          AND sr.is_active
          AND (
            app_security.can_read_scope(sr.permission_scope_key)
            OR app_security.can_read_resource_key(sr.resource_key)
            OR EXISTS (
                SELECT 1
                FROM structured_resource_scope_map sm
                WHERE sm.resource_id = sr.resource_id
                  AND app_security.can_read_scope(sm.permission_scope_key)
            )
          )
    )
$$;


--
-- Name: current_permission_resource_keys(); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.current_permission_resource_keys() RETURNS text[]
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT CASE
        WHEN nullif(current_setting('app.permission_resource_keys', true), '') IS NULL THEN ARRAY[]::text[]
        ELSE string_to_array(current_setting('app.permission_resource_keys', true), ',')
    END
$$;


--
-- Name: current_permission_scope_keys(); Type: FUNCTION; Schema: app_security; Owner: -
--

CREATE FUNCTION app_security.current_permission_scope_keys() RETURNS text[]
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'app_security'
    AS $$
    SELECT CASE
        WHEN nullif(current_setting('app.permission_scope_keys', true), '') IS NULL THEN ARRAY[]::text[]
        ELSE string_to_array(current_setting('app.permission_scope_keys', true), ',')
    END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_groups (
    group_key text NOT NULL,
    display_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_user_groups (
    user_key text NOT NULL,
    group_key text NOT NULL
);


--
-- Name: app_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_users (
    user_key text NOT NULL,
    email text NOT NULL,
    display_name text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approved_join_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approved_join_relationships (
    join_id uuid DEFAULT gen_random_uuid() NOT NULL,
    left_resource_id uuid NOT NULL,
    left_column_id uuid NOT NULL,
    right_resource_id uuid NOT NULL,
    right_column_id uuid NOT NULL,
    join_type text DEFAULT 'inner'::text NOT NULL,
    validation_status text DEFAULT 'approved'::text NOT NULL,
    confidence text NOT NULL,
    validation_source text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id text,
    event_type text NOT NULL,
    actor_user_key text,
    status text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: catalog_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.catalog_entries (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id uuid NOT NULL,
    entry_type text NOT NULL,
    title text NOT NULL,
    safe_path text,
    permission_scope_key text NOT NULL,
    active_dataset_id text,
    source_catalog_version text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_chunks (
    chunk_id uuid DEFAULT gen_random_uuid() NOT NULL,
    catalog_entry_id uuid NOT NULL,
    chunk_index integer NOT NULL,
    chunk_text text NOT NULL,
    citation jsonb DEFAULT '{}'::jsonb NOT NULL,
    permission_scope_key text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permission_scopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_scopes (
    scope_key text NOT NULL,
    display_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rag_chunk_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_chunk_embeddings (
    embedding_id uuid DEFAULT gen_random_uuid() NOT NULL,
    chunk_id uuid NOT NULL,
    embedding public.vector,
    embedding_model text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version text NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: source_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_catalog (
    source_id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_type text NOT NULL,
    source_uri text NOT NULL,
    display_name text NOT NULL,
    permission_scope_key text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: structured_file_server_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_categories (
    permission_scope_key text NOT NULL,
    categoryid bigint,
    categoryname text,
    description text
);


--
-- Name: structured_file_server_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_customers (
    permission_scope_key text NOT NULL,
    customerid text,
    companyname text,
    contactname text,
    contacttitle text,
    city text,
    country text
);


--
-- Name: structured_file_server_order_details_2017; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_order_details_2017 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    productid bigint,
    orderprice numeric,
    quantity bigint,
    discount numeric
);


--
-- Name: structured_file_server_order_details_2018; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_order_details_2018 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    productid bigint,
    orderprice numeric,
    quantity bigint,
    discount numeric
);


--
-- Name: structured_file_server_order_details_2019; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_order_details_2019 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    productid bigint,
    orderprice numeric,
    quantity bigint,
    discount numeric
);


--
-- Name: structured_file_server_order_details_2020; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_order_details_2020 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    productid bigint,
    orderprice numeric,
    quantity bigint,
    discount numeric
);


--
-- Name: structured_file_server_order_details_2021; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_order_details_2021 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    productid bigint,
    orderprice numeric,
    quantity bigint,
    discount numeric
);


--
-- Name: structured_file_server_orders_2017; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_orders_2017 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    customerid text,
    employeeid bigint,
    orderdate text,
    requireddate text,
    shippeddate text,
    shipperid bigint,
    freight numeric
);


--
-- Name: structured_file_server_orders_2018; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_orders_2018 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    customerid text,
    employeeid bigint,
    orderdate text,
    requireddate text,
    shippeddate text,
    shipperid bigint,
    freight numeric
);


--
-- Name: structured_file_server_orders_2019; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_orders_2019 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    customerid text,
    employeeid bigint,
    orderdate text,
    requireddate text,
    shippeddate text,
    shipperid bigint,
    freight numeric
);


--
-- Name: structured_file_server_orders_2020; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_orders_2020 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    customerid text,
    employeeid bigint,
    orderdate text,
    requireddate text,
    shippeddate text,
    shipperid bigint,
    freight numeric
);


--
-- Name: structured_file_server_orders_2021; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_orders_2021 (
    permission_scope_key text NOT NULL,
    orderid bigint,
    customerid text,
    employeeid bigint,
    orderdate text,
    requireddate text,
    shippeddate text,
    shipperid bigint,
    freight numeric
);


--
-- Name: structured_file_server_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_products (
    permission_scope_key text NOT NULL,
    productid bigint,
    productname text,
    quantityperunit text,
    currentprice numeric,
    discontinued bigint,
    categoryid bigint
);


--
-- Name: structured_file_server_shippers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_file_server_shippers (
    permission_scope_key text NOT NULL,
    shipperid bigint,
    companyname text
);


--
-- Name: structured_finance_company_expense_sheet1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_finance_company_expense_sheet1 (
    permission_scope_key text NOT NULL,
    transaction_id bigint,
    date text,
    account text,
    type text,
    category text,
    description_merchant text,
    amount numeric,
    payment_method text,
    is_recurring text
);


--
-- Name: structured_finance_company_revenue_sheet1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_finance_company_revenue_sheet1 (
    permission_scope_key text NOT NULL,
    transaction_id bigint,
    date text,
    description_merchant text,
    amount numeric
);


--
-- Name: structured_hr_employee_hr_records_sheet1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_hr_employee_hr_records_sheet1 (
    permission_scope_key text NOT NULL,
    employee_id bigint,
    full_name text,
    gender text,
    department text,
    job_title text,
    city text,
    country text,
    reportsto bigint,
    hire_date text,
    annual_salary bigint,
    performance_rating numeric,
    satisfaction_score numeric,
    employment_status text
);


--
-- Name: structured_resource_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_resource_columns (
    column_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_id uuid NOT NULL,
    column_name text NOT NULL,
    data_type text NOT NULL,
    safe_description text,
    ordinal_position integer NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: structured_resource_scope_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_resource_scope_map (
    resource_id uuid NOT NULL,
    permission_scope_key text NOT NULL
);


--
-- Name: structured_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structured_resources (
    resource_id uuid DEFAULT gen_random_uuid() NOT NULL,
    catalog_entry_id uuid,
    resource_key text NOT NULL,
    runtime_relation_name text NOT NULL,
    display_name text NOT NULL,
    permission_scope_key text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: app_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_groups (group_key, display_name, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: app_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_user_groups (user_key, group_key) FROM stdin;
\.


--
-- Data for Name: app_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_users (user_key, email, display_name, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: approved_join_relationships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approved_join_relationships (join_id, left_resource_id, left_column_id, right_resource_id, right_column_id, join_type, validation_status, confidence, validation_source, metadata, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: catalog_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.catalog_entries (entry_id, source_id, entry_type, title, safe_path, permission_scope_key, active_dataset_id, source_catalog_version, metadata, is_active, created_at) FROM stdin;
f4079ae9-e270-480b-82db-2c3e0fe74128	6e30b4b1-3cec-4e83-bbb4-ef5602bc9dba	rag_document	Northwind_Code_of_Conduct	Employee Guidelines/Northwind_Code_of_Conduct.pdf	employee_guidelines	active	active	{}	t	2026-07-20 17:59:16.167083+00
b7380168-7178-4afb-b733-fa0cd8d3b654	5230ceb3-111b-4e74-84e7-aed6a2247134	rag_document	Northwind_Leave_and_PTO_Policy	Employee Guidelines/Northwind_Leave_and_PTO_Policy.pdf	employee_guidelines	active	active	{}	t	2026-07-20 17:59:16.167083+00
eb600b02-94ed-4d37-912c-ad570ae809da	a65f6449-4c54-44f8-b46a-7b5a288a28d6	rag_document	Northwind_Remote_Work_Policy	Employee Guidelines/Northwind_Remote_Work_Policy.pdf	employee_guidelines	active	active	{}	t	2026-07-20 17:59:16.167083+00
09dd7ae3-6a54-4b93-bf08-86720c47eba9	1ef60f5d-524b-4e21-a13b-9199d6462a75	rag_document	Northwind_Travel_and_Expense_Policy	Employee Guidelines/Northwind_Travel_and_Expense_Policy.pdf	employee_guidelines	active	active	{}	t	2026-07-20 17:59:16.167083+00
ba5dfe8f-c4d4-40e3-afe3-5e7c11492a92	c70cbd0b-9c23-43f8-97e2-fb7ae9ec941b	structured_table	categories	File Server/categories.csv	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
7a762c9b-462f-4a97-bbcd-8f36f6982bbf	41bfc0e1-36cf-45fa-b289-aa84fcc60c2f	structured_table	customers	File Server/customers.csv	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
11e8f90a-6452-4d77-9faf-b83db7354305	84fbf46f-6ea2-4bf8-983f-680ea0944357	structured_table	order_details	File Server/order_details.xlsx	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
56cb791f-beea-459b-bbec-8fc06b0d98db	2562ceba-424a-45b3-89eb-f9c44bf2b070	structured_table	orders	File Server/orders.xlsx	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
5bc5a890-222a-4b19-b967-13bfd3ef56b1	5074947b-e994-46f0-aa36-d43b3c271b72	structured_table	products	File Server/products.csv	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
0e6aebe1-9f03-41ac-ac95-340d50e59e09	c4cd6dcd-5651-4ccc-865b-f7335c004f71	structured_table	shippers	File Server/shippers.csv	file_server	active	active	{}	t	2026-07-20 17:59:16.167083+00
bf89f1aa-5a08-4886-8735-adb2d1c53b96	aedb1ff9-fefc-4531-b8d2-8f164eadf9d7	structured_table	Company Expense	Finance/Company Expense.xlsx	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
4b0bed98-c9fb-414f-88db-100824712611	480342b7-558e-4237-b7f0-16cb4b3bd14f	structured_table	Company Revenue	Finance/Company Revenue.xlsx	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
d48278c7-7a94-4226-b546-74fc91207833	00390119-3444-442c-8e00-d664b4b1e56e	rag_document	Invoice_10271	Finance/Invoices (50 Sample only)/Invoice_10271.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
7a021b9f-8b87-4155-aea6-0b17f192cb02	5c8776c9-6eca-434c-9c6f-7b0ffea1b5c1	rag_document	Invoice_10278	Finance/Invoices (50 Sample only)/Invoice_10278.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
1117b320-6644-4f81-9f75-190cb8341ec1	dafc5e83-f1fd-412e-a4f6-b40a1c691320	rag_document	Invoice_10287	Finance/Invoices (50 Sample only)/Invoice_10287.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
d3cf5d00-9beb-4245-a94c-0e65b07ad055	feff9ef7-16fa-4351-8d89-97ceba626eab	rag_document	Invoice_10311	Finance/Invoices (50 Sample only)/Invoice_10311.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
affd5185-d983-45d2-add4-14e732503386	29ea70cf-e319-4492-90d9-f4aaf7ba9150	rag_document	Invoice_10313	Finance/Invoices (50 Sample only)/Invoice_10313.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
a5d8d746-a764-48c8-b68e-0d100a32b56f	e74dd380-74ae-449c-ba7e-1e905cd3aca1	rag_document	Invoice_10314	Finance/Invoices (50 Sample only)/Invoice_10314.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
16f51fb6-1865-49aa-9790-8365a9ee2ae4	401711c4-9403-4e7f-a705-295a000d4df4	rag_document	Invoice_10315	Finance/Invoices (50 Sample only)/Invoice_10315.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
ee98ada8-01ee-423f-bdb6-cec696703cea	245e1f7f-f3e6-433c-b4df-72917f2e461a	rag_document	Invoice_10334	Finance/Invoices (50 Sample only)/Invoice_10334.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
d92117ed-f680-40df-991d-3a3d233c5b98	f57ddc1a-b5b7-43e4-b8b0-618cb51739e9	rag_document	Invoice_10357	Finance/Invoices (50 Sample only)/Invoice_10357.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
e3b7e32b-a293-4dd3-9e92-6120721ec3f8	b3e6e20d-669b-4b5d-abb8-81d7af477532	rag_document	Invoice_10385	Finance/Invoices (50 Sample only)/Invoice_10385.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
a1efa286-6fa0-4e3a-9db3-42c769c524e2	9e85f707-0888-4c61-ad61-a38f9bd8c940	rag_document	Invoice_10387	Finance/Invoices (50 Sample only)/Invoice_10387.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
03e24503-12e6-4333-a0e7-5a052aa1eeb1	5906d7d9-a6b0-4b04-85d1-ce3d9c02883f	rag_document	Invoice_10416	Finance/Invoices (50 Sample only)/Invoice_10416.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
1d0620ff-6d58-48c1-b5e3-aebae6bd8751	c284a707-fab7-444a-8305-1f109beaae17	rag_document	Invoice_10447	Finance/Invoices (50 Sample only)/Invoice_10447.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
aaeb2ad2-db50-4173-8643-fd8bda7010d3	edf70a52-9a45-460a-80a6-b2b87af1c035	rag_document	Invoice_10458	Finance/Invoices (50 Sample only)/Invoice_10458.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
e7272c05-c4cb-4b8c-8396-83f0405348a8	300837bf-6ca0-4820-918a-133383bcf1ca	rag_document	Invoice_10463	Finance/Invoices (50 Sample only)/Invoice_10463.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
2b3df1df-0f45-4937-876a-1bff04402557	6c65c142-8605-4623-9a9a-91cfbb567bae	rag_document	Invoice_10487	Finance/Invoices (50 Sample only)/Invoice_10487.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
34f2c061-18c4-4a83-a381-88812460eb56	336e149a-49bb-425b-b13e-b82f3796cf7a	rag_document	Invoice_10495	Finance/Invoices (50 Sample only)/Invoice_10495.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
04201f58-43a4-422d-8353-b99123e96e99	cbc7b447-f178-4006-9795-c45787c5949b	rag_document	Invoice_10507	Finance/Invoices (50 Sample only)/Invoice_10507.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
b248dd63-c7ae-4623-9526-b659d7a19bc7	4022acdd-df49-47ae-b235-60e3ed4eac2a	rag_document	Invoice_10508	Finance/Invoices (50 Sample only)/Invoice_10508.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
cdfdf250-2c9c-40df-ae33-5e663b705b40	915d2098-fe7d-49df-af25-6ef09c729a95	rag_document	Invoice_10513	Finance/Invoices (50 Sample only)/Invoice_10513.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
c5c7d09d-b497-4ad0-9d03-d8dd897bbcbe	5da81f83-662a-4f9b-9856-d1874e273652	rag_document	Invoice_10538	Finance/Invoices (50 Sample only)/Invoice_10538.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
0fb05cd2-0223-4c69-b937-f6edc5500ebd	fbee56dc-b49b-4fe7-a6da-e2d6ca608022	rag_document	Invoice_10590	Finance/Invoices (50 Sample only)/Invoice_10590.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
55ed7781-ec87-4629-81a2-3f46342d6636	f97283da-815c-4ed6-b9c0-eac4b72ca8d0	rag_document	Invoice_10604	Finance/Invoices (50 Sample only)/Invoice_10604.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
6fd679e9-3502-4ca3-96c1-4d1465169115	c81e8634-ca8c-48b3-816d-67cb1380e7e4	rag_document	Invoice_10616	Finance/Invoices (50 Sample only)/Invoice_10616.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
40182aee-8b9d-4364-8237-f25e441ae9dc	5da00ffb-c155-4122-b6c5-9fac24a36950	rag_document	Invoice_10629	Finance/Invoices (50 Sample only)/Invoice_10629.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
a3d3daaf-129d-4537-ac6c-52e70ee5e585	51088d2c-1257-4f96-ad28-120a9556b2f3	rag_document	Invoice_10631	Finance/Invoices (50 Sample only)/Invoice_10631.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
83d949e5-3d25-4fb6-9bf5-fa356c85238b	bc5f3dc1-efbb-41b3-9a01-1a2baa61f6b1	rag_document	Invoice_10690	Finance/Invoices (50 Sample only)/Invoice_10690.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
29d87006-e87b-4163-85aa-30c82e97a0e6	31fc6cbf-43a5-4f29-90e9-97535322f30e	rag_document	Invoice_10699	Finance/Invoices (50 Sample only)/Invoice_10699.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
77b1bbf2-a1cb-4b1d-bb43-6810ca513e39	c94699f4-b3e7-4403-ac6f-b7fcd752f30f	rag_document	Invoice_10705	Finance/Invoices (50 Sample only)/Invoice_10705.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
b6d97e88-f0c5-438e-98fd-b7f5cb0ce2cd	a791f729-ab44-4457-88d2-e0f2f08e1a88	rag_document	Invoice_10729	Finance/Invoices (50 Sample only)/Invoice_10729.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
9a1600bc-0e1b-4817-ba82-5d3c3d58c4ef	7d35b118-bf0a-467d-a5d0-3f38ae1c7fd5	rag_document	Invoice_10733	Finance/Invoices (50 Sample only)/Invoice_10733.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
712ac996-c530-4570-a009-17d002c625a4	97ae01cd-20f7-437a-b1c5-a17edfd20a56	rag_document	Invoice_10760	Finance/Invoices (50 Sample only)/Invoice_10760.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
7f69c9f1-1ab7-4e60-ba15-44f283ec16bd	ecc53eea-5dda-4a7b-8278-035b376396c9	rag_document	Invoice_10782	Finance/Invoices (50 Sample only)/Invoice_10782.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
02a773fd-8db9-424f-877c-8f903dadc101	fac22f2b-3ee4-4460-bf74-921fbf24dc80	rag_document	Invoice_10792	Finance/Invoices (50 Sample only)/Invoice_10792.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
4f032e6d-f8a7-4cd8-9a86-fe65fa329bc1	4706a85e-0de5-40d2-b12e-9a53ba3a4423	rag_document	Invoice_10799	Finance/Invoices (50 Sample only)/Invoice_10799.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
830919af-59c1-4a89-9e32-f2a3179e06b2	4fd1ec94-2202-484a-9254-4f7b1175468f	rag_document	Invoice_10806	Finance/Invoices (50 Sample only)/Invoice_10806.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
e3ca793e-a237-4d62-b52a-56b5e586f1ed	26954831-6596-4540-8622-87c071a63567	rag_document	Invoice_10856	Finance/Invoices (50 Sample only)/Invoice_10856.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
7eb26406-4985-4e89-9d0b-b840b0408130	d758b3ca-d317-4aa1-b7e3-76077be1d355	rag_document	Invoice_10868	Finance/Invoices (50 Sample only)/Invoice_10868.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
37b8b394-0ad4-4d93-8e35-1cdb72625679	f079d1a1-8dc1-4cc6-a71b-bfd2cf23889e	rag_document	Invoice_10884	Finance/Invoices (50 Sample only)/Invoice_10884.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
2928b393-facd-4c68-a2f7-9b7b59029cd1	e16a97c8-f8e1-4d6a-9b18-96ce5ef44136	rag_document	Invoice_10897	Finance/Invoices (50 Sample only)/Invoice_10897.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
93e08a2f-aeef-4bab-877c-0bd17b735a44	4a0cb2b0-c0be-411e-a281-e01bd8ede6a2	rag_document	Invoice_10930	Finance/Invoices (50 Sample only)/Invoice_10930.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
8451f27e-64f0-4622-9942-ff289af6e63a	ac292aca-f0d3-4c0c-a4d7-ebd1166a8152	rag_document	Invoice_10933	Finance/Invoices (50 Sample only)/Invoice_10933.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
2b97cad6-fe0e-42ff-ac57-128b1f0647aa	4e9b5ad3-6c6b-48b4-b52f-ff35ee653e6c	rag_document	Invoice_10968	Finance/Invoices (50 Sample only)/Invoice_10968.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
7839488a-0302-4cdf-965c-92e3b3b6efa2	4e2e07d3-fcd1-491f-83f4-bf3a1ac848fa	rag_document	Invoice_10999	Finance/Invoices (50 Sample only)/Invoice_10999.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
c3a62960-18b7-493e-9248-dc25d1f82f55	ddade437-e9e0-4464-b8bf-e521679aa779	rag_document	Invoice_11024	Finance/Invoices (50 Sample only)/Invoice_11024.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
e35358f7-36cd-41f6-8c8f-c239829379b5	633f35a6-1661-404b-9d19-df4494a1664a	rag_document	Invoice_11031	Finance/Invoices (50 Sample only)/Invoice_11031.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
d63e39c5-2b73-4e8a-bae3-529c51963a37	870c74ad-80fc-4f0f-a1a2-01a3cac03ad0	rag_document	Invoice_11039	Finance/Invoices (50 Sample only)/Invoice_11039.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
c8bd35c7-e595-4e1d-a376-6b12755a5623	bcefd9e7-e9f6-4983-884a-d74dce73d4c7	rag_document	Invoice_11059	Finance/Invoices (50 Sample only)/Invoice_11059.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
b2272bf8-cf18-4c5f-8ee1-026983b6acc9	4df1b598-e2c8-46f7-a44c-8ddedf97f573	rag_document	Invoice_11064	Finance/Invoices (50 Sample only)/Invoice_11064.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
79da76d2-2d9f-46e2-8ba9-2f42b0b8966d	50a003d4-3dfb-4ade-a980-b7816e2bea8e	rag_document	Invoice_11065	Finance/Invoices (50 Sample only)/Invoice_11065.pdf	finance	active	active	{}	t	2026-07-20 17:59:16.167083+00
d3d1d595-3310-4583-8dc6-c309d4ca9772	1437f433-be2b-4443-8d91-9ee00d400cc4	rag_document	10_Natalie_Gardner_CV	HR/Employee CV/10_Natalie_Gardner_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
8dc042d0-a064-45c5-970c-bc75bad8e678	29e2a0a0-9b43-4347-8eb1-648cd2050006	rag_document	11_Anna_Hall_CV	HR/Employee CV/11_Anna_Hall_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
3674040a-3b27-400a-9bb5-77460501994a	1075c83d-a1b6-4b5d-b2f0-11e2302dbac2	rag_document	12_Mike_Miles_CV	HR/Employee CV/12_Mike_Miles_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
f1822609-082a-4420-a5f7-839df48e8208	331c39a4-0e8e-4e5b-8982-8889d58be862	rag_document	13_Kevin_Pacheco_CV	HR/Employee CV/13_Kevin_Pacheco_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
e50cc60a-18fc-4de1-8a65-fd8da54acea0	277b30e9-2589-4d29-9d61-2d53058a0c87	rag_document	14_Christopher_Henderson_CV	HR/Employee CV/14_Christopher_Henderson_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
3f1c8eda-a513-47ef-9f28-cac5f0d94763	424c3ab6-5452-4546-be17-329e37b902d2	rag_document	15_Tina_Rogers_CV	HR/Employee CV/15_Tina_Rogers_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
9313719f-8717-4ed9-be20-20ebd2127662	ec4f179d-e45b-4c78-afee-0c6840245b73	rag_document	16_Ian_Cooper_CV	HR/Employee CV/16_Ian_Cooper_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
5764b056-c464-4ee1-a9cc-4f8cd4a2bed7	a05887da-e373-48e3-a7af-094a58abe65d	rag_document	17_Nicholas_Herrera_CV	HR/Employee CV/17_Nicholas_Herrera_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
fbf5e195-2c28-4664-9ec2-a6b765107464	28f8b6c7-e998-4701-af14-11b2a131a37a	rag_document	18_Elaine_Fuller_CV	HR/Employee CV/18_Elaine_Fuller_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
9a0425dc-cd3f-40b2-afe3-6d3ab998a554	30136917-784b-424a-b442-96236fea4e3d	rag_document	19_Michael_Williams_CV	HR/Employee CV/19_Michael_Williams_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
e97ffefa-997b-4ae3-81ee-0086c7199abe	a901d385-2bf8-4a7e-8825-63303a213b40	rag_document	1_Nancy_Davolio_CV	HR/Employee CV/1_Nancy_Davolio_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
319c10dc-1abe-4af7-b58c-b37e7b7a600c	e9a51247-b8ae-4e1b-9eff-d0cc88c7c8a8	rag_document	20_Victoria_Wyatt_CV	HR/Employee CV/20_Victoria_Wyatt_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
9ffe1d3f-9095-4066-a557-577dfa456a19	1ebbe1f2-1690-4cdc-9428-e69fc35c9dfa	rag_document	21_Jody_Flowers_CV	HR/Employee CV/21_Jody_Flowers_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
4f605a56-828f-43b7-a4ae-85177807ef72	35b1aba1-8b1f-442c-8356-29b4d597044c	rag_document	22_Christine_Adams_CV	HR/Employee CV/22_Christine_Adams_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
06578b47-cbea-4bd3-9fb0-38b396896580	dc183fbe-b81d-4fd5-bd75-68d24daf242f	rag_document	23_Christopher_Daniel_CV	HR/Employee CV/23_Christopher_Daniel_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
dcdd9c3f-0d5f-4ad9-ab5f-a7eb047e8a2f	e37defe3-5003-443e-95eb-c71139337a8f	rag_document	24_Devin_Schaefer_CV	HR/Employee CV/24_Devin_Schaefer_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
b0b9a94d-9c55-4658-9348-7a27ef277020	fcdd9140-d16f-4a5f-b8da-991f9d460f6f	rag_document	25_Ryan_Parsons_CV	HR/Employee CV/25_Ryan_Parsons_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
16281bbe-bfd2-491c-a2a8-8efdd8829cf8	6484ed87-e2c0-4bef-ac08-5762f7eef332	rag_document	26_Robert_Morales_CV	HR/Employee CV/26_Robert_Morales_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
ad11edd5-6345-477f-9908-c37ac07cbb3d	10dfd48e-b7e6-4016-92eb-04c0978182ee	rag_document	27_Tommy_Walter_CV	HR/Employee CV/27_Tommy_Walter_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
7996347a-118a-4127-9e1b-ba93ab83b813	eef04cef-c16f-43cb-a975-ce1944eede60	rag_document	28_Jonathan_Wilkerson_CV	HR/Employee CV/28_Jonathan_Wilkerson_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
ec451662-acc7-4822-9969-b08129c3fae0	bd41a5b6-1eaa-42cd-9d82-f05f91be5f9f	rag_document	29_Charles_Mcgee_CV	HR/Employee CV/29_Charles_Mcgee_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
27aa878c-33ef-4c5c-aa17-ba0184efff6b	f2a8d387-d769-4305-9f72-d9aca76257c8	rag_document	2_Andrew_Fuller_CV	HR/Employee CV/2_Andrew_Fuller_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
5cf0959a-7b63-4ee9-a142-62434c438aee	11914569-d2b6-445c-8ad2-962c18a08407	rag_document	30_Jeffrey_Silva_CV	HR/Employee CV/30_Jeffrey_Silva_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
e19942f2-f352-4544-b4ae-9e1947c16499	4dad2870-da59-4236-920f-1ba91a503918	rag_document	31_Yolanda_Hicks_CV	HR/Employee CV/31_Yolanda_Hicks_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
f032ab6e-ccec-428e-a6d0-674e3fe3c19a	83469ea3-fc87-4b96-83cf-0c53bb87324b	rag_document	32_Shannon_Hernandez_CV	HR/Employee CV/32_Shannon_Hernandez_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
880cdd29-0a87-475f-968a-968cf286d2bf	f922fc6f-7493-4b10-9c50-5bc072e6a28b	rag_document	33_Jay_Brown_CV	HR/Employee CV/33_Jay_Brown_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
6c15cc56-6a2d-453c-ba7a-d21aec7dea24	6adeda06-ae81-46b4-8278-19376bba43e2	rag_document	34_John_King_CV	HR/Employee CV/34_John_King_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
e9f1bddc-efd7-4c56-afa2-0aa177798863	6f5d5dcc-1e2f-49a9-b6d0-cdc31e910f67	rag_document	35_Ashley_Dyer_CV	HR/Employee CV/35_Ashley_Dyer_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
35e181cb-0ec9-491d-8409-323434be391d	00ad9024-4972-455f-bf4f-286068fb1b54	rag_document	36_Gerald_Carter_CV	HR/Employee CV/36_Gerald_Carter_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
03b7672b-846a-43df-844a-4eb41affde11	b93c7843-94fa-4879-998a-f44e366407d7	rag_document	37_Troy_Liu_CV	HR/Employee CV/37_Troy_Liu_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
bc09f7b5-2d7a-4ccd-b21f-41a7de505e14	0b53d939-7e88-4966-9120-7d6a4b8975d8	rag_document	38_Dr._Jordan_Rodriguez_CV	HR/Employee CV/38_Dr._Jordan_Rodriguez_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
a1df9635-024e-41a4-b238-b6e4b834a282	64a41e64-abb0-4082-9621-9e02c7e61e5c	rag_document	3_Janet_Leverling_CV	HR/Employee CV/3_Janet_Leverling_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
b4796f86-8e31-49eb-aa71-61cd3bee1991	9eb85e5a-3ba9-443e-9abe-00267ac9fd50	rag_document	4_Margaret_Peacock_CV	HR/Employee CV/4_Margaret_Peacock_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
86584249-f6f8-4eeb-8709-55205725e354	988bbfa6-8b0f-4a28-9dd9-ce6873d51015	rag_document	5_Steven_Buchanan_CV	HR/Employee CV/5_Steven_Buchanan_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
ed2f2a23-0798-4027-bf48-50581ded48ad	052bfccd-d41f-43b2-959d-1f98b41f46f1	rag_document	6_Michael_Suyama_CV	HR/Employee CV/6_Michael_Suyama_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
0924a455-8fc3-408c-9e7a-a09c94126b72	3e5a551e-7459-4a00-a94c-08c5f1abae4e	rag_document	7_Robert_King_CV	HR/Employee CV/7_Robert_King_CV.pdf	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
f4986604-cc96-4258-b093-e94d12e06e5f	648cd122-20cc-4f51-a837-9df5e4728e37	rag_document	8_Laura_Callahan_CV	HR/Employee CV/8_Laura_Callahan_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
c9b53dee-3ffe-4d21-872f-87fc023e4474	148f608a-d745-478a-b8c9-ba938a8c2229	rag_document	9_Anne_Dodsworth_CV	HR/Employee CV/9_Anne_Dodsworth_CV.docx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
c9f40140-6e99-44e6-9a04-4a874489cac3	a9d1de52-30ed-4c40-bd57-8332891090e7	structured_table	Employee HR Records	HR/Employee HR Records.xlsx	hr	active	active	{}	t	2026-07-20 17:59:16.167083+00
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_chunks (chunk_id, catalog_entry_id, chunk_index, chunk_text, citation, permission_scope_key, metadata, is_active, created_at) FROM stdin;
c7d372b4-5b70-44d4-b83e-d6331506afec	f4079ae9-e270-480b-82db-2c3e0fe74128	0	Northwind Traders Code of Conduct 1. Introduction At Northwind Traders, we are committed to conducting our business with honesty, integrity, and respect. This Code of Conduct outlines the ethical standards and expectations for all employees, contractors, and partners. 2. Professionalism and Respect • Inclusivity: We foster an inclusive environment where diversity is celebrated. Discrimination or harassment of any kind based on race, gender, sexual orientation, religion, or age will not be tolerated. • Respectful Communication: All communication, both internal and external, must remain professional and respectful. 3. Conflict of Interest Employees must avoid any relationship, activity, or situation that could conflict with the interests of Northwind Traders. This includes: • Accepting gifts from suppliers exceeding $50 in value. • Engaging in outside employment that interferes with your duties. • Using company resources for personal gain. 4. Confidentiality Employees frequently have access to confidential client data and trade secrets. You must not disclose any proprietary information to external parties without explicit authorization. 5. Compliance Violations of this Code of Conduc	{"safe_location_path": "Employee Guidelines/Northwind_Code_of_Conduct.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
dfe4bc23-db9f-45ce-a608-38d631c9e49d	f4079ae9-e270-480b-82db-2c3e0fe74128	1	t may result in disciplinary action, up to and including termination of employment. Page 1	{"safe_location_path": "Employee Guidelines/Northwind_Code_of_Conduct.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
67c35651-32d8-45ad-8254-4c68d0a3771f	b7380168-7178-4afb-b733-fa0cd8d3b654	0	Northwind Traders Leave and PTO Policy 1. Paid Time Off (PTO) Northwind Traders believes that taking time off is essential for employee health and productivity. • Accrual: Full-time employees accrue 20 days of PTO per calendar year. • Carryover: Employees may carry over a maximum of 5 unused PTO days into the next calendar year. Any additional days will be forfeited. • Requesting PTO: Requests for PTO exceeding 3 consecutive days must be submitted at least two weeks in advance. 2. Sick Leave • Employees are provided with 10 days of paid sick leave per year. • A doctor's note is required for sick leave exceeding 3 consecutive days. 3. Parental Leave • Primary caregivers are eligible for 16 weeks of fully paid parental leave following the birth or adoption of a child. • Secondary caregivers are eligible for 6 weeks of fully paid parental leave. 4. Public Holidays Northwind Traders observes standard national public holidays. If an employee is required to work on a public holiday, they will be granted a day off in lieu. Page 1	{"safe_location_path": "Employee Guidelines/Northwind_Leave_and_PTO_Policy.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
28af7a23-f8c3-4112-a92e-609f21fd7727	eb600b02-94ed-4d37-912c-ad570ae809da	0	Northwind Traders Remote Work Policy 1. Overview Northwind Traders recognizes the importance of work-life balance. This policy outlines the guidelines for employees working remotely or from home. 2. Eligibility • All full-time employees who have completed their 90-day probationary period are eligible to apply for remote work up to 3 days per week. • Roles requiring physical presence (e.g., warehouse operations, physical mail handling) are exempt from this policy. 3. Core Working Hours Remote employees must be online and available during core working hours: 10:00 AM to 3:00 PM (Local Time). Outside of these hours, flexible scheduling is permitted as long as weekly hour requirements (40 hours) are met. 4. Equipment and Security • Northwind Traders will provide a standard corporate laptop for remote work. • Employees must use a secure, password-protected Wi-Fi network. Public Wi-Fi should only be used in conjunction with the corporate VPN. • Employees are responsible for keeping their remote workspace safe and ergonomically sound. 5. Communication Employees working remotely are expected to maintain regular communication with their team via Microsoft Teams and email. Video is encourage	{"safe_location_path": "Employee Guidelines/Northwind_Remote_Work_Policy.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
1c716dd1-69fd-4ad2-8952-72954e44efb6	eb600b02-94ed-4d37-912c-ad570ae809da	1	d during team meetings to foster connection. Page 1	{"safe_location_path": "Employee Guidelines/Northwind_Remote_Work_Policy.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
c237effe-0130-4032-8867-d6ae3e707427	09dd7ae3-6a54-4b93-bf08-86720c47eba9	0	Northwind Traders Travel & Expense Policy 1. Purpose This document provides guidelines for incurring, reporting, and reimbursing business-related travel and entertainment expenses at Northwind Traders. 2. General Guidelines All travel must be pre-approved by the employee's direct manager if the total cost is expected to exceed $500. 3. Flights and Accommodation • Flights: Employees must book economy class for all domestic flights. International flights exceeding 8 hours may be booked in Premium Economy with VP approval. • Hotels: The maximum nightly rate for hotel accommodation is $250 ($350 for high-cost cities like New York, London, or Tokyo). 4. Meals and Entertainment • Per Diem: Employees are allowed a daily meal allowance of $75 while traveling for business. • Client Entertainment: Reasonable entertainment of clients is permitted. Receipts must include the names of all attendees and the business purpose of the meeting. 5. Reimbursement Process 1. All expenses must be submitted through the Expensify portal within 30 days of the expense being incurred. 2. Itemized receipts are required for all expenses over $25. 3. Finance will process reimbursements within two payroll cycles. 	{"safe_location_path": "Employee Guidelines/Northwind_Travel_and_Expense_Policy.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
66311277-6b83-4353-a006-7e327652b7d5	09dd7ae3-6a54-4b93-bf08-86720c47eba9	1	Page 1	{"safe_location_path": "Employee Guidelines/Northwind_Travel_and_Expense_Policy.pdf"}	employee_guidelines	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
2c470170-743b-4ad1-b8fd-4d87e61d8dde	d48278c7-7a94-4226-b546-74fc91207833	0	Northwind Traders - INVOICE Invoice / Order ID: 10271 Date: 2017-03-10 Bill To: Split Rail Beer & Ale Address: Lander, USA Product Price Quantity Total Geitost $2.00 24 $48.00 Total Amount Due: $48.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10271.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
a2d3109a-6d28-4346-af46-65afca01aabe	7a021b9f-8b87-4155-aea6-0b17f192cb02	0	Northwind Traders - INVOICE Invoice / Order ID: 10278 Date: 2017-04-07 Bill To: Berglunds snabbköp Address: Luleå, Sweden Product Price Quantity Total Gula Malacca $15.50 16 $248.00 Raclette Courdavault $44.00 15 $660.00 Vegie-spread $35.10 8 $280.80 Röd Kaviar $12.00 25 $300.00 Total Amount Due: $1488.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10278.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
a02b061a-f3ad-4e13-ae31-9b6d06083cd6	1117b320-6644-4f81-9f75-190cb8341ec1	0	Northwind Traders - INVOICE Invoice / Order ID: 10287 Date: 2017-05-01 Bill To: Ricardo Adocicados Address: Rio de Janeiro, Brazil Product Price Quantity Total Pavlova $13.90 40 $472.60 Sasquatch Ale $11.20 20 $224.00 Spegesild $9.60 15 $122.40 Total Amount Due: $819.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10287.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
c6150d2e-d1d0-413f-a774-7fdf9006fa17	d3cf5d00-9beb-4245-a94c-0e65b07ad055	0	Northwind Traders - INVOICE Invoice / Order ID: 10311 Date: 2017-07-12 Bill To: Du monde entier Address: Nantes, France Product Price Quantity Total Singaporean Hokkien Fried Mee $11.20 6 $67.20 Gudbrandsdalsost $28.80 7 $201.60 Total Amount Due: $268.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10311.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
9f6c3541-cd99-4af5-809c-80349241675f	affd5185-d983-45d2-add4-14e732503386	0	Northwind Traders - INVOICE Invoice / Order ID: 10313 Date: 2017-07-22 Bill To: QUICK-Stop Address: Cunewalde, Germany Product Price Quantity Total Inlagd Sill $15.20 12 $182.40 Total Amount Due: $182.40	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10313.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
19fc1272-1c78-4ad7-87df-fe308ac6b456	a5d8d746-a764-48c8-b68e-0d100a32b56f	0	Northwind Traders - INVOICE Invoice / Order ID: 10314 Date: 2017-07-24 Bill To: Rattlesnake Canyon Grocery Address: Albuquerque, USA Product Price Quantity Total Mascarpone Fabioli $25.60 40 $921.60 Escargots de Bourgogne $10.60 30 $286.20 Tarte au sucre $39.40 25 $886.50 Total Amount Due: $2094.30	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10314.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
4d46966a-c184-415d-af6f-8fc79fc9fc36	16f51fb6-1865-49aa-9790-8365a9ee2ae4	0	Northwind Traders - INVOICE Invoice / Order ID: 10315 Date: 2017-07-26 Bill To: Island Trading Address: Cowes, UK Product Price Quantity Total Sasquatch Ale $11.20 14 $156.80 Outback Lager $12.00 30 $360.00 Total Amount Due: $516.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10315.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
1932c29d-3c77-4fa8-8ad8-27e196b1ec90	ee98ada8-01ee-423f-bdb6-cec696703cea	0	Northwind Traders - INVOICE Invoice / Order ID: 10334 Date: 2017-09-26 Bill To: Victuailles en stock Address: Lyon, France Product Price Quantity Total Filo Mix $5.60 8 $44.80 Scottish Longbreads $10.00 10 $100.00 Total Amount Due: $144.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10334.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
a3cd06ba-0369-45a5-8b0c-7d25ec3953ef	d92117ed-f680-40df-991d-3a3d233c5b98	0	Northwind Traders - INVOICE Invoice / Order ID: 10357 Date: 2017-12-06 Bill To: LILA-Supermercado Address: Barquisimeto, Venezuela Product Price Quantity Total Ikura $24.80 30 $595.20 Gumbär Gummibärchen $24.90 16 $398.40 Camembert Pierrot $27.20 8 $174.08 Total Amount Due: $1167.68	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10357.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
b57f5e70-2131-4368-9d6c-3971bbd8979b	e3b7e32b-a293-4dd3-9e92-6120721ec3f8	0	Northwind Traders - INVOICE Invoice / Order ID: 10385 Date: 2018-02-13 Bill To: Split Rail Beer & Ale Address: Lander, USA Product Price Quantity Total Uncle Bob's Organic Dried Pears $24.00 10 $192.00 Camembert Pierrot $27.20 20 $435.20 Scottish Longbreads $10.00 8 $64.00 Total Amount Due: $691.20	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10385.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
8b08aa78-4b4f-4f81-a53c-2db5620c1a77	a1efa286-6fa0-4e3a-9db3-42c769c524e2	0	Northwind Traders - INVOICE Invoice / Order ID: 10387 Date: 2018-02-16 Bill To: Santé Gourmet Address: Stavern, Norway Product Price Quantity Total Guarana Fantastica $3.60 15 $54.00 Rössle Sauerkraut $36.40 6 $218.40 Raclette Courdavault $44.00 12 $528.00 Flotemysost $17.20 15 $258.00 Total Amount Due: $1058.40	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10387.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
e13e29ab-72fb-4b62-9dfe-7bf30f8622e1	03e24503-12e6-4333-a0e7-5a052aa1eeb1	0	Northwind Traders - INVOICE Invoice / Order ID: 10416 Date: 2018-04-28 Bill To: Wartian Herkku Address: Oulu, Finland Product Price Quantity Total Teatime Chocolate Biscuits $7.30 20 $146.00 Perth Pasties $26.20 10 $262.00 Ravioli Angelo $15.60 20 $312.00 Total Amount Due: $720.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10416.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
816924c4-f64d-44c7-af44-004e7704d94f	1d0620ff-6d58-48c1-b5e3-aebae6bd8751	0	Northwind Traders - INVOICE Invoice / Order ID: 10447 Date: 2018-07-09 Bill To: Ricardo Adocicados Address: Rio de Janeiro, Brazil Product Price Quantity Total Teatime Chocolate Biscuits $7.30 40 $292.00 Louisiana Fiery Hot Pepper Sauce $16.80 35 $588.00 Flotemysost $17.20 2 $34.40 Total Amount Due: $914.40	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10447.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
0c1c282d-c9c5-4c9b-acb9-0709683f3494	aaeb2ad2-db50-4173-8643-fd8bda7010d3	0	Northwind Traders - INVOICE Invoice / Order ID: 10458 Date: 2018-08-07 Bill To: Suprêmes délices Address: Charleroi, Belgium Product Price Quantity Total Gumbär Gummibärchen $24.90 30 $747.00 Rössle Sauerkraut $36.40 30 $1092.00 Ipoh Coffee $36.80 20 $736.00 Gnocchi di nonna Alice $30.40 15 $456.00 Flotemysost $17.20 50 $860.00 Total Amount Due: $3891.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10458.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
dd3c2be4-81a6-46d1-836a-2cbcba15d796	e7272c05-c4cb-4b8c-8396-83f0405348a8	0	Northwind Traders - INVOICE Invoice / Order ID: 10463 Date: 2018-08-22 Bill To: Suprêmes délices Address: Charleroi, Belgium Product Price Quantity Total Teatime Chocolate Biscuits $7.30 21 $153.30 Singaporean Hokkien Fried Mee $11.20 50 $560.00 Total Amount Due: $713.30	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10463.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
94e6d28d-13e6-4881-b06c-4f57f1c6ede9	2b3df1df-0f45-4937-876a-1bff04402557	0	Northwind Traders - INVOICE Invoice / Order ID: 10487 Date: 2018-10-15 Bill To: Queen Cozinha Address: Sao Paulo, Brazil Product Price Quantity Total Teatime Chocolate Biscuits $7.30 5 $36.50 Gumbär Gummibärchen $24.90 30 $747.00 Tourtière $5.90 24 $106.20 Total Amount Due: $889.70	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10487.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
461149ed-8346-4c38-ad8a-f02f9b9d53ff	34f2c061-18c4-4a83-a381-88812460eb56	0	Northwind Traders - INVOICE Invoice / Order ID: 10495 Date: 2018-11-04 Bill To: Laughing Bacchus Wine Cellars Address: Vancouver, Canada Product Price Quantity Total Tunnbröd $7.20 10 $72.00 Jack's New England Clam Chowder $7.70 20 $154.00 Original Frankfurter Grüne Soße $10.40 5 $52.00 Total Amount Due: $278.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10495.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
650d7fd4-c9e9-461e-83b0-3706a3c003d4	04201f58-43a4-422d-8353-b99123e96e99	0	Northwind Traders - INVOICE Invoice / Order ID: 10507 Date: 2018-12-04 Bill To: Antonio Moreno Taquería Address: Mexico City, Mexico Product Price Quantity Total Ipoh Coffee $46.00 15 $586.50 Chocolade $12.75 15 $162.56 Total Amount Due: $749.06	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10507.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
07405c5d-4992-48cc-b467-0226fa57e75a	b248dd63-c7ae-4623-9526-b659d7a19bc7	0	Northwind Traders - INVOICE Invoice / Order ID: 10508 Date: 2018-12-06 Bill To: Ottilies Käseladen Address: Köln, Germany Product Price Quantity Total Konbu $6.00 10 $60.00 Chartreuse verte $18.00 10 $180.00 Total Amount Due: $240.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10508.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
8b42b463-d5a5-4b34-9a52-54d10cfd24fc	e3ca793e-a237-4d62-b52a-56b5e586f1ed	0	Northwind Traders - INVOICE Invoice / Order ID: 10856 Date: 2020-11-12 Bill To: Antonio Moreno Taquería Address: Mexico City, Mexico Product Price Quantity Total Chang $19.00 20 $380.00 Singaporean Hokkien Fried Mee $14.00 20 $280.00 Total Amount Due: $660.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10856.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
ef15b4a7-4ed5-49f9-9008-e77905f13850	cdfdf250-2c9c-40df-ae33-5e663b705b40	0	Northwind Traders - INVOICE Invoice / Order ID: 10513 Date: 2018-12-21 Bill To: Die Wandernde Kuh Address: Stuttgart, Germany Product Price Quantity Total Sir Rodney's Scones $10.00 40 $320.00 Mascarpone Fabioli $32.00 50 $1280.00 Sirop d'érable $28.50 15 $342.00 Total Amount Due: $1942.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10513.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
b317917b-c6a5-4fe8-b41e-3d8eefdfc01f	c5c7d09d-b497-4ad0-9d03-d8dd897bbcbe	0	Northwind Traders - INVOICE Invoice / Order ID: 10538 Date: 2019-02-15 Bill To: B's Beverages Address: London, UK Product Price Quantity Total Outback Lager $15.00 7 $105.00 Mozzarella di Giovanni $34.80 1 $34.80 Total Amount Due: $139.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10538.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
2d0d09e5-567b-435a-a7ce-73e47b6841bd	0fb05cd2-0223-4c69-b937-f6edc5500ebd	0	Northwind Traders - INVOICE Invoice / Order ID: 10590 Date: 2019-06-26 Bill To: Mère Paillarde Address: Montréal, Canada Product Price Quantity Total Chai $18.00 20 $360.00 Original Frankfurter Grüne Soße $13.00 60 $741.00 Total Amount Due: $1101.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10590.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d155e885-0c43-4cb4-8987-3f296985a8ec	55ed7781-ec87-4629-81a2-3f46342d6636	0	Northwind Traders - INVOICE Invoice / Order ID: 10604 Date: 2019-07-23 Bill To: Furia Bacalhau e Frutos do Mar Address: Lisboa, Portugal Product Price Quantity Total Chocolade $12.75 6 $68.85 Lakkaliköri $18.00 10 $162.00 Total Amount Due: $230.85	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10604.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
11882162-9e45-4434-a590-f0497f83d13a	6fd679e9-3502-4ca3-96c1-4d1465169115	0	Northwind Traders - INVOICE Invoice / Order ID: 10616 Date: 2019-08-24 Bill To: Great Lakes Food Market Address: Eugene, USA Product Price Quantity Total Côte de Blaye $263.50 15 $3754.88 Gnocchi di nonna Alice $38.00 14 $532.00 Outback Lager $15.00 15 $213.75 Flotemysost $21.50 15 $306.38 Total Amount Due: $4807.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10616.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
5faf96d4-6747-4aea-8435-14cf0deadcc8	40182aee-8b9d-4364-8237-f25e441ae9dc	0	Northwind Traders - INVOICE Invoice / Order ID: 10629 Date: 2019-09-23 Bill To: Godos Cocina Típica Address: Sevilla, Spain Product Price Quantity Total Thüringer Rostbratwurst $123.79 20 $2475.80 Wimmers gute Semmelknödel $33.25 9 $299.25 Total Amount Due: $2775.05	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10629.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
132134d8-4d3d-4ead-9794-eef6abaaf5fc	a3d3daaf-129d-4537-ac6c-52e70ee5e585	0	Northwind Traders - INVOICE Invoice / Order ID: 10631 Date: 2019-09-28 Bill To: La maison d'Asie Address: Toulouse, France Product Price Quantity Total Rhönbräu Klosterbier $7.75 8 $55.80 Total Amount Due: $55.80	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10631.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
b4952c55-2bb5-49e7-b2f3-7c0d9c0ec49d	83d949e5-3d25-4fb6-9bf5-fa356c85238b	0	Northwind Traders - INVOICE Invoice / Order ID: 10690 Date: 2020-01-26 Bill To: Hanari Carnes Address: Rio de Janeiro, Brazil Product Price Quantity Total Gnocchi di nonna Alice $38.00 20 $570.00 Original Frankfurter Grüne Soße $13.00 30 $292.50 Total Amount Due: $862.50	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10690.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
99ab000e-3028-4274-8341-04978be8239f	29d87006-e87b-4163-85aa-30c82e97a0e6	0	Northwind Traders - INVOICE Invoice / Order ID: 10699 Date: 2020-02-13 Bill To: Morgenstern Gesundkost Address: Leipzig, Germany Product Price Quantity Total Zaanse koeken $9.50 12 $114.00 Total Amount Due: $114.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10699.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
3b2ba860-155a-4d59-a80b-961c10a58a91	77b1bbf2-a1cb-4b1d-bb43-6810ca513e39	0	Northwind Traders - INVOICE Invoice / Order ID: 10705 Date: 2020-02-27 Bill To: HILARION-Abastos Address: San Cristóbal, Venezuela Product Price Quantity Total Gorgonzola Telino $12.50 20 $250.00 Mascarpone Fabioli $32.00 4 $128.00 Total Amount Due: $378.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10705.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
2396432c-13cf-4a79-880e-c7e203ba4c59	b6d97e88-f0c5-438e-98fd-b7f5cb0ce2cd	0	Northwind Traders - INVOICE Invoice / Order ID: 10729 Date: 2020-04-17 Bill To: LINO-Delicateses Address: I. de Margarita, Venezuela Product Price Quantity Total Chai $18.00 50 $900.00 Sir Rodney's Scones $10.00 30 $300.00 Valkoinen suklaa $16.25 40 $650.00 Total Amount Due: $1850.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10729.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d68d66f4-2bf7-4d4b-97ed-373ca4bc31b3	9a1600bc-0e1b-4817-ba82-5d3c3d58c4ef	0	Northwind Traders - INVOICE Invoice / Order ID: 10733 Date: 2020-04-24 Bill To: Berglunds snabbköp Address: Luleå, Sweden Product Price Quantity Total Tofu $23.25 16 $372.00 Rössle Sauerkraut $45.60 20 $912.00 Filo Mix $7.00 25 $175.00 Total Amount Due: $1459.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10733.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
3e268418-87e4-4c41-8b4f-6f8ba15f6a9a	712ac996-c530-4570-a009-17d002c625a4	0	Northwind Traders - INVOICE Invoice / Order ID: 10760 Date: 2020-06-22 Bill To: Maison Dewey Address: Bruxelles, Belgium Product Price Quantity Total NuNuCa Nuß-Nougat-Creme $14.00 12 $126.00 Schoggi Schokolade $43.90 40 $1756.00 Ipoh Coffee $46.00 30 $1035.00 Total Amount Due: $2917.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10760.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
ed46f3c6-a6b5-4bdb-8e21-be90acc02043	7f69c9f1-1ab7-4e60-ba15-44f283ec16bd	0	Northwind Traders - INVOICE Invoice / Order ID: 10782 Date: 2020-08-01 Bill To: Cactus Comidas para llevar Address: Buenos Aires, Argentina Product Price Quantity Total Gorgonzola Telino $12.50 1 $12.50 Total Amount Due: $12.50	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10782.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
9595c8fd-1351-4302-9443-8fed8dfbf888	02a773fd-8db9-424f-877c-8f903dadc101	0	Northwind Traders - INVOICE Invoice / Order ID: 10792 Date: 2020-08-15 Bill To: Wolski Zajazd Address: Warszawa, Poland Product Price Quantity Total Chang $19.00 10 $190.00 Tourtière $7.45 3 $22.35 Scottish Longbreads $12.50 15 $187.50 Total Amount Due: $399.85	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10792.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
5464e10d-c890-4f89-a70f-356ae4719e07	4f032e6d-f8a7-4cd8-9a86-fe65fa329bc1	0	Northwind Traders - INVOICE Invoice / Order ID: 10799 Date: 2020-08-23 Bill To: Königlich Essen Address: Brandenburg, Germany Product Price Quantity Total Konbu $6.00 20 $102.00 Guarana Fantastica $4.50 20 $76.50 Raclette Courdavault $55.00 25 $1375.00 Total Amount Due: $1553.50	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10799.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d2a23650-b971-4360-89f3-1f4569eca1de	830919af-59c1-4a89-9e32-f2a3179e06b2	0	Northwind Traders - INVOICE Invoice / Order ID: 10806 Date: 2020-09-04 Bill To: Victuailles en stock Address: Lyon, France Product Price Quantity Total Chang $19.00 20 $285.00 Louisiana Fiery Hot Pepper Sauce $21.05 2 $42.10 Longlife Tofu $10.00 15 $112.50 Total Amount Due: $439.60	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10806.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
1ebd4802-9631-4756-bd14-3be9b6ed7982	7eb26406-4985-4e89-9d0b-b840b0408130	0	Northwind Traders - INVOICE Invoice / Order ID: 10868 Date: 2020-11-29 Bill To: Queen Cozinha Address: Sao Paulo, Brazil Product Price Quantity Total Gumbär Gummibärchen $31.23 20 $624.60 Steeleye Stout $18.00 30 $540.00 Maxilaku $20.00 42 $756.00 Total Amount Due: $1920.60	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10868.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
b0959ee6-031f-492f-9c46-0040250bfd12	37b8b394-0ad4-4d93-8e35-1cdb72625679	0	Northwind Traders - INVOICE Invoice / Order ID: 10884 Date: 2020-12-19 Bill To: Let's Stop N Shop Address: San Francisco, USA Product Price Quantity Total Sir Rodney's Scones $10.00 40 $380.00 Gnocchi di nonna Alice $38.00 21 $758.10 Louisiana Fiery Hot Pepper Sauce $21.05 12 $239.97 Total Amount Due: $1378.07	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10884.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
3c0b8b58-b82e-4a53-a6c4-e815ac1dd65b	2928b393-facd-4c68-a2f7-9b7b59029cd1	0	Northwind Traders - INVOICE Invoice / Order ID: 10897 Date: 2021-01-05 Bill To: Hungry Owl All-Night Grocers Address: Cork, Ireland Product Price Quantity Total Thüringer Rostbratwurst $123.79 80 $9903.20 Nord-Ost Matjeshering $25.89 36 $932.04 Total Amount Due: $10835.24	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10897.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
569943c1-ca3d-407a-91b8-7735ecc198ba	93e08a2f-aeef-4bab-877c-0bd17b735a44	0	Northwind Traders - INVOICE Invoice / Order ID: 10930 Date: 2021-02-11 Bill To: Suprêmes délices Address: Charleroi, Belgium Product Price Quantity Total Sir Rodney's Scones $10.00 36 $360.00 Schoggi Schokolade $43.90 25 $1097.50 Pâté chinois $24.00 25 $480.00 Escargots de Bourgogne $13.25 30 $318.00 Total Amount Due: $2255.50	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10930.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
c2313e46-0afc-489e-a141-f20af55d3d84	8451f27e-64f0-4622-9942-ff289af6e63a	0	Northwind Traders - INVOICE Invoice / Order ID: 10933 Date: 2021-02-11 Bill To: Island Trading Address: Cowes, UK Product Price Quantity Total Perth Pasties $32.80 2 $65.60 Sirop d'érable $28.50 30 $855.00 Total Amount Due: $920.60	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10933.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
04cc22c0-effb-4f42-861a-bf07d10b384d	2b97cad6-fe0e-42ff-ac57-128b1f0647aa	0	Northwind Traders - INVOICE Invoice / Order ID: 10968 Date: 2021-03-25 Bill To: Ernst Handel Address: Graz, Austria Product Price Quantity Total Queso Manchego La Pastora $38.00 30 $1140.00 Guarana Fantastica $4.50 30 $135.00 Wimmers gute Semmelknödel $33.25 4 $133.00 Total Amount Due: $1408.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10968.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
cb236c2e-6a99-4d22-ae93-0151e8beff92	7839488a-0302-4cdf-965c-92e3b3b6efa2	0	Northwind Traders - INVOICE Invoice / Order ID: 10999 Date: 2021-04-21 Bill To: Ottilies Käseladen Address: Köln, Germany Product Price Quantity Total Jack's New England Clam Chowder $9.65 20 $183.35 Manjimup Dried Apples $53.00 15 $755.25 Original Frankfurter Grüne Soße $13.00 21 $259.35 Total Amount Due: $1197.95	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_10999.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
1c638295-b88c-41b4-a837-6ff50065e0a7	c3a62960-18b7-493e-9248-dc25d1f82f55	0	Northwind Traders - INVOICE Invoice / Order ID: 11024 Date: 2021-05-21 Bill To: Eastern Connection Address: London, UK Product Price Quantity Total Gumbär Gummibärchen $31.23 12 $374.76 Geitost $2.50 30 $75.00 Louisiana Fiery Hot Pepper Sauce $21.05 21 $442.05 Flotemysost $21.50 50 $1075.00 Total Amount Due: $1966.81	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11024.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d164606b-2570-4a4a-aac1-12f3fe7577b4	e35358f7-36cd-41f6-8c8f-c239829379b5	0	Northwind Traders - INVOICE Invoice / Order ID: 11031 Date: 2021-05-26 Bill To: Save-a-lot Markets Address: Boise, USA Product Price Quantity Total Chai $18.00 45 $810.00 Konbu $6.00 80 $480.00 Guarana Fantastica $4.50 21 $94.50 Wimmers gute Semmelknödel $33.25 20 $665.00 Flotemysost $21.50 16 $344.00 Total Amount Due: $2393.50	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11031.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
de7208a7-e724-4f44-ab86-09f42b6816e8	d63e39c5-2b73-4e8a-bae3-529c51963a37	0	Northwind Traders - INVOICE Invoice / Order ID: 11039 Date: 2021-06-05 Bill To: LINO-Delicateses Address: I. de Margarita, Venezuela Product Price Quantity Total Rössle Sauerkraut $45.60 20 $912.00 Steeleye Stout $18.00 24 $432.00 Maxilaku $20.00 60 $1200.00 Ravioli Angelo $19.50 28 $546.00 Total Amount Due: $3090.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11039.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
289ce48d-03d7-4828-ad06-d42e45385afb	c8bd35c7-e595-4e1d-a376-6b12755a5623	0	Northwind Traders - INVOICE Invoice / Order ID: 11059 Date: 2021-06-24 Bill To: Ricardo Adocicados Address: Rio de Janeiro, Brazil Product Price Quantity Total Konbu $6.00 30 $180.00 Alice Mutton $39.00 12 $468.00 Camembert Pierrot $34.00 35 $1190.00 Total Amount Due: $1838.00	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11059.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
13220ebf-802d-48ee-b3fd-6187c202113c	b2272bf8-cf18-4c5f-8ee1-026983b6acc9	0	Northwind Traders - INVOICE Invoice / Order ID: 11064 Date: 2021-06-29 Bill To: Save-a-lot Markets Address: Boise, USA Product Price Quantity Total Alice Mutton $39.00 77 $2702.70 Jack's New England Clam Chowder $9.65 12 $115.80 Perth Pasties $32.80 25 $738.00 Pâté chinois $24.00 4 $86.40 Scottish Longbreads $12.50 55 $687.50 Total Amount Due: $4330.40	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11064.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
0813b78f-aba2-4128-bb71-f45cdd02b993	79da76d2-2d9f-46e2-8ba9-2f42b0b8966d	0	Northwind Traders - INVOICE Invoice / Order ID: 11065 Date: 2021-06-29 Bill To: LILA-Supermercado Address: Barquisimeto, Venezuela Product Price Quantity Total Nord-Ost Matjeshering $25.89 4 $77.67 Tourtière $7.45 20 $111.75 Total Amount Due: $189.42	{"safe_location_path": "Finance/Invoices (50 Sample only)/Invoice_11065.pdf"}	finance	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
63ee052c-546b-4771-918b-5165ee958e22	d3d1d595-3310-4583-8dc6-c309d4ca9772	0	Natalie Gardner Email: natalie.gardner@northwind.com | Phone: +1-736-619-3990x91699 Professional Profile Experienced and dedicated Software Engineer with a strong background in IT. Proven track record of success and driving business results. Experience Software Engineer - Northwind Traders Started: 2020-08-03 Key responsibilities include managing daily operations within the IT department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Computer Science University of Lake Jennifer	{"safe_location_path": "HR/Employee CV/10_Natalie_Gardner_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
45733462-1f38-4b1c-971d-afa9d8576a68	8dc042d0-a064-45c5-970c-bc75bad8e678	0	Anna Hall Email: anna.hall@northwind.com | Phone: 946.324.7510 Professional Profile Experienced and dedicated Recruiter with a strong background in HR. Proven track record of success and driving business results. Experience Recruiter - Northwind Traders Started: 2017-03-24 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Marketing University of New Jasonview	{"safe_location_path": "HR/Employee CV/11_Anna_Hall_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
472e9e4e-3ba9-4874-8c55-ccb2314a15b8	3674040a-3b27-400a-9bb5-77460501994a	0	Mike Miles Email: mike.miles@northwind.com | Phone: (651)235-4278 Professional Profile Experienced and dedicated Recruiter with a strong background in HR. Proven track record of success and driving business results. Experience Recruiter - Northwind Traders Started: 2020-07-27 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Computer Science University of Sarahville	{"safe_location_path": "HR/Employee CV/12_Mike_Miles_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
4a3efef0-079b-440b-a164-03be3581004c	f1822609-082a-4420-a5f7-839df48e8208	0	Kevin Pacheco Email: kevin.pacheco@northwind.com | Phone: (541)718-2449 Professional Profile Experienced and dedicated Marketing Specialist with a strong background in Marketing. Proven track record of success and driving business results. Experience Marketing Specialist - Northwind Traders Started: 2017-01-21 Key responsibilities include managing daily operations within the Marketing department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Business Administration University of Lake Cynthia	{"safe_location_path": "HR/Employee CV/13_Kevin_Pacheco_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
343dd416-0e62-4645-a3ac-4e5781cd3bbf	e50cc60a-18fc-4de1-8a65-fd8da54acea0	0	Christopher Henderson Email: christopher.henderson@northwind.com | Phone: 687-440-1640x052 Professional Profile Experienced and dedicated Sales Manager with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Manager - Northwind Traders Started: 2019-05-14 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Marketing University of Arnoldchester	{"safe_location_path": "HR/Employee CV/14_Christopher_Henderson_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
3282bb82-99b7-49d0-b6e2-29ae4b4df9e1	3f1c8eda-a513-47ef-9f28-cac5f0d94763	0	Tina Rogers Email: tina.rogers@northwind.com | Phone: +1-401-812-8059 Professional Profile Experienced and dedicated Financial Analyst with a strong background in Finance. Proven track record of success and driving business results. Experience Financial Analyst - Northwind Traders Started: 2017-10-16 Key responsibilities include managing daily operations within the Finance department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Marketing University of North Kyle	{"safe_location_path": "HR/Employee CV/15_Tina_Rogers_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
85a00777-1a4a-4892-8c02-5c6ffc73ebce	9313719f-8717-4ed9-be20-20ebd2127662	0	Ian Cooper Email: ian.cooper@northwind.com | Phone: 4535315869 Professional Profile Experienced and dedicated HR Specialist with a strong background in HR. Proven track record of success and driving business results. Experience HR Specialist - Northwind Traders Started: 2019-04-02 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education M.A. in Marketing University of Port Lisa	{"safe_location_path": "HR/Employee CV/16_Ian_Cooper_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d146c715-1d9e-4028-bb5f-643ab584f8ed	5764b056-c464-4ee1-a9cc-4f8cd4a2bed7	0	Nicholas Herrera Email: nicholas.herrera@northwind.com | Phone: (902)756-3421x60733 Professional Profile Experienced and dedicated Content Writer with a strong background in Marketing. Proven track record of success and driving business results. Experience Content Writer - Northwind Traders Started: 2020-03-22 Key responsibilities include managing daily operations within the Marketing department, collaborating with cross-functional teams, and delivering high-quality results. Education M.A. in Marketing University of Loribury	{"safe_location_path": "HR/Employee CV/17_Nicholas_Herrera_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
ab182812-d833-484f-98f5-06d8cca99d02	fbf5e195-2c28-4664-9ec2-a6b765107464	0	Elaine Fuller Email: elaine.fuller@northwind.com | Phone: 803.765.4145 Professional Profile Experienced and dedicated Financial Analyst with a strong background in Finance. Proven track record of success and driving business results. Experience Financial Analyst - Northwind Traders Started: 2020-01-29 Key responsibilities include managing daily operations within the Finance department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Marketing University of North Natalieview	{"safe_location_path": "HR/Employee CV/18_Elaine_Fuller_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
c4055b35-4380-47ca-a2f5-544b46444a7c	9a0425dc-cd3f-40b2-afe3-6d3ab998a554	0	Michael Williams Email: michael.williams@northwind.com | Phone: (894)301-9655 Professional Profile Experienced and dedicated Content Writer with a strong background in Marketing. Proven track record of success and driving business results. Experience Content Writer - Northwind Traders Started: 2018-12-10 Key responsibilities include managing daily operations within the Marketing department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Computer Science University of Lamborough	{"safe_location_path": "HR/Employee CV/19_Michael_Williams_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
22ba2178-4934-4fa7-a9ea-0b4de57f45b8	e97ffefa-997b-4ae3-81ee-0086c7199abe	0	Nancy Davolio Email: nancy.davolio@northwind.com | Phone: +1-289-332-5288x0957 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2015-09-21 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Computer Science University of Natashaport	{"safe_location_path": "HR/Employee CV/1_Nancy_Davolio_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
a669dc9d-9905-404c-8009-dc81ca41dd56	319c10dc-1abe-4af7-b58c-b37e7b7a600c	0	Victoria Wyatt Email: victoria.wyatt@northwind.com | Phone: 706-308-8356x159 Professional Profile Experienced and dedicated Software Engineer with a strong background in IT. Proven track record of success and driving business results. Experience Software Engineer - Northwind Traders Started: 2017-11-10 Key responsibilities include managing daily operations within the IT department, collaborating with cross-functional teams, and delivering high-quality results. Education M.A. in Computer Science University of Williamchester	{"safe_location_path": "HR/Employee CV/20_Victoria_Wyatt_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
4f525a72-5d3d-40ff-83d8-8e7eddad8a62	9ffe1d3f-9095-4066-a557-577dfa456a19	0	Jody Flowers Email: jody.flowers@northwind.com | Phone: 264-682-3662x99468 Professional Profile Experienced and dedicated Recruiter with a strong background in HR. Proven track record of success and driving business results. Experience Recruiter - Northwind Traders Started: 2018-05-21 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of Jasonshire	{"safe_location_path": "HR/Employee CV/21_Jody_Flowers_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
916a655d-754c-454d-b321-e85519fcc807	4f605a56-828f-43b7-a4ae-85177807ef72	0	Christine Adams Email: christine.adams@northwind.com | Phone: +1-757-377-3872x148 Professional Profile Experienced and dedicated Account Executive with a strong background in Sales. Proven track record of success and driving business results. Experience Account Executive - Northwind Traders Started: 2017-08-10 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Business Administration University of Lake Lance	{"safe_location_path": "HR/Employee CV/22_Christine_Adams_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
b61ef322-cb34-4b66-9c96-97f636d1aea0	06578b47-cbea-4bd3-9fb0-38b396896580	0	Christopher Daniel Email: christopher.daniel@northwind.com | Phone: 820.503.7917 Professional Profile Experienced and dedicated Logistics Coordinator with a strong background in Operations. Proven track record of success and driving business results. Experience Logistics Coordinator - Northwind Traders Started: 2018-05-23 Key responsibilities include managing daily operations within the Operations department, collaborating with cross-functional teams, and delivering high-quality results. Education M.A. in Business Administration University of Snyderbury	{"safe_location_path": "HR/Employee CV/23_Christopher_Daniel_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
83d0d7d9-39ac-4d97-9415-2c3f69cfc7cc	dcdd9c3f-0d5f-4ad9-ab5f-a7eb047e8a2f	0	Devin Schaefer Email: devin.schaefer@northwind.com | Phone: (501)363-2870 Professional Profile Experienced and dedicated Marketing Specialist with a strong background in Marketing. Proven track record of success and driving business results. Experience Marketing Specialist - Northwind Traders Started: 2018-11-14 Key responsibilities include managing daily operations within the Marketing department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of Andersonmouth	{"safe_location_path": "HR/Employee CV/24_Devin_Schaefer_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
408d724e-3ce2-4775-b286-969ffebcc97e	b0b9a94d-9c55-4658-9348-7a27ef277020	0	Ryan Parsons Email: ryan.parsons@northwind.com | Phone: +1-688-595-7986x87277 Professional Profile Experienced and dedicated Accountant with a strong background in Finance. Proven track record of success and driving business results. Experience Accountant - Northwind Traders Started: 2018-12-13 Key responsibilities include managing daily operations within the Finance department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Human Resources University of Katiehaven	{"safe_location_path": "HR/Employee CV/25_Ryan_Parsons_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
52480ebb-0dff-424a-9eb6-96d8a39d26dc	16281bbe-bfd2-491c-a2a8-8efdd8829cf8	0	Robert Morales Email: robert.morales@northwind.com | Phone: 434.571.4345x5812 Professional Profile Experienced and dedicated HR Specialist with a strong background in HR. Proven track record of success and driving business results. Experience HR Specialist - Northwind Traders Started: 2017-07-25 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Computer Science University of Bensonborough	{"safe_location_path": "HR/Employee CV/26_Robert_Morales_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
c874b5de-9e72-4854-986f-f0567da4682d	ad11edd5-6345-477f-9908-c37ac07cbb3d	0	Tommy Walter Email: tommy.walter@northwind.com | Phone: 866-858-7603 Professional Profile Experienced and dedicated System Administrator with a strong background in IT. Proven track record of success and driving business results. Experience System Administrator - Northwind Traders Started: 2019-09-05 Key responsibilities include managing daily operations within the IT department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of Port Nicoleshire	{"safe_location_path": "HR/Employee CV/27_Tommy_Walter_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
1db6a744-d6ae-41d4-b987-821a36cf1448	7996347a-118a-4127-9e1b-ba93ab83b813	0	Jonathan Wilkerson Email: jonathan.wilkerson@northwind.com | Phone: (670)854-6688x9373 Professional Profile Experienced and dedicated Recruiter with a strong background in HR. Proven track record of success and driving business results. Experience Recruiter - Northwind Traders Started: 2020-11-26 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Computer Science University of Johnsonmouth	{"safe_location_path": "HR/Employee CV/28_Jonathan_Wilkerson_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
3b5f744a-8c88-4aff-98b8-e82f43e242c8	ec451662-acc7-4822-9969-b08129c3fae0	0	Charles Mcgee Email: charles.mcgee@northwind.com | Phone: +1-462-972-9806x99016 Professional Profile Experienced and dedicated Account Executive with a strong background in Sales. Proven track record of success and driving business results. Experience Account Executive - Northwind Traders Started: 2019-03-28 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of North Jorge	{"safe_location_path": "HR/Employee CV/29_Charles_Mcgee_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
200c1179-d9aa-41d0-98f1-43ef490f09f7	27aa878c-33ef-4c5c-aa17-ba0184efff6b	0	Andrew Fuller Email: andrew.fuller@northwind.com | Phone: 403.491.1718 Professional Profile Experienced and dedicated Vice President Sales with a strong background in Sales. Proven track record of success and driving business results. Experience Vice President Sales - Northwind Traders Started: 2013-06-22 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Marketing University of Arroyoburgh	{"safe_location_path": "HR/Employee CV/2_Andrew_Fuller_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
6e56a52f-5dc7-4ea8-9459-d13bf717848d	5cf0959a-7b63-4ee9-a142-62434c438aee	0	Jeffrey Silva Email: jeffrey.silva@northwind.com | Phone: 737-555-6464x17080 Professional Profile Experienced and dedicated HR Specialist with a strong background in HR. Proven track record of success and driving business results. Experience HR Specialist - Northwind Traders Started: 2020-01-30 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Computer Science University of Port Susanton	{"safe_location_path": "HR/Employee CV/30_Jeffrey_Silva_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
9f2dc66f-70d7-4b12-8395-db47091f63c9	e19942f2-f352-4544-b4ae-9e1947c16499	0	Yolanda Hicks Email: yolanda.hicks@northwind.com | Phone: 001-603-730-9232x71937 Professional Profile Experienced and dedicated Recruiter with a strong background in HR. Proven track record of success and driving business results. Experience Recruiter - Northwind Traders Started: 2017-10-10 Key responsibilities include managing daily operations within the HR department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Business Administration University of New Catherine	{"safe_location_path": "HR/Employee CV/31_Yolanda_Hicks_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
d32a10c0-e368-4a3a-86fc-a8d17233caf7	f032ab6e-ccec-428e-a6d0-674e3fe3c19a	0	Shannon Hernandez Email: shannon.hernandez@northwind.com | Phone: 001-512-341-9049x6631 Professional Profile Experienced and dedicated Logistics Coordinator with a strong background in Operations. Proven track record of success and driving business results. Experience Logistics Coordinator - Northwind Traders Started: 2018-05-13 Key responsibilities include managing daily operations within the Operations department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Computer Science University of Melissaville	{"safe_location_path": "HR/Employee CV/32_Shannon_Hernandez_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
bda40580-16bd-4c69-ae80-668aee35ab4f	880cdd29-0a87-475f-968a-968cf286d2bf	0	Jay Brown Email: jay.brown@northwind.com | Phone: 001-205-886-5185 Professional Profile Experienced and dedicated Sales Manager with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Manager - Northwind Traders Started: 2020-03-31 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Human Resources University of Garciastad	{"safe_location_path": "HR/Employee CV/33_Jay_Brown_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
8c4ecb34-408f-4496-8e45-4501cd29b08c	6c15cc56-6a2d-453c-ba7a-d21aec7dea24	0	John King Email: john.king@northwind.com | Phone: +1-672-762-8498x7769 Professional Profile Experienced and dedicated Business Development with a strong background in Sales. Proven track record of success and driving business results. Experience Business Development - Northwind Traders Started: 2017-02-05 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of Port Sarah	{"safe_location_path": "HR/Employee CV/34_John_King_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
8cca000d-008d-45b9-ae9b-0855e62e44e8	e9f1bddc-efd7-4c56-afa2-0aa177798863	0	Ashley Dyer Email: ashley.dyer@northwind.com | Phone: 973-579-9650x752 Professional Profile Experienced and dedicated Business Development with a strong background in Sales. Proven track record of success and driving business results. Experience Business Development - Northwind Traders Started: 2019-04-09 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Marketing University of Laurenmouth	{"safe_location_path": "HR/Employee CV/35_Ashley_Dyer_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
e1292ccc-829e-4aed-9596-6dc644c84243	35e181cb-0ec9-491d-8409-323434be391d	0	Gerald Carter Email: gerald.carter@northwind.com | Phone: 594-980-8313x678 Professional Profile Experienced and dedicated Content Writer with a strong background in Marketing. Proven track record of success and driving business results. Experience Content Writer - Northwind Traders Started: 2018-05-07 Key responsibilities include managing daily operations within the Marketing department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Human Resources University of Westtown	{"safe_location_path": "HR/Employee CV/36_Gerald_Carter_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
d0cc5aae-eded-4e3c-9194-abf455271673	03b7672b-846a-43df-844a-4eb41affde11	0	Troy Liu Email: troy.liu@northwind.com | Phone: 743-863-4957 Professional Profile Experienced and dedicated Business Development with a strong background in Sales. Proven track record of success and driving business results. Experience Business Development - Northwind Traders Started: 2019-03-30 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Finance University of Michaelmouth	{"safe_location_path": "HR/Employee CV/37_Troy_Liu_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
927450d5-8cf1-43b3-aafd-4788cae9d42b	bc09f7b5-2d7a-4ccd-b21f-41a7de505e14	0	Dr. Jordan Rodriguez Email: dr..jordan.rodriguez@northwind.com | Phone: 944-631-3518x233 Professional Profile Experienced and dedicated Sales Manager with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Manager - Northwind Traders Started: 2019-07-17 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education M.A. in Computer Science University of Tinaborough	{"safe_location_path": "HR/Employee CV/38_Dr._Jordan_Rodriguez_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
acae731a-e9c5-476a-b57a-3398dd995150	a1df9635-024e-41a4-b238-b6e4b834a282	0	Janet Leverling Email: janet.leverling@northwind.com | Phone: 989-363-8346x578 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2013-02-08 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Marketing University of East Caleb	{"safe_location_path": "HR/Employee CV/3_Janet_Leverling_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
824f2197-8bd7-44db-b6d4-51b14e70804c	b4796f86-8e31-49eb-aa71-61cd3bee1991	0	Margaret Peacock Email: margaret.peacock@northwind.com | Phone: 5983393010 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2016-02-26 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.S. in Finance University of Port Markhaven	{"safe_location_path": "HR/Employee CV/4_Margaret_Peacock_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
578af59f-7c03-4318-9dae-dca012eee61a	86584249-f6f8-4eeb-8709-55205725e354	0	Steven Buchanan Email: steven.buchanan@northwind.com | Phone: 547.938.2997 Professional Profile Experienced and dedicated Sales Manager with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Manager - Northwind Traders Started: 2014-03-04 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education M.S. in Computer Science University of Leeville	{"safe_location_path": "HR/Employee CV/5_Steven_Buchanan_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
afb98027-2fc4-443e-a61b-8398639354c7	ed2f2a23-0798-4027-bf48-50581ded48ad	0	Michael Suyama Email: michael.suyama@northwind.com | Phone: +1-565-966-7010x65133 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2014-01-16 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Marketing University of South Isaiah	{"safe_location_path": "HR/Employee CV/6_Michael_Suyama_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
91884186-7022-40e3-a2f9-3dac071c579d	0924a455-8fc3-408c-9e7a-a09c94126b72	0	Robert King Email: robert.king@northwind.com | Phone: 831.978.1080x132 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2013-12-13 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education MBA in Business Administration University of Lewisfurt	{"safe_location_path": "HR/Employee CV/7_Robert_King_CV.pdf"}	hr	{"parser_extension": ".pdf"}	t	2026-07-20 17:59:16.167083+00
2ca2b86e-8999-4534-ba0a-bd9337564ca8	f4986604-cc96-4258-b093-e94d12e06e5f	0	Laura Callahan Email: laura.callahan@northwind.com | Phone: 9264064746 Professional Profile Experienced and dedicated Sales Manager with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Manager - Northwind Traders Started: 2013-08-05 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Human Resources University of West Jeff	{"safe_location_path": "HR/Employee CV/8_Laura_Callahan_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
f2e70426-bf4e-4483-96aa-6a1561159495	c9b53dee-3ffe-4d21-872f-87fc023e4474	0	Anne Dodsworth Email: anne.dodsworth@northwind.com | Phone: 4982050097 Professional Profile Experienced and dedicated Sales Representative with a strong background in Sales. Proven track record of success and driving business results. Experience Sales Representative - Northwind Traders Started: 2016-02-19 Key responsibilities include managing daily operations within the Sales department, collaborating with cross-functional teams, and delivering high-quality results. Education B.A. in Business Administration University of Port Jacobland	{"safe_location_path": "HR/Employee CV/9_Anne_Dodsworth_CV.docx"}	hr	{"parser_extension": ".docx"}	t	2026-07-20 17:59:16.167083+00
\.


--
-- Data for Name: permission_scopes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_scopes (scope_key, display_name, is_active, created_at) FROM stdin;
employee_guidelines	Employee Guidelines	t	2026-07-20 17:59:04.023075+00
file_server	File Server	t	2026-07-20 17:59:04.023075+00
finance	Finance	t	2026-07-20 17:59:04.023075+00
hr	HR	t	2026-07-20 17:59:04.023075+00
\.


--
-- Data for Name: rag_chunk_embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rag_chunk_embeddings (embedding_id, chunk_id, embedding, embedding_model, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, name, checksum, applied_at) FROM stdin;
001	extensions	40473a735fd63e4d4b796d9befbf2d918a441a4dad70c60a548127729b905890	2026-07-20 17:59:04.023075+00
002	core_schema	b619c1bcd6192c36a3569019d311d7915ca56c40f6b1fad312b981172423bae4	2026-07-20 17:59:04.023075+00
003	runtime_roles_rls	221eb997f4aeaf3bba29bf453f1d67bc1e33139127104cd16c26360f3638c5fe	2026-07-20 17:59:04.023075+00
004	exact_resource_rls	8ead6991ed149c608bb453c3ab913822ac5e1836269aac1d78737b8483fb152a	2026-07-20 17:59:04.023075+00
\.


--
-- Data for Name: source_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_catalog (source_id, source_type, source_uri, display_name, permission_scope_key, metadata, is_active, created_at) FROM stdin;
6e30b4b1-3cec-4e83-bbb4-ef5602bc9dba	rag_document	active-dataset://Employee Guidelines/Northwind_Code_of_Conduct.pdf	Northwind_Code_of_Conduct.pdf	employee_guidelines	{"size_bytes": 2188, "content_hash": "4f3e76d4dec13a2cce024f63559581fd47a6056e5428b54e5de7a28280ebfbbe", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5230ceb3-111b-4e74-84e7-aed6a2247134	rag_document	active-dataset://Employee Guidelines/Northwind_Leave_and_PTO_Policy.pdf	Northwind_Leave_and_PTO_Policy.pdf	employee_guidelines	{"size_bytes": 1985, "content_hash": "c1e9535f6ba2fcb7b95f1ee52f5a650ebaa54e418e7b707a110aef49a6d4ca97", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
a65f6449-4c54-44f8-b46a-7b5a288a28d6	rag_document	active-dataset://Employee Guidelines/Northwind_Remote_Work_Policy.pdf	Northwind_Remote_Work_Policy.pdf	employee_guidelines	{"size_bytes": 2183, "content_hash": "320efb0ead16a8386ce9b28799efdc9a6bab0d99470b61f999f261d4a0759a75", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
1ef60f5d-524b-4e21-a13b-9199d6462a75	rag_document	active-dataset://Employee Guidelines/Northwind_Travel_and_Expense_Policy.pdf	Northwind_Travel_and_Expense_Policy.pdf	employee_guidelines	{"size_bytes": 2154, "content_hash": "0fd927f7702aeec005ca8f9a21040f5304e57a87fa1b4b15164f2f51d5939b6f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
c70cbd0b-9c23-43f8-97e2-fb7ae9ec941b	structured_table	active-dataset://File Server/categories.csv	categories.csv	file_server	{"size_bytes": 406, "content_hash": "247a58c07dab5c39622ad4bf6fdacf3c8c688da5e418922d6049f29e8072a48b", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
41bfc0e1-36cf-45fa-b289-aa84fcc60c2f	structured_table	active-dataset://File Server/customers.csv	customers.csv	file_server	{"size_bytes": 6806, "content_hash": "ad2971fa555a46e18106ee116f78c9de57db99ea9a8737ce7201af2c0255b23e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
84fbf46f-6ea2-4bf8-983f-680ea0944357	structured_table	active-dataset://File Server/order_details.xlsx	order_details.xlsx	file_server	{"size_bytes": 55230, "content_hash": "7901846552b669d8929b4275a5267b3d8de5539ae5ea8d0cf52e73a1cbfb4768", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
2562ceba-424a-45b3-89eb-f9c44bf2b070	structured_table	active-dataset://File Server/orders.xlsx	orders.xlsx	file_server	{"size_bytes": 62381, "content_hash": "3d36f38de9374ff2812c6d94e95c1f8325a0dc179c631fe0229c7fb99d48ccec", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5074947b-e994-46f0-aa36-d43b3c271b72	structured_table	active-dataset://File Server/products.csv	products.csv	file_server	{"size_bytes": 3638, "content_hash": "a248ee48a59e2bc2125b8cd5c3265c6dea1cc93564e278978b503115d87e7e17", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
c4cd6dcd-5651-4ccc-865b-f7335c004f71	structured_table	active-dataset://File Server/shippers.csv	shippers.csv	file_server	{"size_bytes": 79, "content_hash": "5776d698415453e46960334d4e79abf2d68e152fb02c661837fbc8103704d7b3", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
aedb1ff9-fefc-4531-b8d2-8f164eadf9d7	structured_table	active-dataset://Finance/Company Expense.xlsx	Company Expense.xlsx	finance	{"size_bytes": 57437, "content_hash": "b1b28dd2e60200ec1d9d5479f28789d1095ec9205031b761c5af4bb9c1368f64", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
480342b7-558e-4237-b7f0-16cb4b3bd14f	structured_table	active-dataset://Finance/Company Revenue.xlsx	Company Revenue.xlsx	finance	{"size_bytes": 35347, "content_hash": "8cf4b1a8b9b09ad537cac90aaab7962a6895ef0406b9266201e0f893be104d58", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
00390119-3444-442c-8e00-d664b4b1e56e	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10271.pdf	Invoice_10271.pdf	finance	{"size_bytes": 1434, "content_hash": "0980d9f9415baf3a86f68eddbc776ecc8dbb520b6442e2364af5ff4fab8d6f2e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5c8776c9-6eca-434c-9c6f-7b0ffea1b5c1	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10278.pdf	Invoice_10278.pdf	finance	{"size_bytes": 1610, "content_hash": "e9fc72fa573e4c02d943652bb82d19d17250b8cbbf15f7f718e3e7dac16b9faa", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
dafc5e83-f1fd-412e-a4f6-b40a1c691320	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10287.pdf	Invoice_10287.pdf	finance	{"size_bytes": 1547, "content_hash": "0ccfdd778a16c753757874b85c563566290aa2d37e656bdf16201acf93ca47cc", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
feff9ef7-16fa-4351-8d89-97ceba626eab	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10311.pdf	Invoice_10311.pdf	finance	{"size_bytes": 1504, "content_hash": "47a2f2fe5e8d09af682c8ed7e005fd01b84d927465d8da28f7ece00a595e458f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
29ea70cf-e319-4492-90d9-f4aaf7ba9150	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10313.pdf	Invoice_10313.pdf	finance	{"size_bytes": 1436, "content_hash": "3bf5386de6e642cb840bfbf4bece8585b1608ef44a601e36e92898a87130b192", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
e74dd380-74ae-449c-ba7e-1e905cd3aca1	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10314.pdf	Invoice_10314.pdf	finance	{"size_bytes": 1569, "content_hash": "01172fba5b4683d790af962f838618afa1874d3b64c0c7efc314e69d31574a01", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
401711c4-9403-4e7f-a705-295a000d4df4	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10315.pdf	Invoice_10315.pdf	finance	{"size_bytes": 1489, "content_hash": "1798758ae00f005176f554369d27fc19a6d6e3a405c9cc9255562ad3cee75e6b", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
245e1f7f-f3e6-433c-b4df-72917f2e461a	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10334.pdf	Invoice_10334.pdf	finance	{"size_bytes": 1494, "content_hash": "8e5bf3b4134d2638117f30e16381e4bf8dc63efe529c46068595558f5c435311", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
f57ddc1a-b5b7-43e4-b8b0-618cb51739e9	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10357.pdf	Invoice_10357.pdf	finance	{"size_bytes": 1564, "content_hash": "afeaa6c784e0a335292433324202608f760e259cda1bdb14008e2bf338b6f6fc", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
b3e6e20d-669b-4b5d-abb8-81d7af477532	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10385.pdf	Invoice_10385.pdf	finance	{"size_bytes": 1571, "content_hash": "61f931eba97d2434765f8fc95911c7011e1da34861e30ede7ba83ca9cb6e9190", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
9e85f707-0888-4c61-ad61-a38f9bd8c940	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10387.pdf	Invoice_10387.pdf	finance	{"size_bytes": 1608, "content_hash": "293c6414b378d47dbb3a31212681b3daae87819fd52c10ea332745361211c824", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5906d7d9-a6b0-4b04-85d1-ce3d9c02883f	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10416.pdf	Invoice_10416.pdf	finance	{"size_bytes": 1554, "content_hash": "ee976a7dd133bfdf176f8a3cc8b19e8ee707337dcec7d2e4c93033969f3ce79d", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
c284a707-fab7-444a-8305-1f109beaae17	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10447.pdf	Invoice_10447.pdf	finance	{"size_bytes": 1576, "content_hash": "f6084080c43b6d6253286cfef5591b204eacfa5c1370d299c5eabfda52c47626", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
edf70a52-9a45-460a-80a6-b2b87af1c035	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10458.pdf	Invoice_10458.pdf	finance	{"size_bytes": 1673, "content_hash": "cc8716976de5a808c675ced90b98323663538e465015d18c31c4b33b0205ddb7", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
300837bf-6ca0-4820-918a-133383bcf1ca	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10463.pdf	Invoice_10463.pdf	finance	{"size_bytes": 1523, "content_hash": "a8320db08c64b3d333f79785a1851ace8bc241c287638a5054019ecb733a08c9", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
6c65c142-8605-4623-9a9a-91cfbb567bae	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10487.pdf	Invoice_10487.pdf	finance	{"size_bytes": 1563, "content_hash": "358728c1fcb8a51949cddc202871fd64dd60ddb5e2bf2b1f5b5d5b41b20f1612", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
336e149a-49bb-425b-b13e-b82f3796cf7a	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10495.pdf	Invoice_10495.pdf	finance	{"size_bytes": 1589, "content_hash": "f4ba4da38fc6f01d38bc74a28fee57df285c4dd2d5a1b2168779c0aae5459e2a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
cbc7b447-f178-4006-9795-c45787c5949b	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10507.pdf	Invoice_10507.pdf	finance	{"size_bytes": 1499, "content_hash": "0d5c21bbff9549af116049ba09a9da9e7573b95dd1b5396bc5a5d02b032db8a9", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4022acdd-df49-47ae-b235-60e3ed4eac2a	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10508.pdf	Invoice_10508.pdf	finance	{"size_bytes": 1490, "content_hash": "37104086ce31599510d9d952d31e1c7daab9807c0424803b064786bd01c5c6ba", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
915d2098-fe7d-49df-af25-6ef09c729a95	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10513.pdf	Invoice_10513.pdf	finance	{"size_bytes": 1559, "content_hash": "bb2adae19f57072528506f02defdcbab78bee081a9991f6edef42e3c3e2b6776", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5da81f83-662a-4f9b-9856-d1874e273652	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10538.pdf	Invoice_10538.pdf	finance	{"size_bytes": 1494, "content_hash": "740573194016f4adacd3cf5bfaae7399dd9bc46efa898f4e12a8a09dbda3ac3d", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
fbee56dc-b49b-4fe7-a6da-e2d6ca608022	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10590.pdf	Invoice_10590.pdf	finance	{"size_bytes": 1508, "content_hash": "9701af41d55c85101300b4fa28e9eaa0e8b6f67d9f0d014e4a287183d11e8c62", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
f97283da-815c-4ed6-b9c0-eac4b72ca8d0	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10604.pdf	Invoice_10604.pdf	finance	{"size_bytes": 1505, "content_hash": "08fcfc4605c0221dfb0c8649d41c65bafc1426347e7af55c894b9fb60ea0eb2c", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
c81e8634-ca8c-48b3-816d-67cb1380e7e4	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10616.pdf	Invoice_10616.pdf	finance	{"size_bytes": 1616, "content_hash": "0e259dae6fd7dc3f11f3d02ac6a275d4b8890c2ba2f40efabd1bf2ffc53feccf", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
5da00ffb-c155-4122-b6c5-9fac24a36950	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10629.pdf	Invoice_10629.pdf	finance	{"size_bytes": 1524, "content_hash": "cefda7524944d166f42186982847b46e7a9e8cc2817280187d49cd90bd2fc1fe", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
51088d2c-1257-4f96-ad28-120a9556b2f3	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10631.pdf	Invoice_10631.pdf	finance	{"size_bytes": 1447, "content_hash": "08fbff8f22e2341c4c8be1706367e7de2eeb6876f886bfb27056f0ac03dd4701", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
bc5f3dc1-efbb-41b3-9a01-1a2baa61f6b1	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10690.pdf	Invoice_10690.pdf	finance	{"size_bytes": 1521, "content_hash": "fab8475ccd501b2acb8d43c5bbe8b761047ebc895e0bf3acfb83237c4afdf8fb", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
31fc6cbf-43a5-4f29-90e9-97535322f30e	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10699.pdf	Invoice_10699.pdf	finance	{"size_bytes": 1446, "content_hash": "d6511aab4344375fec0228a6d8a73ff2e8d6453dfaf1c862d72e2d62094bd40f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
c94699f4-b3e7-4403-ac6f-b7fcd752f30f	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10705.pdf	Invoice_10705.pdf	finance	{"size_bytes": 1516, "content_hash": "feeafde6ec88c219f00db78a2d3b2e16108fcaaaa468a95e805b531f30585c3a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
a791f729-ab44-4457-88d2-e0f2f08e1a88	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10729.pdf	Invoice_10729.pdf	finance	{"size_bytes": 1557, "content_hash": "953e1c7e0bbffb3792b98cf407cd26d4660c60bd902e8a6ae1974268d0bc815c", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
7d35b118-bf0a-467d-a5d0-3f38ae1c7fd5	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10733.pdf	Invoice_10733.pdf	finance	{"size_bytes": 1549, "content_hash": "2afb7bed4fa87161fb2de1c33dd6031e52e2e0eaa54a0dda68ea6c4ea9a52886", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
97ae01cd-20f7-437a-b1c5-a17edfd20a56	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10760.pdf	Invoice_10760.pdf	finance	{"size_bytes": 1563, "content_hash": "3b5f6b54bb070ee95ab345c9ada3ea86663d2b9ee2476a9e687d3b2f5fe8a021", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
ecc53eea-5dda-4a7b-8278-035b376396c9	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10782.pdf	Invoice_10782.pdf	finance	{"size_bytes": 1452, "content_hash": "76ce4f9b32ccae2c972c776dbacb9a9f4862f502f5bb329eef53b337949d1e0a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
fac22f2b-3ee4-4460-bf74-921fbf24dc80	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10792.pdf	Invoice_10792.pdf	finance	{"size_bytes": 1550, "content_hash": "e5bc28325aa6f3e6d995ced05a6b664a8ad979958d16500cd822d47ca42e9312", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4706a85e-0de5-40d2-b12e-9a53ba3a4423	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10799.pdf	Invoice_10799.pdf	finance	{"size_bytes": 1556, "content_hash": "112af26ff673fe7e0f7d9ce3e7ec021c0f4192849fd7fe793aaa7bc8db9f8bd4", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4fd1ec94-2202-484a-9254-4f7b1175468f	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10806.pdf	Invoice_10806.pdf	finance	{"size_bytes": 1558, "content_hash": "666c8461f44bbe8f8f92e4a59e3844b644ef6f101897a9c2bdb334f815ac7764", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
26954831-6596-4540-8622-87c071a63567	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10856.pdf	Invoice_10856.pdf	finance	{"size_bytes": 1507, "content_hash": "642d9e8c63c9b67bf31bb79702844490d01db493cc140c951a6c1a5bf7b1e463", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
d758b3ca-d317-4aa1-b7e3-76077be1d355	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10868.pdf	Invoice_10868.pdf	finance	{"size_bytes": 1556, "content_hash": "926eee550ba25201c7bc44afd98c2f83c2ba5170ba63b283cee3e726335cb0a0", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
f079d1a1-8dc1-4cc6-a71b-bfd2cf23889e	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10884.pdf	Invoice_10884.pdf	finance	{"size_bytes": 1574, "content_hash": "04e0dc5ef8c00e313a75eb4d9a7c249bf3d57fab191da6dbe4871075192c8527", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
e16a97c8-f8e1-4d6a-9b18-96ce5ef44136	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10897.pdf	Invoice_10897.pdf	finance	{"size_bytes": 1522, "content_hash": "75e2e9941238fb226dc7095c93d455a089b920ca91dbae6832695ce2eed8e03a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4a0cb2b0-c0be-411e-a281-e01bd8ede6a2	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10930.pdf	Invoice_10930.pdf	finance	{"size_bytes": 1623, "content_hash": "0295fa6f595c94d7dee3849a846e8f39231675357db64945cc0c37b93437f9d0", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
ac292aca-f0d3-4c0c-a4d7-ebd1166a8152	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10933.pdf	Invoice_10933.pdf	finance	{"size_bytes": 1491, "content_hash": "450ce5548cfb2ae8e25059e4247ea592e5f0f387080fffec169c460bdef6c95a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4e9b5ad3-6c6b-48b4-b52f-ff35ee653e6c	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10968.pdf	Invoice_10968.pdf	finance	{"size_bytes": 1569, "content_hash": "ddd9644498ee511851cbdf215bb1680f2db69e178e4bc9ce95afce64ae094b72", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4e2e07d3-fcd1-491f-83f4-bf3a1ac848fa	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_10999.pdf	Invoice_10999.pdf	finance	{"size_bytes": 1594, "content_hash": "9bb45b4cddad802df7f811ed7c29c63e7b7914b14bffbb0220bbbe9ebd994649", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
ddade437-e9e0-4464-b8bf-e521679aa779	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11024.pdf	Invoice_11024.pdf	finance	{"size_bytes": 1621, "content_hash": "d1b20086b8a1fe02a9806ce9883c8df40933bc4842d0e03e77ce73b68c4c70ed", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
633f35a6-1661-404b-9d19-df4494a1664a	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11031.pdf	Invoice_11031.pdf	finance	{"size_bytes": 1653, "content_hash": "b661c0df1fa1191471ff401679c613d6caf4ff86a35fbd24bbe3f8f2c6d5f980", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
870c74ad-80fc-4f0f-a1a2-01a3cac03ad0	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11039.pdf	Invoice_11039.pdf	finance	{"size_bytes": 1613, "content_hash": "4d640de33de3d617e4a02a08cc7f3acec9d020fd57527930d9b3b4d88cd5e3b5", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
bcefd9e7-e9f6-4983-884a-d74dce73d4c7	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11059.pdf	Invoice_11059.pdf	finance	{"size_bytes": 1548, "content_hash": "b554f29e68ec8d6387b83082f3c503b0f6e59fbe335b0a32e398f78e5faafdfe", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4df1b598-e2c8-46f7-a44c-8ddedf97f573	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11064.pdf	Invoice_11064.pdf	finance	{"size_bytes": 1672, "content_hash": "6f1dbf11508b57561c611be939238b4c5be953d0a229bac96047d8cc736643e3", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
50a003d4-3dfb-4ade-a980-b7816e2bea8e	rag_document	active-dataset://Finance/Invoices (50 Sample only)/Invoice_11065.pdf	Invoice_11065.pdf	finance	{"size_bytes": 1514, "content_hash": "7c29b499740933869fa6c8f0a5726e392838c1f764c4d76ea6934f04d410910f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
1437f433-be2b-4443-8d91-9ee00d400cc4	rag_document	active-dataset://HR/Employee CV/10_Natalie_Gardner_CV.docx	10_Natalie_Gardner_CV.docx	hr	{"size_bytes": 35649, "content_hash": "82482842baded0ad2c2e66561123ebfc74d12deadc1e9689db29b6ba0ae4fb96", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
29e2a0a0-9b43-4347-8eb1-648cd2050006	rag_document	active-dataset://HR/Employee CV/11_Anna_Hall_CV.pdf	11_Anna_Hall_CV.pdf	hr	{"size_bytes": 1552, "content_hash": "202e6eb098276d75a9de295321213d2f0d6bd66a9a134e497f2aa484f1aa30cb", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
1075c83d-a1b6-4b5d-b2f0-11e2302dbac2	rag_document	active-dataset://HR/Employee CV/12_Mike_Miles_CV.docx	12_Mike_Miles_CV.docx	hr	{"size_bytes": 35630, "content_hash": "01719ad5f9bb87ea9e03ef1fd66f4fe604d8b8eee99010bb7f8064caa7482021", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
331c39a4-0e8e-4e5b-8982-8889d58be862	rag_document	active-dataset://HR/Employee CV/13_Kevin_Pacheco_CV.docx	13_Kevin_Pacheco_CV.docx	hr	{"size_bytes": 35645, "content_hash": "556f0b03f99add3b0e1ae125a2b0b8880900fd01f185499a895bca3c7adaf7c8", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
277b30e9-2589-4d29-9d61-2d53058a0c87	rag_document	active-dataset://HR/Employee CV/14_Christopher_Henderson_CV.docx	14_Christopher_Henderson_CV.docx	hr	{"size_bytes": 35639, "content_hash": "bec754dfd4a6f6120051a347831428bc33538c24f25163be9c420a160b21a25e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
424c3ab6-5452-4546-be17-329e37b902d2	rag_document	active-dataset://HR/Employee CV/15_Tina_Rogers_CV.docx	15_Tina_Rogers_CV.docx	hr	{"size_bytes": 35633, "content_hash": "c439aaed813348214934678c6a2ed90bfa6a7cdfdeddde1e68c17b1489b52fc7", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
ec4f179d-e45b-4c78-afee-0c6840245b73	rag_document	active-dataset://HR/Employee CV/16_Ian_Cooper_CV.pdf	16_Ian_Cooper_CV.pdf	hr	{"size_bytes": 1550, "content_hash": "7b9d00fb11748629126b4cb36ecc7e64172398f81ba1e8063c2f648911935f68", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
a05887da-e373-48e3-a7af-094a58abe65d	rag_document	active-dataset://HR/Employee CV/17_Nicholas_Herrera_CV.pdf	17_Nicholas_Herrera_CV.pdf	hr	{"size_bytes": 1567, "content_hash": "62b2fbeadf60441c2bd503726808d37e372ec6968202be5b3fcf335380b666b6", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
28f8b6c7-e998-4701-af14-11b2a131a37a	rag_document	active-dataset://HR/Employee CV/18_Elaine_Fuller_CV.docx	18_Elaine_Fuller_CV.docx	hr	{"size_bytes": 35636, "content_hash": "b1a1e08df32dacba2664db7e3dae01a184973b2abf027029de5c7495f15dfd22", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
30136917-784b-424a-b442-96236fea4e3d	rag_document	active-dataset://HR/Employee CV/19_Michael_Williams_CV.docx	19_Michael_Williams_CV.docx	hr	{"size_bytes": 35645, "content_hash": "e4ed8edeec3ded7296487e4872db0fcd12897e90f6744c4eb6a286ab5785ae06", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
a901d385-2bf8-4a7e-8825-63303a213b40	rag_document	active-dataset://HR/Employee CV/1_Nancy_Davolio_CV.docx	1_Nancy_Davolio_CV.docx	hr	{"size_bytes": 35645, "content_hash": "927e5b52e69c632fe8522878a26b2369643393369587edcafed5e5e405abb459", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
e9a51247-b8ae-4e1b-9eff-d0cc88c7c8a8	rag_document	active-dataset://HR/Employee CV/20_Victoria_Wyatt_CV.pdf	20_Victoria_Wyatt_CV.pdf	hr	{"size_bytes": 1567, "content_hash": "09347ed4ba1334c87b53153440056b1f464c23d58199c3883491ca39a5feba9e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
1ebbe1f2-1690-4cdc-9428-e69fc35c9dfa	rag_document	active-dataset://HR/Employee CV/21_Jody_Flowers_CV.docx	21_Jody_Flowers_CV.docx	hr	{"size_bytes": 35635, "content_hash": "5f985b0319698ea983617fb79e5796768d15d4f608a5a9effa8083222e9b3b3e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
35b1aba1-8b1f-442c-8356-29b4d597044c	rag_document	active-dataset://HR/Employee CV/22_Christine_Adams_CV.docx	22_Christine_Adams_CV.docx	hr	{"size_bytes": 35646, "content_hash": "ab25aab0da4535f395470e83464f3286c4cdab6042c97230f71f954ec10921d1", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
dc183fbe-b81d-4fd5-bd75-68d24daf242f	rag_document	active-dataset://HR/Employee CV/23_Christopher_Daniel_CV.pdf	23_Christopher_Daniel_CV.pdf	hr	{"size_bytes": 1571, "content_hash": "e3defce25fdca27dc3331e46ce73e8772d650e17b049d3112321317ccfe54bb9", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
e37defe3-5003-443e-95eb-c71139337a8f	rag_document	active-dataset://HR/Employee CV/24_Devin_Schaefer_CV.docx	24_Devin_Schaefer_CV.docx	hr	{"size_bytes": 35644, "content_hash": "65917cd43cb87d81702b975ed0373720e3860e1524823267db17c99a5f82435f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
fcdd9140-d16f-4a5f-b8da-991f9d460f6f	rag_document	active-dataset://HR/Employee CV/25_Ryan_Parsons_CV.docx	25_Ryan_Parsons_CV.docx	hr	{"size_bytes": 35645, "content_hash": "97371f1d4b489c078dc16c03a58eca365d0134197ace4429ce5961a3f16f27db", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
6484ed87-e2c0-4bef-ac08-5762f7eef332	rag_document	active-dataset://HR/Employee CV/26_Robert_Morales_CV.docx	26_Robert_Morales_CV.docx	hr	{"size_bytes": 35639, "content_hash": "34ce640f9801646872c50ebedad6cf5f751dd54e884093f6b9cd6de24e705ed6", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
10dfd48e-b7e6-4016-92eb-04c0978182ee	rag_document	active-dataset://HR/Employee CV/27_Tommy_Walter_CV.pdf	27_Tommy_Walter_CV.pdf	hr	{"size_bytes": 1568, "content_hash": "2eb4e37060b0be83c55d92061beffa0e4524df2e0f9fd4d9ff63da666b59d1be", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
eef04cef-c16f-43cb-a975-ce1944eede60	rag_document	active-dataset://HR/Employee CV/28_Jonathan_Wilkerson_CV.docx	28_Jonathan_Wilkerson_CV.docx	hr	{"size_bytes": 35645, "content_hash": "c628e2191bc0aa445b8942a1a9f6820a789a77f5e105d3a9ebfe54c87b8a0b91", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
bd41a5b6-1eaa-42cd-9d82-f05f91be5f9f	rag_document	active-dataset://HR/Employee CV/29_Charles_Mcgee_CV.docx	29_Charles_Mcgee_CV.docx	hr	{"size_bytes": 35647, "content_hash": "93c1043ac2d6ad4d56f5f03c1c9894a66c15ab00e4ea1f1bdc28239e1a61f44e", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
f2a8d387-d769-4305-9f72-d9aca76257c8	rag_document	active-dataset://HR/Employee CV/2_Andrew_Fuller_CV.docx	2_Andrew_Fuller_CV.docx	hr	{"size_bytes": 35633, "content_hash": "b01f9bb31a12b0b4eef02bcd88d7a2ada885c83bbdd40a0480ce24b0a95e0c35", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
11914569-d2b6-445c-8ad2-962c18a08407	rag_document	active-dataset://HR/Employee CV/30_Jeffrey_Silva_CV.docx	30_Jeffrey_Silva_CV.docx	hr	{"size_bytes": 35641, "content_hash": "a5280d77e8842f4fcc8f58737386c8e9fe1767721a368f31de014ee946c9076a", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
4dad2870-da59-4236-920f-1ba91a503918	rag_document	active-dataset://HR/Employee CV/31_Yolanda_Hicks_CV.docx	31_Yolanda_Hicks_CV.docx	hr	{"size_bytes": 35644, "content_hash": "4b1508cadf752a70ac248a838606ff7e6458864639cbcaa30b9a1c7d3911accd", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
83469ea3-fc87-4b96-83cf-0c53bb87324b	rag_document	active-dataset://HR/Employee CV/32_Shannon_Hernandez_CV.docx	32_Shannon_Hernandez_CV.docx	hr	{"size_bytes": 35652, "content_hash": "791ba1bc616a8ebaa278d3110975aee74e00f67d049181b8b9c2cd3a993e94b5", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
f922fc6f-7493-4b10-9c50-5bc072e6a28b	rag_document	active-dataset://HR/Employee CV/33_Jay_Brown_CV.pdf	33_Jay_Brown_CV.pdf	hr	{"size_bytes": 1559, "content_hash": "db928d800f5a5dfc832cab1c61962bbde76d7fd3b145b132c8ef172a0c12cd37", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
6adeda06-ae81-46b4-8278-19376bba43e2	rag_document	active-dataset://HR/Employee CV/34_John_King_CV.pdf	34_John_King_CV.pdf	hr	{"size_bytes": 1569, "content_hash": "2d05f1a489a28756b10ceef06c00ec8073c20701ce97c0bd7a5ca466d9bf90e2", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
6f5d5dcc-1e2f-49a9-b6d0-cdc31e910f67	rag_document	active-dataset://HR/Employee CV/35_Ashley_Dyer_CV.docx	35_Ashley_Dyer_CV.docx	hr	{"size_bytes": 35639, "content_hash": "a373c6842d65466fb3f0a67e205c2ad14f428267d684e21f533b098df7a8a133", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
00ad9024-4972-455f-bf4f-286068fb1b54	rag_document	active-dataset://HR/Employee CV/36_Gerald_Carter_CV.pdf	36_Gerald_Carter_CV.pdf	hr	{"size_bytes": 1567, "content_hash": "900a983ec87948507242f0b01a8d801b62de9838d54d49462591beb61d80f5eb", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
b93c7843-94fa-4879-998a-f44e366407d7	rag_document	active-dataset://HR/Employee CV/37_Troy_Liu_CV.pdf	37_Troy_Liu_CV.pdf	hr	{"size_bytes": 1556, "content_hash": "c43ed2d42f4bc1eabe2a29f6af7b17774ebedfca4e6a5674bc678121e1e9ba99", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
0b53d939-7e88-4966-9120-7d6a4b8975d8	rag_document	active-dataset://HR/Employee CV/38_Dr._Jordan_Rodriguez_CV.docx	38_Dr._Jordan_Rodriguez_CV.docx	hr	{"size_bytes": 35645, "content_hash": "fc8e72dfd950a6687ef3459c90352e07d92d0d7cc5e7e903d49f294c73c782b7", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
64a41e64-abb0-4082-9621-9e02c7e61e5c	rag_document	active-dataset://HR/Employee CV/3_Janet_Leverling_CV.pdf	3_Janet_Leverling_CV.pdf	hr	{"size_bytes": 1563, "content_hash": "9a92366b3e3ce556b55c91e37eac883a8932c2dd111fb87b19680218487509dd", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
9eb85e5a-3ba9-443e-9abe-00267ac9fd50	rag_document	active-dataset://HR/Employee CV/4_Margaret_Peacock_CV.pdf	4_Margaret_Peacock_CV.pdf	hr	{"size_bytes": 1558, "content_hash": "621c5a5b7e51850cc86f04de8c02fee60f3d1456c695d3045ce6a9920423fb3f", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
988bbfa6-8b0f-4a28-9dd9-ce6873d51015	rag_document	active-dataset://HR/Employee CV/5_Steven_Buchanan_CV.docx	5_Steven_Buchanan_CV.docx	hr	{"size_bytes": 35632, "content_hash": "0377568cac89ec9a745776c3f74fa203bde38d12cb7d4ad35d76620addbdc7fe", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
052bfccd-d41f-43b2-959d-1f98b41f46f1	rag_document	active-dataset://HR/Employee CV/6_Michael_Suyama_CV.pdf	6_Michael_Suyama_CV.pdf	hr	{"size_bytes": 1565, "content_hash": "ac6ecdb80ad9a00f213ead7d7506b6f80a69c705079bfa154b8a29400424ff79", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
3e5a551e-7459-4a00-a94c-08c5f1abae4e	rag_document	active-dataset://HR/Employee CV/7_Robert_King_CV.pdf	7_Robert_King_CV.pdf	hr	{"size_bytes": 1565, "content_hash": "e889f4b3936cd616ebd03677ffa75668d514a87c993626ef80213a80a4b9da17", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
648cd122-20cc-4f51-a837-9df5e4728e37	rag_document	active-dataset://HR/Employee CV/8_Laura_Callahan_CV.docx	8_Laura_Callahan_CV.docx	hr	{"size_bytes": 35633, "content_hash": "ae8841c076c80a8c6d4c4fe840616908f99d8b683bd0373dba94867ac7f2e1a7", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
148f608a-d745-478a-b8c9-ba938a8c2229	rag_document	active-dataset://HR/Employee CV/9_Anne_Dodsworth_CV.docx	9_Anne_Dodsworth_CV.docx	hr	{"size_bytes": 35640, "content_hash": "87ec8ef6c879f18bcb2b67a9dda39fa4dfe12ff7338d3f2f1ed7a1c12ccc3108", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
a9d1de52-30ed-4c40-bd57-8332891090e7	structured_table	active-dataset://HR/Employee HR Records.xlsx	Employee HR Records.xlsx	hr	{"size_bytes": 12104, "content_hash": "d236bae0d8474a63cfab5de9f932030e2c862984fb5234df7bcfcb4c4fd7e6c4", "active_dataset_id": "active"}	t	2026-07-20 17:59:16.167083+00
\.


--
-- Data for Name: structured_file_server_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_categories (permission_scope_key, categoryid, categoryname, description) FROM stdin;
file_server	1	Beverages	Soft drinks, coffees, teas, beers, and ales
file_server	2	Condiments	Sweet and savory sauces, relishes, spreads, and seasonings
file_server	3	Confections	Desserts, candies, and sweet breads
file_server	4	Dairy Products	Cheeses
file_server	5	Grains & Cereals	Breads, crackers, pasta, and cereal
file_server	6	Meat & Poultry	Prepared meats
file_server	7	Produce	Dried fruit and bean curd
file_server	8	Seafood	Seaweed and fish
\.


--
-- Data for Name: structured_file_server_customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_customers (permission_scope_key, customerid, companyname, contactname, contacttitle, city, country) FROM stdin;
file_server	ALFKI	Alfreds Futterkiste	Maria Anders	Sales Representative	Berlin	Germany
file_server	ANATR	Ana Trujillo Emparedados y helados	Ana Trujillo	Owner	Mexico City	Mexico
file_server	ANTON	Antonio Moreno Taquería	Antonio Moreno	Owner	Mexico City	Mexico
file_server	AROUT	Around the Horn	Thomas Hardy	Sales Representative	London	UK
file_server	BERGS	Berglunds snabbköp	Christina Berglund	Order Administrator	Luleå	Sweden
file_server	BLAUS	Blauer See Delikatessen	Hanna Moos	Sales Representative	Mannheim	Germany
file_server	BLONP	Blondesddsl père et fils	Frédérique Citeaux	Marketing Manager	Strasbourg	France
file_server	BOLID	Bólido Comidas preparadas	Martín Sommer	Owner	Madrid	Spain
file_server	BONAP	Bon app'	Laurence Lebihan	Owner	Marseille	France
file_server	BOTTM	Bottom-Dollar Markets	Elizabeth Lincoln	Accounting Manager	Tsawassen	Canada
file_server	BSBEV	B's Beverages	Victoria Ashworth	Sales Representative	London	UK
file_server	CACTU	Cactus Comidas para llevar	Patricio Simpson	Sales Agent	Buenos Aires	Argentina
file_server	CENTC	Centro comercial Moctezuma	Francisco Chang	Marketing Manager	Mexico City	Mexico
file_server	CHOPS	Chop-suey Chinese	Yang Wang	Owner	Bern	Switzerland
file_server	COMMI	Comércio Mineiro	Pedro Afonso	Sales Associate	Sao Paulo	Brazil
file_server	CONSH	Consolidated Holdings	Elizabeth Brown	Sales Representative	London	UK
file_server	DRACD	Drachenblut Delikatessen	Sven Ottlieb	Order Administrator	Aachen	Germany
file_server	DUMON	Du monde entier	Janine Labrune	Owner	Nantes	France
file_server	EASTC	Eastern Connection	Ann Devon	Sales Agent	London	UK
file_server	ERNSH	Ernst Handel	Roland Mendel	Sales Manager	Graz	Austria
file_server	FAMIA	Familia Arquibaldo	Aria Cruz	Marketing Assistant	Sao Paulo	Brazil
file_server	FISSA	FISSA Fabrica Inter. Salchichas S.A.	Diego Roel	Accounting Manager	Madrid	Spain
file_server	FOLIG	Folies gourmandes	Martine Rancé	Assistant Sales Agent	Lille	France
file_server	FOLKO	Folk och fä HB	Maria Larsson	Owner	Bräcke	Sweden
file_server	FRANK	Frankenversand	Peter Franken	Marketing Manager	München	Germany
file_server	FRANR	France restauration	Carine Schmitt	Marketing Manager	Nantes	France
file_server	FRANS	Franchi S.p.A.	Paolo Accorti	Sales Representative	Torino	Italy
file_server	FURIB	Furia Bacalhau e Frutos do Mar	Lino Rodriguez	Sales Manager	Lisboa	Portugal
file_server	GALED	Galería del gastrónomo	Eduardo Saavedra	Marketing Manager	Barcelona	Spain
file_server	GODOS	Godos Cocina Típica	José Pedro Freyre	Sales Manager	Sevilla	Spain
file_server	GOURL	Gourmet Lanchonetes	André Fonseca	Sales Associate	Campinas	Brazil
file_server	GREAL	Great Lakes Food Market	Howard Snyder	Marketing Manager	Eugene	USA
file_server	GROSR	GROSELLA-Restaurante	Manuel Pereira	Owner	Caracas	Venezuela
file_server	HANAR	Hanari Carnes	Mario Pontes	Accounting Manager	Rio de Janeiro	Brazil
file_server	HILAA	HILARION-Abastos	Carlos Hernández	Sales Representative	San Cristóbal	Venezuela
file_server	HUNGC	Hungry Coyote Import Store	Yoshi Latimer	Sales Representative	Elgin	USA
file_server	HUNGO	Hungry Owl All-Night Grocers	Patricia McKenna	Sales Associate	Cork	Ireland
file_server	ISLAT	Island Trading	Helen Bennett	Marketing Manager	Cowes	UK
file_server	KOENE	Königlich Essen	Philip Cramer	Sales Associate	Brandenburg	Germany
file_server	LACOR	La corne d'abondance	Daniel Tonini	Sales Representative	Versailles	France
file_server	LAMAI	La maison d'Asie	Annette Roulet	Sales Manager	Toulouse	France
file_server	LAUGB	Laughing Bacchus Wine Cellars	Yoshi Tannamuri	Marketing Assistant	Vancouver	Canada
file_server	LAZYK	Lazy K Kountry Store	John Steel	Marketing Manager	Walla Walla	USA
file_server	LEHMS	Lehmanns Marktstand	Renate Messner	Sales Representative	Frankfurt a.M.	Germany
file_server	LETSS	Let's Stop N Shop	Jaime Yorres	Owner	San Francisco	USA
file_server	LILAS	LILA-Supermercado	Carlos González	Accounting Manager	Barquisimeto	Venezuela
file_server	LINOD	LINO-Delicateses	Felipe Izquierdo	Owner	I. de Margarita	Venezuela
file_server	LONEP	Lonesome Pine Restaurant	Fran Wilson	Sales Manager	Portland	USA
file_server	MAGAA	Magazzini Alimentari Riuniti	Giovanni Rovelli	Marketing Manager	Bergamo	Italy
file_server	MAISD	Maison Dewey	Catherine Dewey	Sales Agent	Bruxelles	Belgium
file_server	MEREP	Mère Paillarde	Jean Fresnière	Marketing Assistant	Montréal	Canada
file_server	MORGK	Morgenstern Gesundkost	Alexander Feuer	Marketing Assistant	Leipzig	Germany
file_server	NORTS	North/South	Simon Crowther	Sales Associate	London	UK
file_server	OCEAN	Océano Atlántico Ltda.	Yvonne Moncada	Sales Agent	Buenos Aires	Argentina
file_server	OLDWO	Old World Delicatessen	Rene Phillips	Sales Representative	Anchorage	USA
file_server	OTTIK	Ottilies Käseladen	Henriette Pfalzheim	Owner	Köln	Germany
file_server	PARIS	Paris spécialités	Marie Bertrand	Owner	Paris	France
file_server	PERIC	Pericles Comidas clásicas	Guillermo Fernández	Sales Representative	Mexico City	Mexico
file_server	PICCO	Piccolo und mehr	Georg Pipps	Sales Manager	Salzburg	Austria
file_server	PRINI	Princesa Isabel Vinhos	Isabel de Castro	Sales Representative	Lisboa	Portugal
file_server	QUEDE	Que Delícia	Bernardo Batista	Accounting Manager	Rio de Janeiro	Brazil
file_server	QUEEN	Queen Cozinha	Lúcia Carvalho	Marketing Assistant	Sao Paulo	Brazil
file_server	QUICK	QUICK-Stop	Horst Kloss	Accounting Manager	Cunewalde	Germany
file_server	RANCH	Rancho grande	Sergio Gutiérrez	Sales Representative	Buenos Aires	Argentina
file_server	RATTC	Rattlesnake Canyon Grocery	Paula Wilson	Assistant Sales Representative	Albuquerque	USA
file_server	REGGC	Reggiani Caseifici	Maurizio Moroni	Sales Associate	Reggio Emilia	Italy
file_server	RICAR	Ricardo Adocicados	Janete Limeira	Assistant Sales Agent	Rio de Janeiro	Brazil
file_server	RICSU	Richter Supermarkt	Michael Holz	Sales Manager	Genève	Switzerland
file_server	ROMEY	Romero y tomillo	Alejandra Camino	Accounting Manager	Madrid	Spain
file_server	SANTG	Santé Gourmet	Jonas Bergulfsen	Owner	Stavern	Norway
file_server	SAVEA	Save-a-lot Markets	Jose Pavarotti	Sales Representative	Boise	USA
file_server	SEVES	Seven Seas Imports	Hari Kumar	Sales Manager	London	UK
file_server	SIMOB	Simons bistro	Jytte Petersen	Owner	Kobenhavn	Denmark
file_server	SPECD	Spécialités du monde	Dominique Perrier	Marketing Manager	Paris	France
file_server	SPLIR	Split Rail Beer & Ale	Art Braunschweiger	Sales Manager	Lander	USA
file_server	SUPRD	Suprêmes délices	Pascale Cartrain	Accounting Manager	Charleroi	Belgium
file_server	THEBI	The Big Cheese	Liz Nixon	Marketing Manager	Portland	USA
file_server	THECR	The Cracker Box	Liu Wong	Marketing Assistant	Butte	USA
file_server	TOMSP	Toms Spezialitäten	Karin Josephs	Marketing Manager	Münster	Germany
file_server	TORTU	Tortuga Restaurante	Miguel Angel Paolino	Owner	Mexico City	Mexico
file_server	TRADH	Tradição Hipermercados	Anabela Domingues	Sales Representative	Sao Paulo	Brazil
file_server	TRAIH	Trail's Head Gourmet Provisioners	Helvetius Nagy	Sales Associate	Kirkland	USA
file_server	VAFFE	Vaffeljernet	Palle Ibsen	Sales Manager	Århus	Denmark
file_server	VICTE	Victuailles en stock	Mary Saveley	Sales Agent	Lyon	France
file_server	VINET	Vins et alcools Chevalier	Paul Henriot	Accounting Manager	Reims	France
file_server	WANDK	Die Wandernde Kuh	Rita Müller	Sales Representative	Stuttgart	Germany
file_server	WARTH	Wartian Herkku	Pirkko Koskitalo	Accounting Manager	Oulu	Finland
file_server	WELLI	Wellington Importadora	Paula Parente	Sales Manager	Resende	Brazil
file_server	WHITC	White Clover Markets	Karl Jablonski	Owner	Seattle	USA
file_server	WILMK	Wilman Kala	Matti Karttunen	Owner/Marketing Assistant	Helsinki	Finland
file_server	WOLZA	Wolski  Zajazd	Zbyszek Piestrzeniewicz	Owner	Warszawa	Poland
\.


--
-- Data for Name: structured_file_server_order_details_2017; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_order_details_2017 (permission_scope_key, orderid, productid, orderprice, quantity, discount) FROM stdin;
file_server	10248	11	14	12	0
file_server	10248	42	9.8	10	0
file_server	10248	72	34.8	5	0
file_server	10249	14	18.6	9	0
file_server	10249	51	42.4	40	0
file_server	10250	41	7.7	10	0
file_server	10250	51	42.4	35	0.15
file_server	10250	65	16.8	15	0.15
file_server	10251	22	16.8	6	0.05
file_server	10251	57	15.6	15	0.05
file_server	10251	65	16.8	20	0
file_server	10252	20	64.8	40	0.05
file_server	10252	33	2	25	0.05
file_server	10252	60	27.2	40	0
file_server	10253	31	10	20	0
file_server	10253	39	14.4	42	0
file_server	10253	49	16	40	0
file_server	10254	24	3.6	15	0.15
file_server	10254	55	19.2	21	0.15
file_server	10254	74	8	21	0
file_server	10255	2	15.2	20	0
file_server	10255	16	13.9	35	0
file_server	10255	36	15.2	25	0
file_server	10255	59	44	30	0
file_server	10256	53	26.2	15	0
file_server	10256	77	10.4	12	0
file_server	10257	27	35.1	25	0
file_server	10257	39	14.4	6	0
file_server	10257	77	10.4	15	0
file_server	10258	2	15.2	50	0.2
file_server	10258	5	17	65	0.2
file_server	10258	32	25.6	6	0.2
file_server	10259	21	8	10	0
file_server	10259	37	20.8	1	0
file_server	10260	41	7.7	16	0.25
file_server	10260	57	15.6	50	0
file_server	10260	62	39.4	15	0.25
file_server	10260	70	12	21	0.25
file_server	10261	21	8	20	0
file_server	10261	35	14.4	20	0
file_server	10262	5	17	12	0.2
file_server	10262	7	24	15	0
file_server	10262	56	30.4	2	0
file_server	10263	16	13.9	60	0.25
file_server	10263	24	3.6	28	0
file_server	10263	30	20.7	60	0.25
file_server	10263	74	8	36	0.25
file_server	10264	2	15.2	35	0
file_server	10264	41	7.7	25	0.15
file_server	10265	17	31.2	30	0
file_server	10265	70	12	20	0
file_server	10266	12	30.4	12	0.05
file_server	10267	40	14.7	50	0
file_server	10267	59	44	70	0.15
file_server	10267	76	14.4	15	0.15
file_server	10268	29	99	10	0
file_server	10268	72	27.8	4	0
file_server	10269	33	2	60	0.05
file_server	10269	72	27.8	20	0.05
file_server	10270	36	15.2	30	0
file_server	10270	43	36.8	25	0
file_server	10271	33	2	24	0
file_server	10272	20	64.8	6	0
file_server	10272	31	10	40	0
file_server	10272	72	27.8	24	0
file_server	10273	10	24.8	24	0.05
file_server	10273	31	10	15	0.05
file_server	10273	33	2	20	0
file_server	10273	40	14.7	60	0.05
file_server	10273	76	14.4	33	0.05
file_server	10274	71	17.2	20	0
file_server	10274	72	27.8	7	0
file_server	10275	24	3.6	12	0.05
file_server	10275	59	44	6	0.05
file_server	10276	10	24.8	15	0
file_server	10276	13	4.8	10	0
file_server	10277	28	36.4	20	0
file_server	10277	62	39.4	12	0
file_server	10278	44	15.5	16	0
file_server	10278	59	44	15	0
file_server	10278	63	35.1	8	0
file_server	10278	73	12	25	0
file_server	10279	17	31.2	15	0.25
file_server	10280	24	3.6	12	0
file_server	10280	55	19.2	20	0
file_server	10280	75	6.2	30	0
file_server	10281	19	7.3	1	0
file_server	10281	24	3.6	6	0
file_server	10281	35	14.4	4	0
file_server	10282	30	20.7	6	0
file_server	10282	57	15.6	2	0
file_server	10283	15	12.4	20	0
file_server	10283	19	7.3	18	0
file_server	10283	60	27.2	35	0
file_server	10283	72	27.8	3	0
file_server	10284	27	35.1	15	0.25
file_server	10284	44	15.5	21	0
file_server	10284	60	27.2	20	0.25
file_server	10284	67	11.2	5	0.25
file_server	10285	1	14.4	45	0.2
file_server	10285	40	14.7	40	0.2
file_server	10285	53	26.2	36	0.2
file_server	10286	35	14.4	100	0
file_server	10286	62	39.4	40	0
file_server	10287	16	13.9	40	0.15
file_server	10287	34	11.2	20	0
file_server	10287	46	9.6	15	0.15
file_server	10288	54	5.9	10	0.1
file_server	10288	68	10	3	0.1
file_server	10289	3	8	30	0
file_server	10289	64	26.6	9	0
file_server	10290	5	17	20	0
file_server	10290	29	99	15	0
file_server	10290	49	16	15	0
file_server	10290	77	10.4	10	0
file_server	10291	13	4.8	20	0.1
file_server	10291	44	15.5	24	0.1
file_server	10291	51	42.4	2	0.1
file_server	10292	20	64.8	20	0
file_server	10293	18	50	12	0
file_server	10293	24	3.6	10	0
file_server	10293	63	35.1	5	0
file_server	10293	75	6.2	6	0
file_server	10294	1	14.4	18	0
file_server	10294	17	31.2	15	0
file_server	10294	43	36.8	15	0
file_server	10294	60	27.2	21	0
file_server	10294	75	6.2	6	0
file_server	10295	56	30.4	4	0
file_server	10296	11	16.8	12	0
file_server	10296	16	13.9	30	0
file_server	10296	69	28.8	15	0
file_server	10297	39	14.4	60	0
file_server	10297	72	27.8	20	0
file_server	10298	2	15.2	40	0
file_server	10298	36	15.2	40	0.25
file_server	10298	59	44	30	0.25
file_server	10298	62	39.4	15	0
file_server	10299	19	7.3	15	0
file_server	10299	70	12	20	0
file_server	10300	66	13.6	30	0
file_server	10300	68	10	20	0
file_server	10301	40	14.7	10	0
file_server	10301	56	30.4	20	0
file_server	10302	17	31.2	40	0
file_server	10302	28	36.4	28	0
file_server	10302	43	36.8	12	0
file_server	10303	40	14.7	40	0.1
file_server	10303	65	16.8	30	0.1
file_server	10303	68	10	15	0.1
file_server	10304	49	16	30	0
file_server	10304	59	44	10	0
file_server	10304	71	17.2	2	0
file_server	10305	18	50	25	0.1
file_server	10305	29	99	25	0.1
file_server	10305	39	14.4	30	0.1
file_server	10306	30	20.7	10	0
file_server	10306	53	26.2	10	0
file_server	10306	54	5.9	5	0
file_server	10307	62	39.4	10	0
file_server	10307	68	10	3	0
file_server	10308	69	28.8	1	0
file_server	10308	70	12	5	0
file_server	10309	4	17.6	20	0
file_server	10309	6	20	30	0
file_server	10309	42	11.2	2	0
file_server	10309	43	36.8	20	0
file_server	10309	71	17.2	3	0
file_server	10310	16	13.9	10	0
file_server	10310	62	39.4	5	0
file_server	10311	42	11.2	6	0
file_server	10311	69	28.8	7	0
file_server	10312	28	36.4	4	0
file_server	10312	43	36.8	24	0
file_server	10312	53	26.2	20	0
file_server	10312	75	6.2	10	0
file_server	10313	36	15.2	12	0
file_server	10314	32	25.6	40	0.1
file_server	10314	58	10.6	30	0.1
file_server	10314	62	39.4	25	0.1
file_server	10315	34	11.2	14	0
file_server	10315	70	12	30	0
file_server	10316	41	7.7	10	0
file_server	10316	62	39.4	70	0
file_server	10317	1	14.4	20	0
file_server	10318	41	7.7	20	0
file_server	10318	76	14.4	6	0
file_server	10319	17	31.2	8	0
file_server	10319	28	36.4	14	0
file_server	10319	76	14.4	30	0
file_server	10320	71	17.2	30	0
file_server	10321	35	14.4	10	0
file_server	10322	52	5.6	20	0
file_server	10323	15	12.4	5	0
file_server	10323	25	11.2	4	0
file_server	10323	39	14.4	4	0
file_server	10324	16	13.9	21	0.15
file_server	10324	35	14.4	70	0.15
file_server	10324	46	9.6	30	0
file_server	10324	59	44	40	0.15
file_server	10324	63	35.1	80	0.15
file_server	10325	6	20	6	0
file_server	10325	13	4.8	12	0
file_server	10325	14	18.6	9	0
file_server	10325	31	10	4	0
file_server	10325	72	27.8	40	0
file_server	10326	4	17.6	24	0
file_server	10326	57	15.6	16	0
file_server	10326	75	6.2	50	0
file_server	10327	2	15.2	25	0.2
file_server	10327	11	16.8	50	0.2
file_server	10327	30	20.7	35	0.2
file_server	10327	58	10.6	30	0.2
file_server	10328	59	44	9	0
file_server	10328	65	16.8	40	0
file_server	10328	68	10	10	0
file_server	10329	19	7.3	10	0.05
file_server	10329	30	20.7	8	0.05
file_server	10329	38	210.8	20	0.05
file_server	10329	56	30.4	12	0.05
file_server	10330	26	24.9	50	0.15
file_server	10330	72	27.8	25	0.15
file_server	10331	54	5.9	15	0
file_server	10332	18	50	40	0.2
file_server	10332	42	11.2	10	0.2
file_server	10332	47	7.6	16	0.2
file_server	10333	14	18.6	10	0
file_server	10333	21	8	10	0.1
file_server	10333	71	17.2	40	0.1
file_server	10334	52	5.6	8	0
file_server	10334	68	10	10	0
file_server	10335	2	15.2	7	0.2
file_server	10335	31	10	25	0.2
file_server	10335	32	25.6	6	0.2
file_server	10335	51	42.4	48	0.2
file_server	10336	4	17.6	18	0.1
file_server	10337	23	7.2	40	0
file_server	10337	26	24.9	24	0
file_server	10337	36	15.2	20	0
file_server	10337	37	20.8	28	0
file_server	10337	72	27.8	25	0
file_server	10338	17	31.2	20	0
file_server	10338	30	20.7	15	0
file_server	10339	4	17.6	10	0
file_server	10339	17	31.2	70	0.05
file_server	10339	62	39.4	28	0
file_server	10340	18	50	20	0.05
file_server	10340	41	7.7	12	0.05
file_server	10340	43	36.8	40	0.05
file_server	10341	33	2	8	0
file_server	10341	59	44	9	0.15
file_server	10342	2	15.2	24	0.2
file_server	10342	31	10	56	0.2
file_server	10342	36	15.2	40	0.2
file_server	10342	55	19.2	40	0.2
file_server	10343	64	26.6	50	0
file_server	10343	68	10	4	0.05
file_server	10343	76	14.4	15	0
file_server	10344	4	17.6	35	0
file_server	10344	8	32	70	0.25
file_server	10345	8	32	70	0
file_server	10345	19	7.3	80	0
file_server	10345	42	11.2	9	0
file_server	10346	17	31.2	36	0.1
file_server	10346	56	30.4	20	0
file_server	10347	25	11.2	10	0
file_server	10347	39	14.4	50	0.15
file_server	10347	40	14.7	4	0
file_server	10347	75	6.2	6	0.15
file_server	10348	1	14.4	15	0.15
file_server	10348	23	7.2	25	0
file_server	10349	54	5.9	24	0
file_server	10350	50	13	15	0.1
file_server	10350	69	28.8	18	0.1
file_server	10351	38	210.8	20	0.05
file_server	10351	41	7.7	13	0
file_server	10351	44	15.5	77	0.05
file_server	10351	65	16.8	10	0.05
file_server	10352	24	3.6	10	0
file_server	10352	54	5.9	20	0.15
file_server	10353	11	16.8	12	0.2
file_server	10353	38	210.8	50	0.2
file_server	10354	1	14.4	12	0
file_server	10354	29	99	4	0
file_server	10355	24	3.6	25	0
file_server	10355	57	15.6	25	0
file_server	10356	31	10	30	0
file_server	10356	55	19.2	12	0
file_server	10356	69	28.8	20	0
file_server	10357	10	24.8	30	0.2
file_server	10357	26	24.9	16	0
file_server	10357	60	27.2	8	0.2
file_server	10358	24	3.6	10	0.05
file_server	10358	34	11.2	10	0.05
file_server	10358	36	15.2	20	0.05
file_server	10359	16	13.9	56	0.05
file_server	10359	31	10	70	0.05
file_server	10359	60	27.2	80	0.05
file_server	10360	28	36.4	30	0
file_server	10360	29	99	35	0
file_server	10360	38	210.8	10	0
file_server	10360	49	16	35	0
file_server	10360	54	5.9	28	0
file_server	10361	39	14.4	54	0.1
file_server	10361	60	27.2	55	0.1
file_server	10362	25	11.2	50	0
file_server	10362	51	42.4	20	0
file_server	10362	54	5.9	24	0
file_server	10363	31	10	20	0
file_server	10363	75	6.2	12	0
file_server	10363	76	14.4	12	0
file_server	10364	69	28.8	30	0
file_server	10364	71	17.2	5	0
file_server	10365	11	16.8	24	0
file_server	10366	65	16.8	5	0
file_server	10366	77	10.4	5	0
file_server	10367	34	11.2	36	0
file_server	10367	54	5.9	18	0
file_server	10367	65	16.8	15	0
file_server	10367	77	10.4	7	0
file_server	10368	21	8	5	0.1
file_server	10368	28	36.4	13	0.1
file_server	10368	57	15.6	25	0
file_server	10368	64	26.6	35	0.1
\.


--
-- Data for Name: structured_file_server_order_details_2018; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_order_details_2018 (permission_scope_key, orderid, productid, orderprice, quantity, discount) FROM stdin;
file_server	10369	29	99	20	0
file_server	10369	56	30.4	18	0.25
file_server	10370	1	14.4	15	0.15
file_server	10370	64	26.6	30	0
file_server	10370	74	8	20	0.15
file_server	10371	36	15.2	6	0.2
file_server	10372	20	64.8	12	0.25
file_server	10372	38	210.8	40	0.25
file_server	10372	60	27.2	70	0.25
file_server	10372	72	27.8	42	0.25
file_server	10373	58	10.6	80	0.2
file_server	10373	71	17.2	50	0.2
file_server	10374	31	10	30	0
file_server	10374	58	10.6	15	0
file_server	10375	14	18.6	15	0
file_server	10375	54	5.9	10	0
file_server	10376	31	10	42	0.05
file_server	10377	28	36.4	20	0.15
file_server	10377	39	14.4	20	0.15
file_server	10378	71	17.2	6	0
file_server	10379	41	7.7	8	0.1
file_server	10379	63	35.1	16	0.1
file_server	10379	65	16.8	20	0.1
file_server	10380	30	20.7	18	0.1
file_server	10380	53	26.2	20	0.1
file_server	10380	60	27.2	6	0.1
file_server	10380	70	12	30	0
file_server	10381	74	8	14	0
file_server	10382	5	17	32	0
file_server	10382	18	50	9	0
file_server	10382	29	99	14	0
file_server	10382	33	2	60	0
file_server	10382	74	8	50	0
file_server	10383	13	4.8	20	0
file_server	10383	50	13	15	0
file_server	10383	56	30.4	20	0
file_server	10384	20	64.8	28	0
file_server	10384	60	27.2	15	0
file_server	10385	7	24	10	0.2
file_server	10385	60	27.2	20	0.2
file_server	10385	68	10	8	0.2
file_server	10386	24	3.6	15	0
file_server	10386	34	11.2	10	0
file_server	10387	24	3.6	15	0
file_server	10387	28	36.4	6	0
file_server	10387	59	44	12	0
file_server	10387	71	17.2	15	0
file_server	10388	45	7.6	15	0.2
file_server	10388	52	5.6	20	0.2
file_server	10388	53	26.2	40	0
file_server	10389	10	24.8	16	0
file_server	10389	55	19.2	15	0
file_server	10389	62	39.4	20	0
file_server	10389	70	12	30	0
file_server	10390	31	10	60	0.1
file_server	10390	35	14.4	40	0.1
file_server	10390	46	9.6	45	0
file_server	10390	72	27.8	24	0.1
file_server	10391	13	4.8	18	0
file_server	10392	69	28.8	50	0
file_server	10393	2	15.2	25	0.25
file_server	10393	14	18.6	42	0.25
file_server	10393	25	11.2	7	0.25
file_server	10393	26	24.9	70	0.25
file_server	10393	31	10	32	0
file_server	10394	13	4.8	10	0
file_server	10394	62	39.4	10	0
file_server	10395	46	9.6	28	0.1
file_server	10395	53	26.2	70	0.1
file_server	10395	69	28.8	8	0
file_server	10396	23	7.2	40	0
file_server	10396	71	17.2	60	0
file_server	10396	72	27.8	21	0
file_server	10397	21	8	10	0.15
file_server	10397	51	42.4	18	0.15
file_server	10398	35	14.4	30	0
file_server	10398	55	19.2	120	0.1
file_server	10399	68	10	60	0
file_server	10399	71	17.2	30	0
file_server	10399	76	14.4	35	0
file_server	10399	77	10.4	14	0
file_server	10400	29	99	21	0
file_server	10400	35	14.4	35	0
file_server	10400	49	16	30	0
file_server	10401	30	20.7	18	0
file_server	10401	56	30.4	70	0
file_server	10401	65	16.8	20	0
file_server	10401	71	17.2	60	0
file_server	10402	23	7.2	60	0
file_server	10402	63	35.1	65	0
file_server	10403	16	13.9	21	0.15
file_server	10403	48	10.2	70	0.15
file_server	10404	26	24.9	30	0.05
file_server	10404	42	11.2	40	0.05
file_server	10404	49	16	30	0.05
file_server	10405	3	8	50	0
file_server	10406	1	14.4	10	0
file_server	10406	21	8	30	0.1
file_server	10406	28	36.4	42	0.1
file_server	10406	36	15.2	5	0.1
file_server	10406	40	14.7	2	0.1
file_server	10407	11	16.8	30	0
file_server	10407	69	28.8	15	0
file_server	10407	71	17.2	15	0
file_server	10408	37	20.8	10	0
file_server	10408	54	5.9	6	0
file_server	10408	62	39.4	35	0
file_server	10409	14	18.6	12	0
file_server	10409	21	8	12	0
file_server	10410	33	2	49	0
file_server	10410	59	44	16	0
file_server	10411	41	7.7	25	0.2
file_server	10411	44	15.5	40	0.2
file_server	10411	59	44	9	0.2
file_server	10412	14	18.6	20	0.1
file_server	10413	1	14.4	24	0
file_server	10413	62	39.4	40	0
file_server	10413	76	14.4	14	0
file_server	10414	19	7.3	18	0.05
file_server	10414	33	2	50	0
file_server	10415	17	31.2	2	0
file_server	10415	33	2	20	0
file_server	10416	19	7.3	20	0
file_server	10416	53	26.2	10	0
file_server	10416	57	15.6	20	0
file_server	10417	38	210.8	50	0
file_server	10417	46	9.6	2	0.25
file_server	10417	68	10	36	0.25
file_server	10417	77	10.4	35	0
file_server	10418	2	15.2	60	0
file_server	10418	47	7.6	55	0
file_server	10418	61	22.8	16	0
file_server	10418	74	8	15	0
file_server	10419	60	27.2	60	0.05
file_server	10419	69	28.8	20	0.05
file_server	10420	9	77.6	20	0.1
file_server	10420	13	4.8	2	0.1
file_server	10420	70	12	8	0.1
file_server	10420	73	12	20	0.1
file_server	10421	19	7.3	4	0.15
file_server	10421	26	24.9	30	0
file_server	10421	53	26.2	15	0.15
file_server	10421	77	10.4	10	0.15
file_server	10422	26	24.9	2	0
file_server	10423	31	10	14	0
file_server	10423	59	44	20	0
file_server	10424	35	14.4	60	0.2
file_server	10424	38	210.8	49	0.2
file_server	10424	68	10	30	0.2
file_server	10425	55	19.2	10	0.25
file_server	10425	76	14.4	20	0.25
file_server	10426	56	30.4	5	0
file_server	10426	64	26.6	7	0
file_server	10427	14	18.6	35	0
file_server	10428	46	9.6	20	0
file_server	10429	50	13	40	0
file_server	10429	63	35.1	35	0.25
file_server	10430	17	31.2	45	0.2
file_server	10430	21	8	50	0
file_server	10430	56	30.4	30	0
file_server	10430	59	44	70	0.2
file_server	10431	17	31.2	50	0.25
file_server	10431	40	14.7	50	0.25
file_server	10431	47	7.6	30	0.25
file_server	10432	26	24.9	10	0
file_server	10432	54	5.9	40	0
file_server	10433	56	30.4	28	0
file_server	10434	11	16.8	6	0
file_server	10434	76	14.4	18	0.15
file_server	10435	2	15.2	10	0
file_server	10435	22	16.8	12	0
file_server	10435	72	27.8	10	0
file_server	10436	46	9.6	5	0
file_server	10436	56	30.4	40	0.1
file_server	10436	64	26.6	30	0.1
file_server	10436	75	6.2	24	0.1
file_server	10437	53	26.2	15	0
file_server	10438	19	7.3	15	0.2
file_server	10438	34	11.2	20	0.2
file_server	10438	57	15.6	15	0.2
file_server	10439	12	30.4	15	0
file_server	10439	16	13.9	16	0
file_server	10439	64	26.6	6	0
file_server	10439	74	8	30	0
file_server	10440	2	15.2	45	0.15
file_server	10440	16	13.9	49	0.15
file_server	10440	29	99	24	0.15
file_server	10440	61	22.8	90	0.15
file_server	10441	27	35.1	50	0
file_server	10442	11	16.8	30	0
file_server	10442	54	5.9	80	0
file_server	10442	66	13.6	60	0
file_server	10443	11	16.8	6	0.2
file_server	10443	28	36.4	12	0
file_server	10444	17	31.2	10	0
file_server	10444	26	24.9	15	0
file_server	10444	35	14.4	8	0
file_server	10444	41	7.7	30	0
file_server	10445	39	14.4	6	0
file_server	10445	54	5.9	15	0
file_server	10446	19	7.3	12	0.1
file_server	10446	24	3.6	20	0.1
file_server	10446	31	10	3	0.1
file_server	10446	52	5.6	15	0.1
file_server	10447	19	7.3	40	0
file_server	10447	65	16.8	35	0
file_server	10447	71	17.2	2	0
file_server	10448	26	24.9	6	0
file_server	10448	40	14.7	20	0
file_server	10449	10	24.8	14	0
file_server	10449	52	5.6	20	0
file_server	10449	62	39.4	35	0
file_server	10450	10	24.8	20	0.2
file_server	10450	54	5.9	6	0.2
file_server	10451	55	19.2	120	0.1
file_server	10451	64	26.6	35	0.1
file_server	10451	65	16.8	28	0.1
file_server	10451	77	10.4	55	0.1
file_server	10452	28	36.4	15	0
file_server	10452	44	15.5	100	0.05
file_server	10453	48	10.2	15	0.1
file_server	10453	70	12	25	0.1
file_server	10454	16	13.9	20	0.2
file_server	10454	33	2	20	0.2
file_server	10454	46	9.6	10	0.2
file_server	10455	39	14.4	20	0
file_server	10455	53	26.2	50	0
file_server	10455	61	22.8	25	0
file_server	10455	71	17.2	30	0
file_server	10456	21	8	40	0.15
file_server	10456	49	16	21	0.15
file_server	10457	59	44	36	0
file_server	10458	26	24.9	30	0
file_server	10458	28	36.4	30	0
file_server	10458	43	36.8	20	0
file_server	10458	56	30.4	15	0
file_server	10458	71	17.2	50	0
file_server	10459	7	24	16	0.05
file_server	10459	46	9.6	20	0.05
file_server	10459	72	27.8	40	0
file_server	10460	68	10	21	0.25
file_server	10460	75	6.2	4	0.25
file_server	10461	21	8	40	0.25
file_server	10461	30	20.7	28	0.25
file_server	10461	55	19.2	60	0.25
file_server	10462	13	4.8	1	0
file_server	10462	23	7.2	21	0
file_server	10463	19	7.3	21	0
file_server	10463	42	11.2	50	0
file_server	10464	4	17.6	16	0.2
file_server	10464	43	36.8	3	0
file_server	10464	56	30.4	30	0.2
file_server	10464	60	27.2	20	0
file_server	10465	24	3.6	25	0
file_server	10465	29	99	18	0.1
file_server	10465	40	14.7	20	0
file_server	10465	45	7.6	30	0.1
file_server	10465	50	13	25	0
file_server	10466	11	16.8	10	0
file_server	10466	46	9.6	5	0
file_server	10467	24	3.6	28	0
file_server	10467	25	11.2	12	0
file_server	10468	30	20.7	8	0
file_server	10468	43	36.8	15	0
file_server	10469	2	15.2	40	0.15
file_server	10469	16	13.9	35	0.15
file_server	10469	44	15.5	2	0.15
file_server	10470	18	50	30	0
file_server	10470	23	7.2	15	0
file_server	10470	64	26.6	8	0
file_server	10471	7	24	30	0
file_server	10471	56	30.4	20	0
file_server	10472	24	3.6	80	0.05
file_server	10472	51	42.4	18	0
file_server	10473	33	2	12	0
file_server	10473	71	17.2	12	0
file_server	10474	14	18.6	12	0
file_server	10474	28	36.4	18	0
file_server	10474	40	14.7	21	0
file_server	10474	75	6.2	10	0
file_server	10475	31	10	35	0.15
file_server	10475	66	13.6	60	0.15
file_server	10475	76	14.4	42	0.15
file_server	10476	55	19.2	2	0.05
file_server	10476	70	12	12	0
file_server	10477	1	14.4	15	0
file_server	10477	21	8	21	0.25
file_server	10477	39	14.4	20	0.25
file_server	10478	10	24.8	20	0.05
file_server	10479	38	210.8	30	0
file_server	10479	53	26.2	28	0
file_server	10479	59	44	60	0
file_server	10479	64	26.6	30	0
file_server	10480	47	7.6	30	0
file_server	10480	59	44	12	0
file_server	10481	49	16	24	0
file_server	10481	60	27.2	40	0
file_server	10482	40	14.7	10	0
file_server	10483	34	11.2	35	0.05
file_server	10483	77	10.4	30	0.05
file_server	10484	21	8	14	0
file_server	10484	40	14.7	10	0
file_server	10484	51	42.4	3	0
file_server	10485	2	15.2	20	0.1
file_server	10485	3	8	20	0.1
file_server	10485	55	19.2	30	0.1
file_server	10485	70	12	60	0.1
file_server	10486	11	16.8	5	0
file_server	10486	51	42.4	25	0
file_server	10486	74	8	16	0
file_server	10487	19	7.3	5	0
file_server	10487	26	24.9	30	0
file_server	10487	54	5.9	24	0.25
file_server	10488	59	44	30	0
file_server	10488	73	12	20	0.2
file_server	10489	11	16.8	15	0.25
file_server	10489	16	13.9	18	0
file_server	10490	59	44	60	0
file_server	10490	68	10	30	0
file_server	10490	75	6.2	36	0
file_server	10491	44	15.5	15	0.15
file_server	10491	77	10.4	7	0.15
file_server	10492	25	11.2	60	0.05
file_server	10492	42	11.2	20	0.05
file_server	10493	65	16.8	15	0.1
file_server	10493	66	13.6	10	0.1
file_server	10493	69	28.8	10	0.1
file_server	10494	56	30.4	30	0
file_server	10495	23	7.2	10	0
file_server	10495	41	7.7	20	0
file_server	10495	77	10.4	5	0
file_server	10496	31	10	20	0.05
file_server	10497	56	30.4	14	0
file_server	10497	72	27.8	25	0
file_server	10497	77	10.4	25	0
file_server	10498	24	4.5	14	0
file_server	10498	40	18.4	5	0
file_server	10498	42	14	30	0
file_server	10499	28	45.6	20	0
file_server	10499	49	20	25	0
file_server	10500	15	15.5	12	0.05
file_server	10500	28	45.6	8	0.05
file_server	10501	54	7.45	20	0
file_server	10502	45	9.5	21	0
file_server	10502	53	32.8	6	0
file_server	10502	67	14	30	0
file_server	10503	14	23.25	70	0
file_server	10503	65	21.05	20	0
file_server	10504	2	19	12	0
file_server	10504	21	10	12	0
file_server	10504	53	32.8	10	0
file_server	10504	61	28.5	25	0
file_server	10505	62	49.3	3	0
file_server	10506	25	14	18	0.1
file_server	10506	70	15	14	0.1
file_server	10507	43	46	15	0.15
file_server	10507	48	12.75	15	0.15
file_server	10508	13	6	10	0
file_server	10508	39	18	10	0
file_server	10509	28	45.6	3	0
file_server	10510	29	123.79	36	0
file_server	10510	75	7.75	36	0.1
file_server	10511	4	22	50	0.15
file_server	10511	7	30	50	0.15
file_server	10511	8	40	10	0.15
file_server	10512	24	4.5	10	0.15
file_server	10512	46	12	9	0.15
file_server	10512	47	9.5	6	0.15
file_server	10512	60	34	12	0.15
file_server	10513	21	10	40	0.2
file_server	10513	32	32	50	0.2
file_server	10513	61	28.5	15	0.2
file_server	10514	20	81	39	0
file_server	10514	28	45.6	35	0
file_server	10514	56	38	70	0
file_server	10514	65	21.05	39	0
file_server	10514	75	7.75	50	0
file_server	10515	9	97	16	0.15
file_server	10515	16	17.45	50	0
file_server	10515	27	43.9	120	0
file_server	10515	33	2.5	16	0.15
file_server	10515	60	34	84	0.15
file_server	10516	18	62.5	25	0.1
file_server	10516	41	9.65	80	0.1
file_server	10516	42	14	20	0
file_server	10517	52	7	6	0
file_server	10517	59	55	4	0
file_server	10517	70	15	6	0
file_server	10518	24	4.5	5	0
file_server	10518	38	263.5	15	0
file_server	10518	44	19.45	9	0
\.


--
-- Data for Name: structured_file_server_order_details_2019; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_order_details_2019 (permission_scope_key, orderid, productid, orderprice, quantity, discount) FROM stdin;
file_server	10519	10	31	16	0.05
file_server	10519	56	38	40	0
file_server	10519	60	34	10	0.05
file_server	10520	24	4.5	8	0
file_server	10520	53	32.8	5	0
file_server	10521	35	18	3	0
file_server	10521	41	9.65	10	0
file_server	10521	68	12.5	6	0
file_server	10522	1	18	40	0.2
file_server	10522	8	40	24	0
file_server	10522	30	25.89	20	0.2
file_server	10522	40	18.4	25	0.2
file_server	10523	17	39	25	0.1
file_server	10523	20	81	15	0.1
file_server	10523	37	26	18	0.1
file_server	10523	41	9.65	6	0.1
file_server	10524	10	31	2	0
file_server	10524	30	25.89	10	0
file_server	10524	43	46	60	0
file_server	10524	54	7.45	15	0
file_server	10525	36	19	30	0
file_server	10525	40	18.4	15	0.1
file_server	10526	1	18	8	0.15
file_server	10526	13	6	10	0
file_server	10526	56	38	30	0.15
file_server	10527	4	22	50	0.1
file_server	10527	36	19	30	0.1
file_server	10528	11	21	3	0
file_server	10528	33	2.5	8	0.2
file_server	10528	72	34.8	9	0
file_server	10529	55	24	14	0
file_server	10529	68	12.5	20	0
file_server	10529	69	36	10	0
file_server	10530	17	39	40	0
file_server	10530	43	46	25	0
file_server	10530	61	28.5	20	0
file_server	10530	76	18	50	0
file_server	10531	59	55	2	0
file_server	10532	30	25.89	15	0
file_server	10532	66	17	24	0
file_server	10533	4	22	50	0.05
file_server	10533	72	34.8	24	0
file_server	10533	73	15	24	0.05
file_server	10534	30	25.89	10	0
file_server	10534	40	18.4	10	0.2
file_server	10534	54	7.45	10	0.2
file_server	10535	11	21	50	0.1
file_server	10535	40	18.4	10	0.1
file_server	10535	57	19.5	5	0.1
file_server	10535	59	55	15	0.1
file_server	10536	12	38	15	0.25
file_server	10536	31	12.5	20	0
file_server	10536	33	2.5	30	0
file_server	10536	60	34	35	0.25
file_server	10537	31	12.5	30	0
file_server	10537	51	53	6	0
file_server	10537	58	13.25	20	0
file_server	10537	72	34.8	21	0
file_server	10537	73	15	9	0
file_server	10538	70	15	7	0
file_server	10538	72	34.8	1	0
file_server	10539	13	6	8	0
file_server	10539	21	10	15	0
file_server	10539	33	2.5	15	0
file_server	10539	49	20	6	0
file_server	10540	3	10	60	0
file_server	10540	26	31.23	40	0
file_server	10540	38	263.5	30	0
file_server	10540	68	12.5	35	0
file_server	10541	24	4.5	35	0.1
file_server	10541	38	263.5	4	0.1
file_server	10541	65	21.05	36	0.1
file_server	10541	71	21.5	9	0.1
file_server	10542	11	21	15	0.05
file_server	10542	54	7.45	24	0.05
file_server	10543	12	38	30	0.15
file_server	10543	23	9	70	0.15
file_server	10544	28	45.6	7	0
file_server	10544	67	14	7	0
file_server	10545	11	21	10	0
file_server	10546	7	30	10	0
file_server	10546	35	18	30	0
file_server	10546	62	49.3	40	0
file_server	10547	32	32	24	0.15
file_server	10547	36	19	60	0
file_server	10548	34	14	10	0.25
file_server	10548	41	9.65	14	0
file_server	10549	31	12.5	55	0.15
file_server	10549	45	9.5	100	0.15
file_server	10549	51	53	48	0.15
file_server	10550	17	39	8	0.1
file_server	10550	19	9.2	10	0
file_server	10550	21	10	6	0.1
file_server	10550	61	28.5	10	0.1
file_server	10551	16	17.45	40	0.15
file_server	10551	35	18	20	0.15
file_server	10551	44	19.45	40	0
file_server	10552	69	36	18	0
file_server	10552	75	7.75	30	0
file_server	10553	11	21	15	0
file_server	10553	16	17.45	14	0
file_server	10553	22	21	24	0
file_server	10553	31	12.5	30	0
file_server	10553	35	18	6	0
file_server	10554	16	17.45	30	0.05
file_server	10554	23	9	20	0.05
file_server	10554	62	49.3	20	0.05
file_server	10554	77	13	10	0.05
file_server	10555	14	23.25	30	0.2
file_server	10555	19	9.2	35	0.2
file_server	10555	24	4.5	18	0.2
file_server	10555	51	53	20	0.2
file_server	10555	56	38	40	0.2
file_server	10556	72	34.8	24	0
file_server	10557	64	33.25	30	0
file_server	10557	75	7.75	20	0
file_server	10558	47	9.5	25	0
file_server	10558	51	53	20	0
file_server	10558	52	7	30	0
file_server	10558	53	32.8	18	0
file_server	10558	73	15	3	0
file_server	10559	41	9.65	12	0.05
file_server	10559	55	24	18	0.05
file_server	10560	30	25.89	20	0
file_server	10560	62	49.3	15	0.25
file_server	10561	44	19.45	10	0
file_server	10561	51	53	50	0
file_server	10562	33	2.5	20	0.1
file_server	10562	62	49.3	10	0.1
file_server	10563	36	19	25	0
file_server	10563	52	7	70	0
file_server	10564	17	39	16	0.05
file_server	10564	31	12.5	6	0.05
file_server	10564	55	24	25	0.05
file_server	10565	24	4.5	25	0.1
file_server	10565	64	33.25	18	0.1
file_server	10566	11	21	35	0.15
file_server	10566	18	62.5	18	0.15
file_server	10566	76	18	10	0
file_server	10567	31	12.5	60	0.2
file_server	10567	51	53	3	0
file_server	10567	59	55	40	0.2
file_server	10568	10	31	5	0
file_server	10569	31	12.5	35	0.2
file_server	10569	76	18	30	0
file_server	10570	11	21	15	0.05
file_server	10570	56	38	60	0.05
file_server	10571	14	23.25	11	0.15
file_server	10571	42	14	28	0.15
file_server	10572	16	17.45	12	0.1
file_server	10572	32	32	10	0.1
file_server	10572	40	18.4	50	0
file_server	10572	75	7.75	15	0.1
file_server	10573	17	39	18	0
file_server	10573	34	14	40	0
file_server	10573	53	32.8	25	0
file_server	10574	33	2.5	14	0
file_server	10574	40	18.4	2	0
file_server	10574	62	49.3	10	0
file_server	10574	64	33.25	6	0
file_server	10575	59	55	12	0
file_server	10575	63	43.9	6	0
file_server	10575	72	34.8	30	0
file_server	10575	76	18	10	0
file_server	10576	1	18	10	0
file_server	10576	31	12.5	20	0
file_server	10576	44	19.45	21	0
file_server	10577	39	18	10	0
file_server	10577	75	7.75	20	0
file_server	10577	77	13	18	0
file_server	10578	35	18	20	0
file_server	10578	57	19.5	6	0
file_server	10579	15	15.5	10	0
file_server	10579	75	7.75	21	0
file_server	10580	14	23.25	15	0.05
file_server	10580	41	9.65	9	0.05
file_server	10580	65	21.05	30	0.05
file_server	10581	75	7.75	50	0.2
file_server	10582	57	19.5	4	0
file_server	10582	76	18	14	0
file_server	10583	29	123.79	10	0
file_server	10583	60	34	24	0.15
file_server	10583	69	36	10	0.15
file_server	10584	31	12.5	50	0.05
file_server	10585	47	9.5	15	0
file_server	10586	52	7	4	0.15
file_server	10587	26	31.23	6	0
file_server	10587	35	18	20	0
file_server	10587	77	13	20	0
file_server	10588	18	62.5	40	0.2
file_server	10588	42	14	100	0.2
file_server	10589	35	18	4	0
file_server	10590	1	18	20	0
file_server	10590	77	13	60	0.05
file_server	10591	3	10	14	0
file_server	10591	7	30	10	0
file_server	10591	54	7.45	50	0
file_server	10592	15	15.5	25	0.05
file_server	10592	26	31.23	5	0.05
file_server	10593	20	81	21	0.2
file_server	10593	69	36	20	0.2
file_server	10593	76	18	4	0.2
file_server	10594	52	7	24	0
file_server	10594	58	13.25	30	0
file_server	10595	35	18	30	0.25
file_server	10595	61	28.5	120	0.25
file_server	10595	69	36	65	0.25
file_server	10596	56	38	5	0.2
file_server	10596	63	43.9	24	0.2
file_server	10596	75	7.75	30	0.2
file_server	10597	24	4.5	35	0.2
file_server	10597	57	19.5	20	0
file_server	10597	65	21.05	12	0.2
file_server	10598	27	43.9	50	0
file_server	10598	71	21.5	9	0
file_server	10599	62	49.3	10	0
file_server	10600	54	7.45	4	0
file_server	10600	73	15	30	0
file_server	10601	13	6	60	0
file_server	10601	59	55	35	0
file_server	10602	77	13	5	0.25
file_server	10603	22	21	48	0
file_server	10603	49	20	25	0.05
file_server	10604	48	12.75	6	0.1
file_server	10604	76	18	10	0.1
file_server	10605	16	17.45	30	0.05
file_server	10605	59	55	20	0.05
file_server	10605	60	34	70	0.05
file_server	10605	71	21.5	15	0.05
file_server	10606	4	22	20	0.2
file_server	10606	55	24	20	0.2
file_server	10606	62	49.3	10	0.2
file_server	10607	7	30	45	0
file_server	10607	17	39	100	0
file_server	10607	33	2.5	14	0
file_server	10607	40	18.4	42	0
file_server	10607	72	34.8	12	0
file_server	10608	56	38	28	0
file_server	10609	1	18	3	0
file_server	10609	10	31	10	0
file_server	10609	21	10	6	0
file_server	10610	36	19	21	0.25
file_server	10611	1	18	6	0
file_server	10611	2	19	10	0
file_server	10611	60	34	15	0
file_server	10612	10	31	70	0
file_server	10612	36	19	55	0
file_server	10612	49	20	18	0
file_server	10612	60	34	40	0
file_server	10612	76	18	80	0
file_server	10613	13	6	8	0.1
file_server	10613	75	7.75	40	0
file_server	10614	11	21	14	0
file_server	10614	21	10	8	0
file_server	10614	39	18	5	0
file_server	10615	55	24	5	0
file_server	10616	38	263.5	15	0.05
file_server	10616	56	38	14	0
file_server	10616	70	15	15	0.05
file_server	10616	71	21.5	15	0.05
file_server	10617	59	55	30	0.15
file_server	10618	6	25	70	0
file_server	10618	56	38	20	0
file_server	10618	68	12.5	15	0
file_server	10619	21	10	42	0
file_server	10619	22	21	40	0
file_server	10620	24	4.5	5	0
file_server	10620	52	7	5	0
file_server	10621	19	9.2	5	0
file_server	10621	23	9	10	0
file_server	10621	70	15	20	0
file_server	10621	71	21.5	15	0
file_server	10622	2	19	20	0
file_server	10622	68	12.5	18	0.2
file_server	10623	14	23.25	21	0
file_server	10623	19	9.2	15	0.1
file_server	10623	21	10	25	0.1
file_server	10623	24	4.5	3	0
file_server	10623	35	18	30	0.1
file_server	10624	28	45.6	10	0
file_server	10624	29	123.79	6	0
file_server	10624	44	19.45	10	0
file_server	10625	14	23.25	3	0
file_server	10625	42	14	5	0
file_server	10625	60	34	10	0
file_server	10626	53	32.8	12	0
file_server	10626	60	34	20	0
file_server	10626	71	21.5	20	0
file_server	10627	62	49.3	15	0
file_server	10627	73	15	35	0.15
file_server	10628	1	18	25	0
file_server	10629	29	123.79	20	0
file_server	10629	64	33.25	9	0
file_server	10630	55	24	12	0.05
file_server	10630	76	18	35	0
file_server	10631	75	7.75	8	0.1
file_server	10632	2	19	30	0.05
file_server	10632	33	2.5	20	0.05
file_server	10633	12	38	36	0.15
file_server	10633	13	6	13	0.15
file_server	10633	26	31.23	35	0.15
file_server	10633	62	49.3	80	0.15
file_server	10634	7	30	35	0
file_server	10634	18	62.5	50	0
file_server	10634	51	53	15	0
file_server	10634	75	7.75	2	0
file_server	10635	4	22	10	0.1
file_server	10635	5	21.35	15	0.1
file_server	10635	22	21	40	0
file_server	10636	4	22	25	0
file_server	10636	58	13.25	6	0
file_server	10637	11	21	10	0
file_server	10637	50	16.25	25	0.05
file_server	10637	56	38	60	0.05
file_server	10638	45	9.5	20	0
file_server	10638	65	21.05	21	0
file_server	10638	72	34.8	60	0
file_server	10639	18	62.5	8	0
file_server	10640	69	36	20	0.25
file_server	10640	70	15	15	0.25
file_server	10641	2	19	50	0
file_server	10641	40	18.4	60	0
file_server	10642	21	10	30	0.2
file_server	10642	61	28.5	20	0.2
file_server	10643	28	45.6	15	0.25
file_server	10643	39	18	21	0.25
file_server	10643	46	12	2	0.25
file_server	10644	18	62.5	4	0.1
file_server	10644	43	46	20	0
file_server	10644	46	12	21	0.1
file_server	10645	18	62.5	20	0
file_server	10645	36	19	15	0
file_server	10646	1	18	15	0.25
file_server	10646	10	31	18	0.25
file_server	10646	71	21.5	30	0.25
file_server	10646	77	13	35	0.25
file_server	10647	19	9.2	30	0
file_server	10647	39	18	20	0
file_server	10648	22	21	15	0
file_server	10648	24	4.5	15	0.15
file_server	10649	28	45.6	20	0
file_server	10649	72	34.8	15	0
file_server	10650	30	25.89	30	0
file_server	10650	53	32.8	25	0.05
file_server	10650	54	7.45	30	0
file_server	10651	19	9.2	12	0.25
file_server	10651	22	21	20	0.25
file_server	10652	30	25.89	2	0.25
file_server	10652	42	14	20	0
file_server	10653	16	17.45	30	0.1
file_server	10653	60	34	20	0.1
file_server	10654	4	22	12	0.1
file_server	10654	39	18	20	0.1
file_server	10654	54	7.45	6	0.1
file_server	10655	41	9.65	20	0.2
file_server	10656	14	23.25	3	0.1
file_server	10656	44	19.45	28	0.1
file_server	10656	47	9.5	6	0.1
file_server	10657	15	15.5	50	0
file_server	10657	41	9.65	24	0
file_server	10657	46	12	45	0
file_server	10657	47	9.5	10	0
file_server	10657	56	38	45	0
file_server	10657	60	34	30	0
file_server	10658	21	10	60	0
file_server	10658	40	18.4	70	0.05
file_server	10658	60	34	55	0.05
file_server	10658	77	13	70	0.05
file_server	10659	31	12.5	20	0.05
file_server	10659	40	18.4	24	0.05
file_server	10659	70	15	40	0.05
file_server	10660	20	81	21	0
file_server	10661	39	18	3	0.2
file_server	10661	58	13.25	49	0.2
file_server	10662	68	12.5	10	0
file_server	10663	40	18.4	30	0.05
file_server	10663	42	14	30	0.05
file_server	10663	51	53	20	0.05
file_server	10664	10	31	24	0.15
file_server	10664	56	38	12	0.15
file_server	10664	65	21.05	15	0.15
file_server	10665	51	53	20	0
file_server	10665	59	55	1	0
file_server	10665	76	18	10	0
file_server	10666	29	123.79	36	0
file_server	10666	65	21.05	10	0
file_server	10667	69	36	45	0.2
file_server	10667	71	21.5	14	0.2
file_server	10668	31	12.5	8	0.1
file_server	10668	55	24	4	0.1
file_server	10668	64	33.25	15	0.1
file_server	10669	36	19	30	0
file_server	10670	23	9	32	0
file_server	10670	46	12	60	0
file_server	10670	67	14	25	0
file_server	10670	73	15	50	0
file_server	10670	75	7.75	25	0
file_server	10671	16	17.45	10	0
file_server	10671	62	49.3	10	0
file_server	10671	65	21.05	12	0
file_server	10672	38	263.5	15	0.1
file_server	10672	71	21.5	12	0
file_server	10673	16	17.45	3	0
file_server	10673	42	14	6	0
file_server	10673	43	46	6	0
file_server	10674	23	9	5	0
file_server	10675	14	23.25	30	0
file_server	10675	53	32.8	10	0
file_server	10675	58	13.25	30	0
\.


--
-- Data for Name: structured_file_server_order_details_2020; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_order_details_2020 (permission_scope_key, orderid, productid, orderprice, quantity, discount) FROM stdin;
file_server	10676	10	31	2	0
file_server	10676	19	9.2	7	0
file_server	10676	44	19.45	21	0
file_server	10677	26	31.23	30	0.15
file_server	10677	33	2.5	8	0.15
file_server	10678	12	38	100	0
file_server	10678	33	2.5	30	0
file_server	10678	41	9.65	120	0
file_server	10678	54	7.45	30	0
file_server	10679	59	55	12	0
file_server	10680	16	17.45	50	0.25
file_server	10680	31	12.5	20	0.25
file_server	10680	42	14	40	0.25
file_server	10681	19	9.2	30	0.1
file_server	10681	21	10	12	0.1
file_server	10681	64	33.25	28	0
file_server	10682	33	2.5	30	0
file_server	10682	66	17	4	0
file_server	10682	75	7.75	30	0
file_server	10683	52	7	9	0
file_server	10684	40	18.4	20	0
file_server	10684	47	9.5	40	0
file_server	10684	60	34	30	0
file_server	10685	10	31	20	0
file_server	10685	41	9.65	4	0
file_server	10685	47	9.5	15	0
file_server	10686	17	39	30	0.2
file_server	10686	26	31.23	15	0
file_server	10687	9	97	50	0.25
file_server	10687	29	123.79	10	0
file_server	10687	36	19	6	0.25
file_server	10688	10	31	18	0.1
file_server	10688	28	45.6	60	0.1
file_server	10688	34	14	14	0
file_server	10689	1	18	35	0.25
file_server	10690	56	38	20	0.25
file_server	10690	77	13	30	0.25
file_server	10691	1	18	30	0
file_server	10691	29	123.79	40	0
file_server	10691	43	46	40	0
file_server	10691	44	19.45	24	0
file_server	10691	62	49.3	48	0
file_server	10692	63	43.9	20	0
file_server	10693	9	97	6	0
file_server	10693	54	7.45	60	0.15
file_server	10693	69	36	30	0.15
file_server	10693	73	15	15	0.15
file_server	10694	7	30	90	0
file_server	10694	59	55	25	0
file_server	10694	70	15	50	0
file_server	10695	8	40	10	0
file_server	10695	12	38	4	0
file_server	10695	24	4.5	20	0
file_server	10696	17	39	20	0
file_server	10696	46	12	18	0
file_server	10697	19	9.2	7	0.25
file_server	10697	35	18	9	0.25
file_server	10697	58	13.25	30	0.25
file_server	10697	70	15	30	0.25
file_server	10698	11	21	15	0
file_server	10698	17	39	8	0.05
file_server	10698	29	123.79	12	0.05
file_server	10698	65	21.05	65	0.05
file_server	10698	70	15	8	0.05
file_server	10699	47	9.5	12	0
file_server	10700	1	18	5	0.2
file_server	10700	34	14	12	0.2
file_server	10700	68	12.5	40	0.2
file_server	10700	71	21.5	60	0.2
file_server	10701	59	55	42	0.15
file_server	10701	71	21.5	20	0.15
file_server	10701	76	18	35	0.15
file_server	10702	3	10	6	0
file_server	10702	76	18	15	0
file_server	10703	2	19	5	0
file_server	10703	59	55	35	0
file_server	10703	73	15	35	0
file_server	10704	4	22	6	0
file_server	10704	24	4.5	35	0
file_server	10704	48	12.75	24	0
file_server	10705	31	12.5	20	0
file_server	10705	32	32	4	0
file_server	10706	16	17.45	20	0
file_server	10706	43	46	24	0
file_server	10706	59	55	8	0
file_server	10707	55	24	21	0
file_server	10707	57	19.5	40	0
file_server	10707	70	15	28	0.15
file_server	10708	5	21.35	4	0
file_server	10708	36	19	5	0
file_server	10709	8	40	40	0
file_server	10709	51	53	28	0
file_server	10709	60	34	10	0
file_server	10710	19	9.2	5	0
file_server	10710	47	9.5	5	0
file_server	10711	19	9.2	12	0
file_server	10711	41	9.65	42	0
file_server	10711	53	32.8	120	0
file_server	10712	53	32.8	3	0.05
file_server	10712	56	38	30	0
file_server	10713	10	31	18	0
file_server	10713	26	31.23	30	0
file_server	10713	45	9.5	110	0
file_server	10713	46	12	24	0
file_server	10714	2	19	30	0.25
file_server	10714	17	39	27	0.25
file_server	10714	47	9.5	50	0.25
file_server	10714	56	38	18	0.25
file_server	10714	58	13.25	12	0.25
file_server	10715	10	31	21	0
file_server	10715	71	21.5	30	0
file_server	10716	21	10	5	0
file_server	10716	51	53	7	0
file_server	10716	61	28.5	10	0
file_server	10717	21	10	32	0.05
file_server	10717	54	7.45	15	0
file_server	10717	69	36	25	0.05
file_server	10718	12	38	36	0
file_server	10718	16	17.45	20	0
file_server	10718	36	19	40	0
file_server	10718	62	49.3	20	0
file_server	10719	18	62.5	12	0.25
file_server	10719	30	25.89	3	0.25
file_server	10719	54	7.45	40	0.25
file_server	10720	35	18	21	0
file_server	10720	71	21.5	8	0
file_server	10721	44	19.45	50	0.05
file_server	10722	2	19	3	0
file_server	10722	31	12.5	50	0
file_server	10722	68	12.5	45	0
file_server	10722	75	7.75	42	0
file_server	10723	26	31.23	15	0
file_server	10724	10	31	16	0
file_server	10724	61	28.5	5	0
file_server	10725	41	9.65	12	0
file_server	10725	52	7	4	0
file_server	10725	55	24	6	0
file_server	10726	4	22	25	0
file_server	10726	11	21	5	0
file_server	10727	17	39	20	0.05
file_server	10727	56	38	10	0.05
file_server	10727	59	55	10	0.05
file_server	10728	30	25.89	15	0
file_server	10728	40	18.4	6	0
file_server	10728	55	24	12	0
file_server	10728	60	34	15	0
file_server	10729	1	18	50	0
file_server	10729	21	10	30	0
file_server	10729	50	16.25	40	0
file_server	10730	16	17.45	15	0.05
file_server	10730	31	12.5	3	0.05
file_server	10730	65	21.05	10	0.05
file_server	10731	21	10	40	0.05
file_server	10731	51	53	30	0.05
file_server	10732	76	18	20	0
file_server	10733	14	23.25	16	0
file_server	10733	28	45.6	20	0
file_server	10733	52	7	25	0
file_server	10734	6	25	30	0
file_server	10734	30	25.89	15	0
file_server	10734	76	18	20	0
file_server	10735	61	28.5	20	0.1
file_server	10735	77	13	2	0.1
file_server	10736	65	21.05	40	0
file_server	10736	75	7.75	20	0
file_server	10737	13	6	4	0
file_server	10737	41	9.65	12	0
file_server	10738	16	17.45	3	0
file_server	10739	36	19	6	0
file_server	10739	52	7	18	0
file_server	10740	28	45.6	5	0.2
file_server	10740	35	18	35	0.2
file_server	10740	45	9.5	40	0.2
file_server	10740	56	38	14	0.2
file_server	10741	2	19	15	0.2
file_server	10742	3	10	20	0
file_server	10742	60	34	50	0
file_server	10742	72	34.8	35	0
file_server	10743	46	12	28	0.05
file_server	10744	40	18.4	50	0.2
file_server	10745	18	62.5	24	0
file_server	10745	44	19.45	16	0
file_server	10745	59	55	45	0
file_server	10745	72	34.8	7	0
file_server	10746	13	6	6	0
file_server	10746	42	14	28	0
file_server	10746	62	49.3	9	0
file_server	10746	69	36	40	0
file_server	10747	31	12.5	8	0
file_server	10747	41	9.65	35	0
file_server	10747	63	43.9	9	0
file_server	10747	69	36	30	0
file_server	10748	23	9	44	0
file_server	10748	40	18.4	40	0
file_server	10748	56	38	28	0
file_server	10749	56	38	15	0
file_server	10749	59	55	6	0
file_server	10749	76	18	10	0
file_server	10750	14	23.25	5	0.15
file_server	10750	45	9.5	40	0.15
file_server	10750	59	55	25	0.15
file_server	10751	26	31.23	12	0.1
file_server	10751	30	25.89	30	0
file_server	10751	50	16.25	20	0.1
file_server	10751	73	15	15	0
file_server	10752	1	18	8	0
file_server	10752	69	36	3	0
file_server	10753	45	9.5	4	0
file_server	10753	74	10	5	0
file_server	10754	40	18.4	3	0
file_server	10755	47	9.5	30	0.25
file_server	10755	56	38	30	0.25
file_server	10755	57	19.5	14	0.25
file_server	10755	69	36	25	0.25
file_server	10756	18	62.5	21	0.2
file_server	10756	36	19	20	0.2
file_server	10756	68	12.5	6	0.2
file_server	10756	69	36	20	0.2
file_server	10757	34	14	30	0
file_server	10757	59	55	7	0
file_server	10757	62	49.3	30	0
file_server	10757	64	33.25	24	0
file_server	10758	26	31.23	20	0
file_server	10758	52	7	60	0
file_server	10758	70	15	40	0
file_server	10759	32	32	10	0
file_server	10760	25	14	12	0.25
file_server	10760	27	43.9	40	0
file_server	10760	43	46	30	0.25
file_server	10761	25	14	35	0.25
file_server	10761	75	7.75	18	0
file_server	10762	39	18	16	0
file_server	10762	47	9.5	30	0
file_server	10762	51	53	28	0
file_server	10762	56	38	60	0
file_server	10763	21	10	40	0
file_server	10763	22	21	6	0
file_server	10763	24	4.5	20	0
file_server	10764	3	10	20	0.1
file_server	10764	39	18	130	0.1
file_server	10765	65	21.05	80	0.1
file_server	10766	2	19	40	0
file_server	10766	7	30	35	0
file_server	10766	68	12.5	40	0
file_server	10767	42	14	2	0
file_server	10768	22	21	4	0
file_server	10768	31	12.5	50	0
file_server	10768	60	34	15	0
file_server	10768	71	21.5	12	0
file_server	10769	41	9.65	30	0.05
file_server	10769	52	7	15	0.05
file_server	10769	61	28.5	20	0
file_server	10769	62	49.3	15	0
file_server	10770	11	21	15	0.25
file_server	10771	71	21.5	16	0
file_server	10772	29	123.79	18	0
file_server	10772	59	55	25	0
file_server	10773	17	39	33	0
file_server	10773	31	12.5	70	0.2
file_server	10773	75	7.75	7	0.2
file_server	10774	31	12.5	2	0.25
file_server	10774	66	17	50	0
file_server	10775	10	31	6	0
file_server	10775	67	14	3	0
file_server	10776	31	12.5	16	0.05
file_server	10776	42	14	12	0.05
file_server	10776	45	9.5	27	0.05
file_server	10776	51	53	120	0.05
file_server	10777	42	14	20	0.2
file_server	10778	41	9.65	10	0
file_server	10779	16	17.45	20	0
file_server	10779	62	49.3	20	0
file_server	10780	70	15	35	0
file_server	10780	77	13	15	0
file_server	10781	54	7.45	3	0.2
file_server	10781	56	38	20	0.2
file_server	10781	74	10	35	0
file_server	10782	31	12.5	1	0
file_server	10783	31	12.5	10	0
file_server	10783	38	263.5	5	0
file_server	10784	36	19	30	0
file_server	10784	39	18	2	0.15
file_server	10784	72	34.8	30	0.15
file_server	10785	10	31	10	0
file_server	10785	75	7.75	10	0
file_server	10786	8	40	30	0.2
file_server	10786	30	25.89	15	0.2
file_server	10786	75	7.75	42	0.2
file_server	10787	2	19	15	0.05
file_server	10787	29	123.79	20	0.05
file_server	10788	19	9.2	50	0.05
file_server	10788	75	7.75	40	0.05
file_server	10789	18	62.5	30	0
file_server	10789	35	18	15	0
file_server	10789	63	43.9	30	0
file_server	10789	68	12.5	18	0
file_server	10790	7	30	3	0.15
file_server	10790	56	38	20	0.15
file_server	10791	29	123.79	14	0.05
file_server	10791	41	9.65	20	0.05
file_server	10792	2	19	10	0
file_server	10792	54	7.45	3	0
file_server	10792	68	12.5	15	0
file_server	10793	41	9.65	14	0
file_server	10793	52	7	8	0
file_server	10794	14	23.25	15	0.2
file_server	10794	54	7.45	6	0.2
file_server	10795	16	17.45	65	0
file_server	10795	17	39	35	0.25
file_server	10796	26	31.23	21	0.2
file_server	10796	44	19.45	10	0
file_server	10796	64	33.25	35	0.2
file_server	10796	69	36	24	0.2
file_server	10797	11	21	20	0
file_server	10798	62	49.3	2	0
file_server	10798	72	34.8	10	0
file_server	10799	13	6	20	0.15
file_server	10799	24	4.5	20	0.15
file_server	10799	59	55	25	0
file_server	10800	11	21	50	0.1
file_server	10800	51	53	10	0.1
file_server	10800	54	7.45	7	0.1
file_server	10801	17	39	40	0.25
file_server	10801	29	123.79	20	0.25
file_server	10802	30	25.89	25	0.25
file_server	10802	51	53	30	0.25
file_server	10802	55	24	60	0.25
file_server	10802	62	49.3	5	0.25
file_server	10803	19	9.2	24	0.05
file_server	10803	25	14	15	0.05
file_server	10803	59	55	15	0.05
file_server	10804	10	31	36	0
file_server	10804	28	45.6	24	0
file_server	10804	49	20	4	0.15
file_server	10805	34	14	10	0
file_server	10805	38	263.5	10	0
file_server	10806	2	19	20	0.25
file_server	10806	65	21.05	2	0
file_server	10806	74	10	15	0.25
file_server	10807	40	18.4	1	0
file_server	10808	56	38	20	0.15
file_server	10808	76	18	50	0.15
file_server	10809	52	7	20	0
file_server	10810	13	6	7	0
file_server	10810	25	14	5	0
file_server	10810	70	15	5	0
file_server	10811	19	9.2	15	0
file_server	10811	23	9	18	0
file_server	10811	40	18.4	30	0
file_server	10812	31	12.5	16	0.1
file_server	10812	72	34.8	40	0.1
file_server	10812	77	13	20	0
file_server	10813	2	19	12	0.2
file_server	10813	46	12	35	0
file_server	10814	41	9.65	20	0
file_server	10814	43	46	20	0.15
file_server	10814	48	12.75	8	0.15
file_server	10814	61	28.5	30	0.15
file_server	10815	33	2.5	16	0
file_server	10816	38	263.5	30	0.05
file_server	10816	62	49.3	20	0.05
file_server	10817	26	31.23	40	0.15
file_server	10817	38	263.5	30	0
file_server	10817	40	18.4	60	0.15
file_server	10817	62	49.3	25	0.15
file_server	10818	32	32	20	0
file_server	10818	41	9.65	20	0
file_server	10819	43	46	7	0
file_server	10819	75	7.75	20	0
file_server	10820	56	38	30	0
file_server	10821	35	18	20	0
file_server	10821	51	53	6	0
file_server	10822	62	49.3	3	0
file_server	10822	70	15	6	0
file_server	10823	11	21	20	0.1
file_server	10823	57	19.5	15	0
file_server	10823	59	55	40	0.1
file_server	10823	77	13	15	0.1
file_server	10824	41	9.65	12	0
file_server	10824	70	15	9	0
file_server	10825	26	31.23	12	0
file_server	10825	53	32.8	20	0
file_server	10826	31	12.5	35	0
file_server	10826	57	19.5	15	0
file_server	10827	10	31	15	0
file_server	10827	39	18	21	0
file_server	10828	20	81	5	0
file_server	10828	38	263.5	2	0
file_server	10829	2	19	10	0
file_server	10829	8	40	20	0
file_server	10829	13	6	10	0
file_server	10829	60	34	21	0
file_server	10830	6	25	6	0
file_server	10830	39	18	28	0
file_server	10830	60	34	30	0
file_server	10830	68	12.5	24	0
file_server	10831	19	9.2	2	0
file_server	10831	35	18	8	0
file_server	10831	38	263.5	8	0
file_server	10831	43	46	9	0
file_server	10832	13	6	3	0.2
file_server	10832	25	14	10	0.2
file_server	10832	44	19.45	16	0.2
file_server	10832	64	33.25	3	0
file_server	10833	7	30	20	0.1
file_server	10833	31	12.5	9	0.1
file_server	10833	53	32.8	9	0.1
file_server	10834	29	123.79	8	0.05
file_server	10834	30	25.89	20	0.05
file_server	10835	59	55	15	0
file_server	10835	77	13	2	0.2
file_server	10836	22	21	52	0
file_server	10836	35	18	6	0
file_server	10836	57	19.5	24	0
file_server	10836	60	34	60	0
file_server	10836	64	33.25	30	0
file_server	10837	13	6	6	0
file_server	10837	40	18.4	25	0
file_server	10837	47	9.5	40	0.25
file_server	10837	76	18	21	0.25
file_server	10838	1	18	4	0.25
file_server	10838	18	62.5	25	0.25
file_server	10838	36	19	50	0.25
file_server	10839	58	13.25	30	0.1
file_server	10839	72	34.8	15	0.1
file_server	10840	25	14	6	0.2
file_server	10840	39	18	10	0.2
file_server	10841	10	31	16	0
file_server	10841	56	38	30	0
file_server	10841	59	55	50	0
file_server	10841	77	13	15	0
file_server	10842	11	21	15	0
file_server	10842	43	46	5	0
file_server	10842	68	12.5	20	0
file_server	10842	70	15	12	0
file_server	10843	51	53	4	0.25
file_server	10844	22	21	35	0
file_server	10845	23	9	70	0.1
file_server	10845	35	18	25	0.1
file_server	10845	42	14	42	0.1
file_server	10845	58	13.25	60	0.1
file_server	10845	64	33.25	48	0
file_server	10846	4	22	21	0
file_server	10846	70	15	30	0
file_server	10846	74	10	20	0
file_server	10847	1	18	80	0.2
file_server	10847	19	9.2	12	0.2
file_server	10847	37	26	60	0.2
file_server	10847	45	9.5	36	0.2
file_server	10847	60	34	45	0.2
file_server	10847	71	21.5	55	0.2
file_server	10848	5	21.35	30	0
file_server	10848	9	97	3	0
file_server	10849	3	10	49	0
file_server	10849	26	31.23	18	0.15
file_server	10850	25	14	20	0.15
file_server	10850	33	2.5	4	0.15
file_server	10850	70	15	30	0.15
file_server	10851	2	19	5	0.05
file_server	10851	25	14	10	0.05
file_server	10851	57	19.5	10	0.05
file_server	10851	59	55	42	0.05
file_server	10852	2	19	15	0
file_server	10852	17	39	6	0
file_server	10852	62	49.3	50	0
file_server	10853	18	62.5	10	0
file_server	10854	10	31	100	0.15
file_server	10854	13	6	65	0.15
file_server	10855	16	17.45	50	0
file_server	10855	31	12.5	14	0
file_server	10855	56	38	24	0
file_server	10855	65	21.05	15	0.15
file_server	10856	2	19	20	0
file_server	10856	42	14	20	0
file_server	10857	3	10	30	0
file_server	10857	26	31.23	35	0.25
file_server	10857	29	123.79	10	0.25
file_server	10858	7	30	5	0
file_server	10858	27	43.9	10	0
file_server	10858	70	15	4	0
file_server	10859	24	4.5	40	0.25
file_server	10859	54	7.45	35	0.25
file_server	10859	64	33.25	30	0.25
file_server	10860	51	53	3	0
file_server	10860	76	18	20	0
file_server	10861	17	39	42	0
file_server	10861	18	62.5	20	0
file_server	10861	21	10	40	0
file_server	10861	33	2.5	35	0
file_server	10861	62	49.3	3	0
file_server	10862	11	21	25	0
file_server	10862	52	7	8	0
file_server	10863	1	18	20	0.15
file_server	10863	58	13.25	12	0.15
file_server	10864	35	18	4	0
file_server	10864	67	14	15	0
file_server	10865	38	263.5	60	0.05
file_server	10865	39	18	80	0.05
file_server	10866	2	19	21	0.25
file_server	10866	24	4.5	6	0.25
file_server	10866	30	25.89	40	0.25
file_server	10867	53	32.8	3	0
file_server	10868	26	31.23	20	0
file_server	10868	35	18	30	0
file_server	10868	49	20	42	0.1
file_server	10869	1	18	40	0
file_server	10869	11	21	10	0
file_server	10869	23	9	50	0
file_server	10869	68	12.5	20	0
file_server	10870	35	18	3	0
file_server	10870	51	53	2	0
file_server	10871	6	25	50	0.05
file_server	10871	16	17.45	12	0.05
file_server	10871	17	39	16	0.05
file_server	10872	55	24	10	0.05
file_server	10872	62	49.3	20	0.05
file_server	10872	64	33.25	15	0.05
file_server	10872	65	21.05	21	0.05
file_server	10873	21	10	20	0
file_server	10873	28	45.6	3	0
file_server	10874	10	31	10	0
file_server	10875	19	9.2	25	0
file_server	10875	47	9.5	21	0.1
file_server	10875	49	20	15	0
file_server	10876	46	12	21	0
file_server	10876	64	33.25	20	0
file_server	10877	16	17.45	30	0.25
file_server	10877	18	62.5	25	0
file_server	10878	20	81	20	0.05
file_server	10879	40	18.4	12	0
file_server	10879	65	21.05	10	0
file_server	10879	76	18	10	0
file_server	10880	23	9	30	0.2
file_server	10880	61	28.5	30	0.2
file_server	10880	70	15	50	0.2
file_server	10881	73	15	10	0
file_server	10882	42	14	25	0
file_server	10882	49	20	20	0.15
file_server	10882	54	7.45	32	0.15
file_server	10883	24	4.5	8	0
file_server	10884	21	10	40	0.05
file_server	10884	56	38	21	0.05
file_server	10884	65	21.05	12	0.05
file_server	10885	2	19	20	0
file_server	10885	24	4.5	12	0
file_server	10885	70	15	30	0
file_server	10885	77	13	25	0
file_server	10886	10	31	70	0
file_server	10886	31	12.5	35	0
file_server	10886	77	13	40	0
file_server	10887	25	14	5	0
file_server	10888	2	19	20	0
file_server	10888	68	12.5	18	0
file_server	10889	11	21	40	0
file_server	10889	38	263.5	40	0
file_server	10890	17	39	15	0
file_server	10890	34	14	10	0
file_server	10890	41	9.65	14	0
file_server	10891	30	25.89	15	0.05
file_server	10892	59	55	40	0.05
\.


--
-- Data for Name: structured_file_server_order_details_2021; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_order_details_2021 (permission_scope_key, orderid, productid, orderprice, quantity, discount) FROM stdin;
file_server	10893	8	40	30	0
file_server	10893	24	4.5	10	0
file_server	10893	29	123.79	24	0
file_server	10893	30	25.89	35	0
file_server	10893	36	19	20	0
file_server	10894	13	6	28	0.05
file_server	10894	69	36	50	0.05
file_server	10894	75	7.75	120	0.05
file_server	10895	24	4.5	110	0
file_server	10895	39	18	45	0
file_server	10895	40	18.4	91	0
file_server	10895	60	34	100	0
file_server	10896	45	9.5	15	0
file_server	10896	56	38	16	0
file_server	10897	29	123.79	80	0
file_server	10897	30	25.89	36	0
file_server	10898	13	6	5	0
file_server	10899	39	18	8	0.15
file_server	10900	70	15	3	0.25
file_server	10901	41	9.65	30	0
file_server	10901	71	21.5	30	0
file_server	10902	55	24	30	0.15
file_server	10902	62	49.3	6	0.15
file_server	10903	13	6	40	0
file_server	10903	65	21.05	21	0
file_server	10903	68	12.5	20	0
file_server	10904	58	13.25	15	0
file_server	10904	62	49.3	35	0
file_server	10905	1	18	20	0.05
file_server	10906	61	28.5	15	0
file_server	10907	75	7.75	14	0
file_server	10908	7	30	20	0.05
file_server	10908	52	7	14	0.05
file_server	10909	7	30	12	0
file_server	10909	16	17.45	15	0
file_server	10909	41	9.65	5	0
file_server	10910	19	9.2	12	0
file_server	10910	49	20	10	0
file_server	10910	61	28.5	5	0
file_server	10911	1	18	10	0
file_server	10911	17	39	12	0
file_server	10911	67	14	15	0
file_server	10912	11	21	40	0.25
file_server	10912	29	123.79	60	0.25
file_server	10913	4	22	30	0.25
file_server	10913	33	2.5	40	0.25
file_server	10913	58	13.25	15	0
file_server	10914	71	21.5	25	0
file_server	10915	17	39	10	0
file_server	10915	33	2.5	30	0
file_server	10915	54	7.45	10	0
file_server	10916	16	17.45	6	0
file_server	10916	32	32	6	0
file_server	10916	57	19.5	20	0
file_server	10917	30	25.89	1	0
file_server	10917	60	34	10	0
file_server	10918	1	18	60	0.25
file_server	10918	60	34	25	0.25
file_server	10919	16	17.45	24	0
file_server	10919	25	14	24	0
file_server	10919	40	18.4	20	0
file_server	10920	50	16.25	24	0
file_server	10921	35	18	10	0
file_server	10921	63	43.9	40	0
file_server	10922	17	39	15	0
file_server	10922	24	4.5	35	0
file_server	10923	42	14	10	0.2
file_server	10923	43	46	10	0.2
file_server	10923	67	14	24	0.2
file_server	10924	10	31	20	0.1
file_server	10924	28	45.6	30	0.1
file_server	10924	75	7.75	6	0
file_server	10925	36	19	25	0.15
file_server	10925	52	7	12	0.15
file_server	10926	11	21	2	0
file_server	10926	13	6	10	0
file_server	10926	19	9.2	7	0
file_server	10926	72	34.8	10	0
file_server	10927	20	81	5	0
file_server	10927	52	7	5	0
file_server	10927	76	18	20	0
file_server	10928	47	9.5	5	0
file_server	10928	76	18	5	0
file_server	10929	21	10	60	0
file_server	10929	75	7.75	49	0
file_server	10929	77	13	15	0
file_server	10930	21	10	36	0
file_server	10930	27	43.9	25	0
file_server	10930	55	24	25	0.2
file_server	10930	58	13.25	30	0.2
file_server	10931	13	6	42	0.15
file_server	10931	57	19.5	30	0
file_server	10932	16	17.45	30	0.1
file_server	10932	62	49.3	14	0.1
file_server	10932	72	34.8	16	0
file_server	10932	75	7.75	20	0.1
file_server	10933	53	32.8	2	0
file_server	10933	61	28.5	30	0
file_server	10934	6	25	20	0
file_server	10935	1	18	21	0
file_server	10935	18	62.5	4	0.25
file_server	10935	23	9	8	0.25
file_server	10936	36	19	30	0.2
file_server	10937	28	45.6	8	0
file_server	10937	34	14	20	0
file_server	10938	13	6	20	0.25
file_server	10938	43	46	24	0.25
file_server	10938	60	34	49	0.25
file_server	10938	71	21.5	35	0.25
file_server	10939	2	19	10	0.15
file_server	10939	67	14	40	0.15
file_server	10940	7	30	8	0
file_server	10940	13	6	20	0
file_server	10941	31	12.5	44	0.25
file_server	10941	62	49.3	30	0.25
file_server	10941	68	12.5	80	0.25
file_server	10941	72	34.8	50	0
file_server	10942	49	20	28	0
file_server	10943	13	6	15	0
file_server	10943	22	21	21	0
file_server	10943	46	12	15	0
file_server	10944	11	21	5	0.25
file_server	10944	44	19.45	18	0.25
file_server	10944	56	38	18	0
file_server	10945	13	6	20	0
file_server	10945	31	12.5	10	0
file_server	10946	10	31	25	0
file_server	10946	24	4.5	25	0
file_server	10946	77	13	40	0
file_server	10947	59	55	4	0
file_server	10948	50	16.25	9	0
file_server	10948	51	53	40	0
file_server	10948	55	24	4	0
file_server	10949	6	25	12	0
file_server	10949	10	31	30	0
file_server	10949	17	39	6	0
file_server	10949	62	49.3	60	0
file_server	10950	4	22	5	0
file_server	10951	33	2.5	15	0.05
file_server	10951	41	9.65	6	0.05
file_server	10951	75	7.75	50	0.05
file_server	10952	6	25	16	0.05
file_server	10952	28	45.6	2	0
file_server	10953	20	81	50	0.05
file_server	10953	31	12.5	50	0.05
file_server	10954	16	17.45	28	0.15
file_server	10954	31	12.5	25	0.15
file_server	10954	45	9.5	30	0
file_server	10954	60	34	24	0.15
file_server	10955	75	7.75	12	0.2
file_server	10956	21	10	12	0
file_server	10956	47	9.5	14	0
file_server	10956	51	53	8	0
file_server	10957	30	25.89	30	0
file_server	10957	35	18	40	0
file_server	10957	64	33.25	8	0
file_server	10958	5	21.35	20	0
file_server	10958	7	30	6	0
file_server	10958	72	34.8	5	0
file_server	10959	75	7.75	20	0.15
file_server	10960	24	4.5	10	0.25
file_server	10960	41	9.65	24	0
file_server	10961	52	7	6	0.05
file_server	10961	76	18	60	0
file_server	10962	7	30	45	0
file_server	10962	13	6	77	0
file_server	10962	53	32.8	20	0
file_server	10962	69	36	9	0
file_server	10962	76	18	44	0
file_server	10963	60	34	2	0.15
file_server	10964	18	62.5	6	0
file_server	10964	38	263.5	5	0
file_server	10964	69	36	10	0
file_server	10965	51	53	16	0
file_server	10966	37	26	8	0
file_server	10966	56	38	12	0.15
file_server	10966	62	49.3	12	0.15
file_server	10967	19	9.2	12	0
file_server	10967	49	20	40	0
file_server	10968	12	38	30	0
file_server	10968	24	4.5	30	0
file_server	10968	64	33.25	4	0
file_server	10969	46	12	9	0
file_server	10970	52	7	40	0.2
file_server	10971	29	123.79	14	0
file_server	10972	17	39	6	0
file_server	10972	33	2.5	7	0
file_server	10973	26	31.23	5	0
file_server	10973	41	9.65	6	0
file_server	10973	75	7.75	10	0
file_server	10974	63	43.9	10	0
file_server	10975	8	40	16	0
file_server	10975	75	7.75	10	0
file_server	10976	28	45.6	20	0
file_server	10977	39	18	30	0
file_server	10977	47	9.5	30	0
file_server	10977	51	53	10	0
file_server	10977	63	43.9	20	0
file_server	10978	8	40	20	0.15
file_server	10978	21	10	40	0.15
file_server	10978	40	18.4	10	0
file_server	10978	44	19.45	6	0.15
file_server	10979	7	30	18	0
file_server	10979	12	38	20	0
file_server	10979	24	4.5	80	0
file_server	10979	27	43.9	30	0
file_server	10979	31	12.5	24	0
file_server	10979	63	43.9	35	0
file_server	10980	75	7.75	40	0.2
file_server	10981	38	263.5	60	0
file_server	10982	7	30	20	0
file_server	10982	43	46	9	0
file_server	10983	13	6	84	0.15
file_server	10983	57	19.5	15	0
file_server	10984	16	17.45	55	0
file_server	10984	24	4.5	20	0
file_server	10984	36	19	40	0
file_server	10985	16	17.45	36	0.1
file_server	10985	18	62.5	8	0.1
file_server	10985	32	32	35	0.1
file_server	10986	11	21	30	0
file_server	10986	20	81	15	0
file_server	10986	76	18	10	0
file_server	10986	77	13	15	0
file_server	10987	7	30	60	0
file_server	10987	43	46	6	0
file_server	10987	72	34.8	20	0
file_server	10988	7	30	60	0
file_server	10988	62	49.3	40	0.1
file_server	10989	6	25	40	0
file_server	10989	11	21	15	0
file_server	10989	41	9.65	4	0
file_server	10990	21	10	65	0
file_server	10990	34	14	60	0.15
file_server	10990	55	24	65	0.15
file_server	10990	61	28.5	66	0.15
file_server	10991	2	19	50	0.2
file_server	10991	70	15	20	0.2
file_server	10991	76	18	90	0.2
file_server	10992	72	34.8	2	0
file_server	10993	29	123.79	50	0.25
file_server	10993	41	9.65	35	0.25
file_server	10994	59	55	18	0.05
file_server	10995	51	53	20	0
file_server	10995	60	34	4	0
file_server	10996	42	14	40	0
file_server	10997	32	32	50	0
file_server	10997	46	12	20	0.25
file_server	10997	52	7	20	0.25
file_server	10998	24	4.5	12	0
file_server	10998	61	28.5	7	0
file_server	10998	74	10	20	0
file_server	10998	75	7.75	30	0
file_server	10999	41	9.65	20	0.05
file_server	10999	51	53	15	0.05
file_server	10999	77	13	21	0.05
file_server	11000	4	22	25	0.25
file_server	11000	24	4.5	30	0.25
file_server	11000	77	13	30	0
file_server	11001	7	30	60	0
file_server	11001	22	21	25	0
file_server	11001	46	12	25	0
file_server	11001	55	24	6	0
file_server	11002	13	6	56	0
file_server	11002	35	18	15	0.15
file_server	11002	42	14	24	0.15
file_server	11002	55	24	40	0
file_server	11003	1	18	4	0
file_server	11003	40	18.4	10	0
file_server	11003	52	7	10	0
file_server	11004	26	31.23	6	0
file_server	11004	76	18	6	0
file_server	11005	1	18	2	0
file_server	11005	59	55	10	0
file_server	11006	1	18	8	0
file_server	11006	29	123.79	2	0.25
file_server	11007	8	40	30	0
file_server	11007	29	123.79	10	0
file_server	11007	42	14	14	0
file_server	11008	28	45.6	70	0.05
file_server	11008	34	14	90	0.05
file_server	11008	71	21.5	21	0
file_server	11009	24	4.5	12	0
file_server	11009	36	19	18	0.25
file_server	11009	60	34	9	0
file_server	11010	7	30	20	0
file_server	11010	24	4.5	10	0
file_server	11011	58	13.25	40	0.05
file_server	11011	71	21.5	20	0
file_server	11012	19	9.2	50	0.05
file_server	11012	60	34	36	0.05
file_server	11012	71	21.5	60	0.05
file_server	11013	23	9	10	0
file_server	11013	42	14	4	0
file_server	11013	45	9.5	20	0
file_server	11013	68	12.5	2	0
file_server	11014	41	9.65	28	0.1
file_server	11015	30	25.89	15	0
file_server	11015	77	13	18	0
file_server	11016	31	12.5	15	0
file_server	11016	36	19	16	0
file_server	11017	3	10	25	0
file_server	11017	59	55	110	0
file_server	11017	70	15	30	0
file_server	11018	12	38	20	0
file_server	11018	18	62.5	10	0
file_server	11018	56	38	5	0
file_server	11019	46	12	3	0
file_server	11019	49	20	2	0
file_server	11020	10	31	24	0.15
file_server	11021	2	19	11	0.25
file_server	11021	20	81	15	0
file_server	11021	26	31.23	63	0
file_server	11021	51	53	44	0.25
file_server	11021	72	34.8	35	0
file_server	11022	19	9.2	35	0
file_server	11022	69	36	30	0
file_server	11023	7	30	4	0
file_server	11023	43	46	30	0
file_server	11024	26	31.23	12	0
file_server	11024	33	2.5	30	0
file_server	11024	65	21.05	21	0
file_server	11024	71	21.5	50	0
file_server	11025	1	18	10	0.1
file_server	11025	13	6	20	0.1
file_server	11026	18	62.5	8	0
file_server	11026	51	53	10	0
file_server	11027	24	4.5	30	0.25
file_server	11027	62	49.3	21	0.25
file_server	11028	55	24	35	0
file_server	11028	59	55	24	0
file_server	11029	56	38	20	0
file_server	11029	63	43.9	12	0
file_server	11030	2	19	100	0.25
file_server	11030	5	21.35	70	0
file_server	11030	29	123.79	60	0.25
file_server	11030	59	55	100	0.25
file_server	11031	1	18	45	0
file_server	11031	13	6	80	0
file_server	11031	24	4.5	21	0
file_server	11031	64	33.25	20	0
file_server	11031	71	21.5	16	0
file_server	11032	36	19	35	0
file_server	11032	38	263.5	25	0
file_server	11032	59	55	30	0
file_server	11033	53	32.8	70	0.1
file_server	11033	69	36	36	0.1
file_server	11034	21	10	15	0.1
file_server	11034	44	19.45	12	0
file_server	11034	61	28.5	6	0
file_server	11035	1	18	10	0
file_server	11035	35	18	60	0
file_server	11035	42	14	30	0
file_server	11035	54	7.45	10	0
file_server	11036	13	6	7	0
file_server	11036	59	55	30	0
file_server	11037	70	15	4	0
file_server	11038	40	18.4	5	0.2
file_server	11038	52	7	2	0
file_server	11038	71	21.5	30	0
file_server	11039	28	45.6	20	0
file_server	11039	35	18	24	0
file_server	11039	49	20	60	0
file_server	11039	57	19.5	28	0
file_server	11040	21	10	20	0
file_server	11041	2	19	30	0.2
file_server	11041	63	43.9	30	0
file_server	11042	44	19.45	15	0
file_server	11042	61	28.5	4	0
file_server	11043	11	21	10	0
file_server	11044	62	49.3	12	0
file_server	11045	33	2.5	15	0
file_server	11045	51	53	24	0
file_server	11046	12	38	20	0.05
file_server	11046	32	32	15	0.05
file_server	11046	35	18	18	0.05
file_server	11047	1	18	25	0.25
file_server	11047	5	21.35	30	0.25
file_server	11048	68	12.5	42	0
file_server	11049	2	19	10	0.2
file_server	11049	12	38	4	0.2
file_server	11050	76	18	50	0.1
file_server	11051	24	4.5	10	0.2
file_server	11052	43	46	30	0.2
file_server	11052	61	28.5	10	0.2
file_server	11053	18	62.5	35	0.2
file_server	11053	32	32	20	0
file_server	11053	64	33.25	25	0.2
file_server	11054	33	2.5	10	0
file_server	11054	67	14	20	0
file_server	11055	24	4.5	15	0
file_server	11055	25	14	15	0
file_server	11055	51	53	20	0
file_server	11055	57	19.5	20	0
file_server	11056	7	30	40	0
file_server	11056	55	24	35	0
file_server	11056	60	34	50	0
file_server	11057	70	15	3	0
file_server	11058	21	10	3	0
file_server	11058	60	34	21	0
file_server	11058	61	28.5	4	0
file_server	11059	13	6	30	0
file_server	11059	17	39	12	0
file_server	11059	60	34	35	0
file_server	11060	60	34	4	0
file_server	11060	77	13	10	0
file_server	11061	60	34	15	0
file_server	11062	53	32.8	10	0.2
file_server	11062	70	15	12	0.2
file_server	11063	34	14	30	0
file_server	11063	40	18.4	40	0.1
file_server	11063	41	9.65	30	0.1
file_server	11064	17	39	77	0.1
file_server	11064	41	9.65	12	0
file_server	11064	53	32.8	25	0.1
file_server	11064	55	24	4	0.1
file_server	11064	68	12.5	55	0
file_server	11065	30	25.89	4	0.25
file_server	11065	54	7.45	20	0.25
file_server	11066	16	17.45	3	0
file_server	11066	19	9.2	42	0
file_server	11066	34	14	35	0
file_server	11067	41	9.65	9	0
file_server	11068	28	45.6	8	0.15
file_server	11068	43	46	36	0.15
file_server	11068	77	13	28	0.15
file_server	11069	39	18	20	0
file_server	11070	1	18	40	0.15
file_server	11070	2	19	20	0.15
file_server	11070	16	17.45	30	0.15
file_server	11070	31	12.5	20	0
file_server	11071	7	30	15	0.05
file_server	11071	13	6	10	0.05
file_server	11072	2	19	8	0
file_server	11072	41	9.65	40	0
file_server	11072	50	16.25	22	0
file_server	11072	64	33.25	130	0
file_server	11073	11	21	10	0
file_server	11073	24	4.5	20	0
file_server	11074	16	17.45	14	0.05
file_server	11075	2	19	10	0.15
file_server	11075	46	12	30	0.15
file_server	11075	76	18	2	0.15
file_server	11076	6	25	20	0.25
file_server	11076	14	23.25	20	0.25
file_server	11076	19	9.2	10	0.25
file_server	11077	2	19	24	0.2
file_server	11077	3	10	4	0
file_server	11077	4	22	1	0
file_server	11077	6	25	1	0.02
file_server	11077	7	30	1	0.05
file_server	11077	8	40	2	0.1
file_server	11077	10	31	1	0
file_server	11077	12	38	2	0.05
file_server	11077	13	6	4	0
file_server	11077	14	23.25	1	0.03
file_server	11077	16	17.45	2	0.03
file_server	11077	20	81	1	0.04
file_server	11077	23	9	2	0
file_server	11077	32	32	1	0
file_server	11077	39	18	2	0.05
file_server	11077	41	9.65	3	0
file_server	11077	46	12	3	0.02
file_server	11077	52	7	2	0
file_server	11077	55	24	2	0
file_server	11077	60	34	2	0.06
file_server	11077	64	33.25	2	0.03
file_server	11077	66	17	1	0
file_server	11077	73	15	2	0.01
file_server	11077	75	7.75	4	0
file_server	11077	77	13	2	0
\.


--
-- Data for Name: structured_file_server_orders_2017; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_orders_2017 (permission_scope_key, orderid, customerid, employeeid, orderdate, requireddate, shippeddate, shipperid, freight) FROM stdin;
file_server	10248	VINET	5	2017-01-01	2017-01-29	2017-01-13	3	32.38
file_server	10249	TOMSP	6	2017-01-03 11:07:25	2017-02-14 11:07:25	2017-01-08 11:07:25	1	11.61
file_server	10250	HANAR	4	2017-01-10 20:29:41	2017-02-07 20:29:41	2017-01-14 20:29:41	2	65.83
file_server	10251	VICTE	3	2017-01-10 20:29:41	2017-02-07 20:29:41	2017-01-17 20:29:41	1	41.34
file_server	10252	SUPRD	4	2017-01-13 07:37:07	2017-02-10 07:37:07	2017-01-15 07:37:07	2	51.3
file_server	10253	HANAR	3	2017-01-15 18:44:32	2017-01-29 18:44:32	2017-01-21 18:44:32	2	58.17
file_server	10254	CHOPS	5	2017-01-18 05:51:57	2017-02-15 05:51:57	2017-01-30 05:51:57	2	22.98
file_server	10255	RICSU	9	2017-01-20 16:59:22	2017-02-17 16:59:22	2017-01-23 16:59:22	3	148.33
file_server	10256	WELLI	3	2017-01-28 02:21:38	2017-02-25 02:21:38	2017-01-30 02:21:38	2	13.97
file_server	10257	HILAA	4	2017-01-30 13:29:04	2017-02-27 13:29:04	2017-02-05 13:29:04	3	81.91
file_server	10258	ERNSH	1	2017-02-02 00:36:29	2017-03-02 00:36:29	2017-02-08 00:36:29	1	140.51
file_server	10259	CENTC	4	2017-02-04 11:43:54	2017-03-04 11:43:54	2017-02-11 11:43:54	3	3.25
file_server	10260	OTTIK	4	2017-02-06 22:51:20	2017-03-06 22:51:20	2017-02-16 22:51:20	1	55.09
file_server	10261	QUEDE	4	2017-02-06 22:51:20	2017-03-06 22:51:20	2017-02-17 22:51:20	2	3.05
file_server	10262	RATTC	8	2017-02-14 08:13:35	2017-03-14 08:13:35	2017-02-17 08:13:35	3	48.29
file_server	10263	ERNSH	9	2017-02-16 19:21:01	2017-03-16 19:21:01	2017-02-24 19:21:01	3	146.06
file_server	10264	FOLKO	6	2017-02-19 06:28:26	2017-03-19 06:28:26	2017-03-21 06:28:26	3	3.67
file_server	10265	BLONP	2	2017-02-21 17:35:51	2017-03-21 17:35:51	2017-03-11 17:35:51	1	55.28
file_server	10266	WARTH	3	2017-02-24 04:43:17	2017-04-07 04:43:17	2017-03-01 04:43:17	3	25.73
file_server	10267	FRANK	4	2017-03-03 14:05:33	2017-03-31 14:05:33	2017-03-11 14:05:33	1	208.58
file_server	10268	GROSR	8	2017-03-06 01:12:58	2017-04-03 01:12:58	2017-03-09 01:12:58	3	66.29
file_server	10269	WHITC	5	2017-03-08 12:20:23	2017-03-22 12:20:23	2017-03-17 12:20:23	1	4.56
file_server	10270	WARTH	1	2017-03-10 23:27:49	2017-04-07 23:27:49	2017-03-11 23:27:49	1	136.54
file_server	10271	SPLIR	6	2017-03-10 23:27:49	2017-04-07 23:27:49	2017-04-08 23:27:49	2	4.54
file_server	10272	RATTC	6	2017-03-13 10:35:14	2017-04-10 10:35:14	2017-03-17 10:35:14	2	98.03
file_server	10273	QUICK	3	2017-03-20 19:57:30	2017-04-17 19:57:30	2017-03-27 19:57:30	3	76.07
file_server	10274	VINET	6	2017-03-23 07:04:55	2017-04-20 07:04:55	2017-04-02 07:04:55	1	6.01
file_server	10275	MAGAA	1	2017-03-25 18:12:20	2017-04-22 18:12:20	2017-03-27 18:12:20	1	26.93
file_server	10276	TORTU	8	2017-03-28 05:19:46	2017-04-11 05:19:46	2017-04-03 05:19:46	3	13.84
file_server	10277	MORGK	2	2017-03-30 16:27:11	2017-04-27 16:27:11	2017-04-03 16:27:11	3	125.77
file_server	10278	BERGS	8	2017-04-07 01:49:27	2017-05-05 01:49:27	2017-04-11 01:49:27	2	92.69
file_server	10279	LEHMS	8	2017-04-09 12:56:52	2017-05-07 12:56:52	2017-04-12 12:56:52	2	25.83
file_server	10280	BERGS	2	2017-04-12 00:04:18	2017-05-10 00:04:18	2017-05-11 00:04:18	1	8.98
file_server	10281	ROMEY	4	2017-04-12 00:04:18	2017-04-26 00:04:18	2017-04-19 00:04:18	1	2.94
file_server	10282	ROMEY	4	2017-04-14 11:11:43	2017-05-12 11:11:43	2017-04-20 11:11:43	1	12.69
file_server	10283	LILAS	3	2017-04-16 22:19:08	2017-05-14 22:19:08	2017-04-23 22:19:08	3	84.81
file_server	10284	LEHMS	4	2017-04-24 07:41:24	2017-05-22 07:41:24	2017-05-02 07:41:24	1	76.56
file_server	10285	QUICK	1	2017-04-26 18:48:49	2017-05-24 18:48:49	2017-05-02 18:48:49	2	76.83
file_server	10286	QUICK	8	2017-04-29 05:56:15	2017-05-27 05:56:15	2017-05-08 05:56:15	3	229.24
file_server	10287	RICAR	8	2017-05-01 17:03:40	2017-05-29 17:03:40	2017-05-07 17:03:40	3	12.76
file_server	10288	REGGC	4	2017-05-04 04:11:05	2017-06-01 04:11:05	2017-05-15 04:11:05	1	7.45
file_server	10289	BSBEV	7	2017-05-11 13:33:21	2017-06-08 13:33:21	2017-05-13 13:33:21	3	22.77
file_server	10290	COMMI	8	2017-05-14 00:40:46	2017-06-11 00:40:46	2017-05-21 00:40:46	1	79.7
file_server	10291	QUEDE	6	2017-05-14 00:40:46	2017-06-11 00:40:46	2017-05-22 00:40:46	2	6.4
file_server	10292	TRADH	1	2017-05-16 11:48:12	2017-06-13 11:48:12	2017-05-21 11:48:12	2	1.35
file_server	10293	TORTU	1	2017-05-18 22:55:37	2017-06-15 22:55:37	2017-05-31 22:55:37	3	21.18
file_server	10294	RATTC	4	2017-05-21 10:03:02	2017-06-18 10:03:02	2017-05-27 10:03:02	2	147.26
file_server	10295	VINET	2	2017-05-28 19:25:18	2017-06-25 19:25:18	2017-06-05 19:25:18	2	1.15
file_server	10296	LILAS	6	2017-05-31 06:32:44	2017-06-28 06:32:44	2017-06-08 06:32:44	1	0.12
file_server	10297	BLONP	5	2017-06-02 17:40:09	2017-07-14 17:40:09	2017-06-08 17:40:09	2	5.74
file_server	10298	HUNGO	6	2017-06-05 04:47:34	2017-07-03 04:47:34	2017-06-11 04:47:34	2	168.22
file_server	10299	RICAR	4	2017-06-07 15:55:00	2017-07-05 15:55:00	2017-06-14 15:55:00	2	29.76
file_server	10300	MAGAA	2	2017-06-15 01:17:15	2017-07-13 01:17:15	2017-06-24 01:17:15	2	17.68
file_server	10301	WANDK	8	2017-06-15 01:17:15	2017-07-13 01:17:15	2017-06-23 01:17:15	2	45.08
file_server	10302	SUPRD	4	2017-06-17 12:24:41	2017-07-15 12:24:41	2017-07-16 12:24:41	2	6.27
file_server	10303	GODOS	7	2017-06-19 23:32:06	2017-07-17 23:32:06	2017-06-26 23:32:06	2	107.83
file_server	10304	TORTU	1	2017-06-22 10:39:31	2017-07-20 10:39:31	2017-06-27 10:39:31	2	63.79
file_server	10305	OLDWO	8	2017-06-24 21:46:57	2017-07-22 21:46:57	2017-07-20 21:46:57	3	257.62
file_server	10306	ROMEY	1	2017-07-02 07:09:13	2017-07-30 07:09:13	2017-07-09 07:09:13	3	7.56
file_server	10307	LONEP	2	2017-07-04 18:16:38	2017-08-01 18:16:38	2017-07-12 18:16:38	2	0.56
file_server	10308	ANATR	7	2017-07-07 05:24:03	2017-08-04 05:24:03	2017-07-13 05:24:03	3	1.61
file_server	10309	HUNGO	3	2017-07-09 16:31:29	2017-08-06 16:31:29	2017-08-12 16:31:29	1	47.3
file_server	10310	THEBI	8	2017-07-12 03:38:54	2017-08-09 03:38:54	2017-07-19 03:38:54	2	17.52
file_server	10311	DUMON	1	2017-07-12 03:38:54	2017-07-26 03:38:54	2017-07-18 03:38:54	3	24.69
file_server	10312	WANDK	2	2017-07-19 13:01:10	2017-08-16 13:01:10	2017-07-29 13:01:10	2	40.26
file_server	10313	QUICK	2	2017-07-22 00:08:35	2017-08-19 00:08:35	2017-08-01 00:08:35	2	1.96
file_server	10314	RATTC	1	2017-07-24 11:16:00	2017-08-21 11:16:00	2017-08-02 11:16:00	2	74.16
file_server	10315	ISLAT	4	2017-07-26 22:23:26	2017-08-23 22:23:26	2017-08-02 22:23:26	2	41.76
file_server	10316	RATTC	1	2017-07-29 09:30:51	2017-08-26 09:30:51	2017-08-09 09:30:51	3	150.15
file_server	10317	LONEP	6	2017-08-05 18:53:07	2017-09-02 18:53:07	2017-08-15 18:53:07	1	12.69
file_server	10318	ISLAT	8	2017-08-08 06:00:32	2017-09-05 06:00:32	2017-08-11 06:00:32	2	4.73
file_server	10319	TORTU	7	2017-08-10 17:07:57	2017-09-07 17:07:57	2017-08-19 17:07:57	3	64.5
file_server	10320	WARTH	5	2017-08-13 04:15:23	2017-08-27 04:15:23	2017-08-28 04:15:23	3	34.57
file_server	10321	ISLAT	3	2017-08-13 04:15:23	2017-09-10 04:15:23	2017-08-21 04:15:23	2	3.43
file_server	10322	PERIC	7	2017-08-15 15:22:48	2017-09-12 15:22:48	2017-09-03 15:22:48	3	0.4
file_server	10323	KOENE	4	2017-08-23 00:45:04	2017-09-20 00:45:04	2017-08-30 00:45:04	1	4.88
file_server	10324	SAVEA	9	2017-08-25 11:52:29	2017-09-22 11:52:29	2017-08-27 11:52:29	1	214.27
file_server	10325	KOENE	1	2017-08-27 22:59:55	2017-09-10 22:59:55	2017-09-01 22:59:55	3	64.86
file_server	10326	BOLID	4	2017-08-30 10:07:20	2017-09-27 10:07:20	2017-09-03 10:07:20	2	77.92
file_server	10327	FOLKO	2	2017-09-01 21:14:45	2017-09-29 21:14:45	2017-09-04 21:14:45	1	63.36
file_server	10328	FURIB	4	2017-09-09 06:37:01	2017-10-07 06:37:01	2017-09-12 06:37:01	3	87.03
file_server	10329	SPLIR	4	2017-09-11 17:44:26	2017-10-23 17:44:26	2017-09-19 17:44:26	2	191.67
file_server	10330	LILAS	3	2017-09-14 04:51:52	2017-10-12 04:51:52	2017-09-26 04:51:52	1	12.75
file_server	10331	BONAP	9	2017-09-14 04:51:52	2017-10-26 04:51:52	2017-09-19 04:51:52	1	10.19
file_server	10332	MEREP	3	2017-09-16 15:59:17	2017-10-28 15:59:17	2017-09-20 15:59:17	2	52.84
file_server	10333	WARTH	5	2017-09-19 03:06:42	2017-10-17 03:06:42	2017-09-26 03:06:42	3	0.59
file_server	10334	VICTE	8	2017-09-26 12:28:58	2017-10-24 12:28:58	2017-10-03 12:28:58	2	8.56
file_server	10335	HUNGO	7	2017-09-28 23:36:24	2017-10-26 23:36:24	2017-09-30 23:36:24	2	42.11
file_server	10336	PRINI	7	2017-10-01 10:43:49	2017-10-29 10:43:49	2017-10-03 10:43:49	2	15.51
file_server	10337	FRANK	4	2017-10-03 21:51:14	2017-10-31 21:51:14	2017-10-08 21:51:14	3	108.26
file_server	10338	OLDWO	4	2017-10-06 08:58:40	2017-11-03 08:58:40	2017-10-10 08:58:40	3	84.21
file_server	10339	MEREP	2	2017-10-13 18:20:55	2017-11-10 18:20:55	2017-10-20 18:20:55	2	15.66
file_server	10340	BONAP	1	2017-10-16 05:28:21	2017-11-13 05:28:21	2017-10-26 05:28:21	3	166.31
file_server	10341	SIMOB	7	2017-10-16 05:28:21	2017-11-13 05:28:21	2017-10-23 05:28:21	3	26.78
file_server	10342	FRANK	4	2017-10-18 16:35:46	2017-11-01 16:35:46	2017-10-23 16:35:46	2	54.83
file_server	10343	LEHMS	4	2017-10-21 03:43:11	2017-11-18 03:43:11	2017-10-27 03:43:11	1	110.37
file_server	10344	WHITC	4	2017-10-23 14:50:37	2017-11-20 14:50:37	2017-10-27 14:50:37	2	23.29
file_server	10345	QUICK	2	2017-10-31 00:12:53	2017-11-28 00:12:53	2017-11-07 00:12:53	2	249.06
file_server	10346	RATTC	3	2017-11-02 11:20:18	2017-12-14 11:20:18	2017-11-05 11:20:18	3	142.08
file_server	10347	FAMIA	4	2017-11-04 22:27:43	2017-12-02 22:27:43	2017-11-06 22:27:43	3	3.1
file_server	10348	WANDK	4	2017-11-07 09:35:08	2017-12-05 09:35:08	2017-11-15 09:35:08	2	0.78
file_server	10349	SPLIR	7	2017-11-09 20:42:34	2017-12-07 20:42:34	2017-11-16 20:42:34	1	8.63
file_server	10350	LAMAI	6	2017-11-17 06:04:50	2017-12-15 06:04:50	2017-12-09 06:04:50	2	64.19
file_server	10351	ERNSH	1	2017-11-17 06:04:50	2017-12-15 06:04:50	2017-11-26 06:04:50	1	162.33
file_server	10352	FURIB	3	2017-11-19 17:12:15	2017-12-03 17:12:15	2017-11-25 17:12:15	3	1.3
file_server	10353	PICCO	7	2017-11-22 04:19:40	2017-12-20 04:19:40	2017-12-04 04:19:40	3	360.63
file_server	10354	PERIC	8	2017-11-24 15:27:06	2017-12-22 15:27:06	2017-11-30 15:27:06	3	53.8
file_server	10355	AROUT	6	2017-11-27 02:34:31	2017-12-25 02:34:31	2017-12-02 02:34:31	1	41.95
file_server	10356	WANDK	6	2017-12-04 11:56:47	2018-01-01 11:56:47	2017-12-13 11:56:47	2	36.71
file_server	10357	LILAS	1	2017-12-06 23:04:12	2018-01-03 23:04:12	2017-12-19 23:04:12	3	34.88
file_server	10358	LAMAI	5	2017-12-09 10:11:37	2018-01-06 10:11:37	2017-12-16 10:11:37	1	19.64
file_server	10359	SEVES	5	2017-12-11 21:19:03	2018-01-08 21:19:03	2017-12-16 21:19:03	3	288.43
file_server	10360	BLONP	4	2017-12-14 08:26:28	2018-01-11 08:26:28	2017-12-24 08:26:28	3	131.7
file_server	10361	QUICK	1	2017-12-14 08:26:28	2018-01-11 08:26:28	2017-12-25 08:26:28	2	183.17
file_server	10362	BONAP	3	2017-12-21 17:48:44	2018-01-18 17:48:44	2017-12-24 17:48:44	1	96.04
file_server	10363	DRACD	4	2017-12-24 04:56:09	2018-01-21 04:56:09	2018-01-01 04:56:09	3	30.54
file_server	10364	EASTC	1	2017-12-24 04:56:09	2018-02-04 04:56:09	2018-01-01 04:56:09	1	71.97
file_server	10365	ANTON	3	2017-12-26 16:03:35	2018-01-23 16:03:35	2017-12-31 16:03:35	2	22
file_server	10366	GALED	8	2017-12-29 03:11:00	2018-02-09 03:11:00	2018-01-30 03:11:00	2	10.14
file_server	10367	VAFFE	7	2017-12-29 03:11:00	2018-01-26 03:11:00	2018-01-02 03:11:00	3	13.55
file_server	10368	ERNSH	2	2017-12-31 14:18:25	2018-01-28 14:18:25	2018-01-03 14:18:25	2	101.95
\.


--
-- Data for Name: structured_file_server_orders_2018; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_orders_2018 (permission_scope_key, orderid, customerid, employeeid, orderdate, requireddate, shippeddate, shipperid, freight) FROM stdin;
file_server	10369	SPLIR	8	2018-01-07 23:40:41	2018-02-04 23:40:41	2018-01-14 23:40:41	2	195.68
file_server	10370	CHOPS	6	2018-01-10 10:48:06	2018-02-07 10:48:06	2018-02-03 10:48:06	2	1.17
file_server	10371	LAMAI	1	2018-01-10 10:48:06	2018-02-07 10:48:06	2018-01-31 10:48:06	1	0.45
file_server	10372	QUEEN	5	2018-01-12 21:55:32	2018-02-09 21:55:32	2018-01-17 21:55:32	2	890.78
file_server	10373	HUNGO	4	2018-01-15 09:02:57	2018-02-12 09:02:57	2018-01-21 09:02:57	3	124.12
file_server	10374	WOLZA	1	2018-01-15 09:02:57	2018-02-12 09:02:57	2018-01-19 09:02:57	3	3.94
file_server	10375	HUNGC	3	2018-01-17 20:10:22	2018-02-14 20:10:22	2018-01-20 20:10:22	2	20.12
file_server	10376	MEREP	1	2018-01-25 05:32:38	2018-02-22 05:32:38	2018-01-29 05:32:38	2	20.39
file_server	10377	SEVES	1	2018-01-25 05:32:38	2018-02-22 05:32:38	2018-01-29 05:32:38	3	22.21
file_server	10378	FOLKO	5	2018-01-27 16:40:04	2018-02-24 16:40:04	2018-02-05 16:40:04	3	5.44
file_server	10379	QUEDE	2	2018-01-30 03:47:29	2018-02-27 03:47:29	2018-02-01 03:47:29	1	45.03
file_server	10380	HUNGO	8	2018-02-01 14:54:54	2018-03-01 14:54:54	2018-03-08 14:54:54	3	35.03
file_server	10381	LILAS	3	2018-02-01 14:54:54	2018-03-01 14:54:54	2018-02-02 14:54:54	3	7.99
file_server	10382	ERNSH	4	2018-02-04 02:02:19	2018-03-04 02:02:19	2018-02-07 02:02:19	1	94.77
file_server	10383	AROUT	8	2018-02-11 11:24:35	2018-03-11 11:24:35	2018-02-13 11:24:35	3	34.24
file_server	10384	BERGS	3	2018-02-11 11:24:35	2018-03-11 11:24:35	2018-02-15 11:24:35	3	168.64
file_server	10385	SPLIR	1	2018-02-13 22:32:01	2018-03-13 22:32:01	2018-02-19 22:32:01	2	30.96
file_server	10386	FAMIA	9	2018-02-16 09:39:26	2018-03-02 09:39:26	2018-02-23 09:39:26	3	13.99
file_server	10387	SANTG	1	2018-02-16 09:39:26	2018-03-16 09:39:26	2018-02-18 09:39:26	2	93.63
file_server	10388	SEVES	2	2018-02-18 20:46:51	2018-03-18 20:46:51	2018-02-19 20:46:51	1	34.86
file_server	10389	BOTTM	4	2018-02-21 07:54:17	2018-03-21 07:54:17	2018-02-25 07:54:17	2	47.42
file_server	10390	ERNSH	6	2018-02-28 17:16:33	2018-03-28 17:16:33	2018-03-03 17:16:33	1	126.38
file_server	10391	DRACD	3	2018-02-28 17:16:33	2018-03-28 17:16:33	2018-03-08 17:16:33	3	5.45
file_server	10392	PICCO	2	2018-03-03 04:23:58	2018-03-31 04:23:58	2018-03-11 04:23:58	3	122.46
file_server	10393	SAVEA	1	2018-03-05 15:31:23	2018-04-02 15:31:23	2018-03-14 15:31:23	3	126.56
file_server	10394	HUNGC	1	2018-03-05 15:31:23	2018-04-02 15:31:23	2018-03-14 15:31:23	3	30.34
file_server	10395	HILAA	6	2018-03-08 02:38:48	2018-04-05 02:38:48	2018-03-16 02:38:48	1	184.41
file_server	10396	FRANK	1	2018-03-10 13:46:14	2018-03-24 13:46:14	2018-03-20 13:46:14	3	135.35
file_server	10397	PRINI	5	2018-03-10 13:46:14	2018-04-07 13:46:14	2018-03-16 13:46:14	1	60.26
file_server	10398	SAVEA	2	2018-03-17 23:08:30	2018-04-14 23:08:30	2018-03-27 23:08:30	3	89.16
file_server	10399	VAFFE	8	2018-03-20 10:15:55	2018-04-03 10:15:55	2018-03-28 10:15:55	3	27.36
file_server	10400	EASTC	1	2018-03-22 21:23:20	2018-04-19 21:23:20	2018-04-06 21:23:20	3	83.93
file_server	10401	RATTC	1	2018-03-22 21:23:20	2018-04-19 21:23:20	2018-03-31 21:23:20	1	12.51
file_server	10402	ERNSH	8	2018-03-25 08:30:46	2018-05-06 08:30:46	2018-04-02 08:30:46	2	67.88
file_server	10403	ERNSH	4	2018-03-27 19:38:11	2018-04-24 19:38:11	2018-04-02 19:38:11	3	73.79
file_server	10404	MAGAA	2	2018-03-27 19:38:11	2018-04-24 19:38:11	2018-04-01 19:38:11	1	155.97
file_server	10405	LINOD	1	2018-04-04 05:00:27	2018-05-02 05:00:27	2018-04-20 05:00:27	1	34.82
file_server	10406	QUEEN	7	2018-04-06 16:07:52	2018-05-18 16:07:52	2018-04-12 16:07:52	1	108.04
file_server	10407	OTTIK	2	2018-04-06 16:07:52	2018-05-04 16:07:52	2018-04-29 16:07:52	2	91.48
file_server	10408	FOLIG	8	2018-04-09 03:15:17	2018-05-07 03:15:17	2018-04-15 03:15:17	1	11.26
file_server	10409	OCEAN	3	2018-04-11 14:22:43	2018-05-09 14:22:43	2018-04-16 14:22:43	1	29.83
file_server	10410	BOTTM	3	2018-04-14 01:30:08	2018-05-12 01:30:08	2018-04-19 01:30:08	3	2.4
file_server	10411	BOTTM	9	2018-04-14 01:30:08	2018-05-12 01:30:08	2018-04-25 01:30:08	3	23.65
file_server	10412	WARTH	8	2018-04-21 10:52:24	2018-05-19 10:52:24	2018-04-23 10:52:24	2	3.77
file_server	10413	LAMAI	3	2018-04-23 21:59:49	2018-05-21 21:59:49	2018-04-25 21:59:49	2	95.66
file_server	10414	FAMIA	2	2018-04-23 21:59:49	2018-05-21 21:59:49	2018-04-26 21:59:49	3	21.48
file_server	10415	HUNGC	3	2018-04-26 09:07:15	2018-05-24 09:07:15	2018-05-05 09:07:15	1	0.2
file_server	10416	WARTH	8	2018-04-28 20:14:40	2018-05-26 20:14:40	2018-05-09 20:14:40	3	22.72
file_server	10417	SIMOB	4	2018-04-28 20:14:40	2018-05-26 20:14:40	2018-05-10 20:14:40	3	70.29
file_server	10418	QUICK	4	2018-05-01 07:22:05	2018-05-29 07:22:05	2018-05-08 07:22:05	1	17.55
file_server	10419	RICSU	4	2018-05-08 16:44:21	2018-06-05 16:44:21	2018-05-18 16:44:21	2	137.35
file_server	10420	WELLI	3	2018-05-11 03:51:46	2018-06-08 03:51:46	2018-05-17 03:51:46	1	44.12
file_server	10421	QUEDE	8	2018-05-11 03:51:46	2018-06-22 03:51:46	2018-05-17 03:51:46	1	99.23
file_server	10422	FRANS	2	2018-05-13 14:59:12	2018-06-10 14:59:12	2018-05-22 14:59:12	1	3.02
file_server	10423	GOURL	6	2018-05-16 02:06:37	2018-05-30 02:06:37	2018-06-17 02:06:37	3	24.5
file_server	10424	MEREP	7	2018-05-16 02:06:37	2018-06-13 02:06:37	2018-05-20 02:06:37	2	370.61
file_server	10425	LAMAI	6	2018-05-18 13:14:02	2018-06-15 13:14:02	2018-06-08 13:14:02	2	7.93
file_server	10426	GALED	4	2018-05-25 22:36:18	2018-06-22 22:36:18	2018-06-04 22:36:18	1	18.69
file_server	10427	PICCO	4	2018-05-25 22:36:18	2018-06-22 22:36:18	2018-06-29 22:36:18	2	31.29
file_server	10428	REGGC	7	2018-05-28 09:43:44	2018-06-25 09:43:44	2018-06-04 09:43:44	1	11.09
file_server	10429	HUNGO	3	2018-05-30 20:51:09	2018-07-11 20:51:09	2018-06-08 20:51:09	2	56.63
file_server	10430	ERNSH	4	2018-06-02 07:58:34	2018-06-16 07:58:34	2018-06-06 07:58:34	1	458.78
file_server	10431	BOTTM	4	2018-06-02 07:58:34	2018-06-16 07:58:34	2018-06-10 07:58:34	2	44.17
file_server	10432	SPLIR	3	2018-06-04 19:05:59	2018-06-18 19:05:59	2018-06-11 19:05:59	2	4.34
file_server	10433	PRINI	3	2018-06-12 04:28:15	2018-07-10 04:28:15	2018-07-11 04:28:15	3	73.83
file_server	10434	FOLKO	3	2018-06-12 04:28:15	2018-07-10 04:28:15	2018-06-22 04:28:15	2	17.92
file_server	10435	CONSH	8	2018-06-14 15:35:41	2018-07-26 15:35:41	2018-06-17 15:35:41	2	9.21
file_server	10436	BLONP	3	2018-06-17 02:43:06	2018-07-15 02:43:06	2018-06-23 02:43:06	2	156.66
file_server	10437	WARTH	8	2018-06-17 02:43:06	2018-07-15 02:43:06	2018-06-24 02:43:06	1	19.97
file_server	10438	TOMSP	3	2018-06-19 13:50:31	2018-07-17 13:50:31	2018-06-27 13:50:31	2	8.24
file_server	10439	MEREP	6	2018-06-22 00:57:57	2018-07-20 00:57:57	2018-06-25 00:57:57	3	4.07
file_server	10440	SAVEA	4	2018-06-29 10:20:13	2018-07-27 10:20:13	2018-07-17 10:20:13	2	86.53
file_server	10441	OLDWO	3	2018-06-29 10:20:13	2018-08-10 10:20:13	2018-07-31 10:20:13	2	73.02
file_server	10442	ERNSH	3	2018-07-01 21:27:38	2018-07-29 21:27:38	2018-07-08 21:27:38	2	47.94
file_server	10443	REGGC	8	2018-07-04 08:35:03	2018-08-01 08:35:03	2018-07-06 08:35:03	1	13.95
file_server	10444	BERGS	3	2018-07-04 08:35:03	2018-08-01 08:35:03	2018-07-13 08:35:03	3	3.5
file_server	10445	BERGS	3	2018-07-06 19:42:28	2018-08-03 19:42:28	2018-07-13 19:42:28	1	9.3
file_server	10446	TOMSP	6	2018-07-09 06:49:54	2018-08-06 06:49:54	2018-07-14 06:49:54	1	14.68
file_server	10447	RICAR	4	2018-07-09 06:49:54	2018-08-06 06:49:54	2018-07-30 06:49:54	2	68.66
file_server	10448	RANCH	4	2018-07-16 16:12:10	2018-08-13 16:12:10	2018-07-23 16:12:10	2	38.82
file_server	10449	BLONP	3	2018-07-19 03:19:35	2018-08-16 03:19:35	2018-07-28 03:19:35	2	53.3
file_server	10450	VICTE	8	2018-07-21 14:27:00	2018-08-18 14:27:00	2018-08-10 14:27:00	2	7.23
file_server	10451	QUICK	4	2018-07-21 14:27:00	2018-08-04 14:27:00	2018-08-11 14:27:00	3	189.09
file_server	10452	SAVEA	8	2018-07-24 01:34:26	2018-08-21 01:34:26	2018-07-30 01:34:26	1	140.26
file_server	10453	AROUT	1	2018-07-26 12:41:51	2018-08-23 12:41:51	2018-07-31 12:41:51	2	25.36
file_server	10454	LAMAI	4	2018-07-26 12:41:51	2018-08-23 12:41:51	2018-07-30 12:41:51	3	2.74
file_server	10455	WARTH	8	2018-08-02 22:04:07	2018-09-13 22:04:07	2018-08-09 22:04:07	2	180.45
file_server	10456	KOENE	8	2018-08-05 09:11:32	2018-09-16 09:11:32	2018-08-08 09:11:32	2	8.12
file_server	10457	KOENE	2	2018-08-05 09:11:32	2018-09-02 09:11:32	2018-08-11 09:11:32	1	11.57
file_server	10458	SUPRD	7	2018-08-07 20:18:57	2018-09-04 20:18:57	2018-08-13 20:18:57	3	147.06
file_server	10459	VICTE	4	2018-08-10 07:26:23	2018-09-07 07:26:23	2018-08-11 07:26:23	2	25.09
file_server	10460	FOLKO	8	2018-08-12 18:33:48	2018-09-09 18:33:48	2018-08-15 18:33:48	1	16.27
file_server	10461	LILAS	1	2018-08-12 18:33:48	2018-09-09 18:33:48	2018-08-17 18:33:48	3	148.61
file_server	10462	CONSH	2	2018-08-20 03:56:04	2018-09-17 03:56:04	2018-09-04 03:56:04	1	6.17
file_server	10463	SUPRD	5	2018-08-22 15:03:29	2018-09-19 15:03:29	2018-08-24 15:03:29	3	14.78
file_server	10464	FURIB	4	2018-08-22 15:03:29	2018-09-19 15:03:29	2018-09-01 15:03:29	2	89
file_server	10465	VAFFE	1	2018-08-25 02:10:55	2018-09-22 02:10:55	2018-09-03 02:10:55	3	145.04
file_server	10466	COMMI	4	2018-08-27 13:18:20	2018-09-24 13:18:20	2018-09-03 13:18:20	1	11.93
file_server	10467	MAGAA	8	2018-08-27 13:18:20	2018-09-24 13:18:20	2018-09-01 13:18:20	2	4.93
file_server	10468	KOENE	3	2018-08-30 00:25:45	2018-09-27 00:25:45	2018-09-04 00:25:45	3	44.12
file_server	10469	WHITC	1	2018-09-06 09:48:01	2018-10-04 09:48:01	2018-09-10 09:48:01	1	60.18
file_server	10470	BONAP	4	2018-09-08 20:55:26	2018-10-06 20:55:26	2018-09-11 20:55:26	2	64.56
file_server	10471	BSBEV	2	2018-09-08 20:55:26	2018-10-06 20:55:26	2018-09-15 20:55:26	3	45.59
file_server	10472	SEVES	8	2018-09-11 08:02:52	2018-10-09 08:02:52	2018-09-18 08:02:52	1	4.2
file_server	10473	ISLAT	1	2018-09-13 19:10:17	2018-09-27 19:10:17	2018-09-21 19:10:17	3	16.37
file_server	10474	PERIC	5	2018-09-13 19:10:17	2018-10-11 19:10:17	2018-09-21 19:10:17	2	83.49
file_server	10475	SUPRD	9	2018-09-16 06:17:42	2018-10-14 06:17:42	2018-10-07 06:17:42	1	68.52
file_server	10476	HILAA	8	2018-09-23 15:39:58	2018-10-21 15:39:58	2018-09-30 15:39:58	3	4.41
file_server	10477	PRINI	5	2018-09-23 15:39:58	2018-10-21 15:39:58	2018-10-01 15:39:58	2	13.02
file_server	10478	VICTE	2	2018-09-26 02:47:24	2018-10-10 02:47:24	2018-10-04 02:47:24	3	4.81
file_server	10479	RATTC	3	2018-09-28 13:54:49	2018-10-26 13:54:49	2018-09-30 13:54:49	3	708.95
file_server	10480	FOLIG	6	2018-10-01 01:02:14	2018-10-29 01:02:14	2018-10-05 01:02:14	2	1.35
file_server	10481	RICAR	8	2018-10-01 01:02:14	2018-10-29 01:02:14	2018-10-06 01:02:14	2	64.33
file_server	10482	LAZYK	1	2018-10-03 12:09:39	2018-10-31 12:09:39	2018-10-23 12:09:39	3	7.48
file_server	10483	WHITC	7	2018-10-10 21:31:55	2018-11-07 21:31:55	2018-11-11 21:31:55	2	15.28
file_server	10484	BSBEV	3	2018-10-10 21:31:55	2018-11-07 21:31:55	2018-10-18 21:31:55	3	6.88
file_server	10485	LINOD	4	2018-10-13 08:39:21	2018-10-27 08:39:21	2018-10-19 08:39:21	2	64.45
file_server	10486	HILAA	1	2018-10-15 19:46:46	2018-11-12 19:46:46	2018-10-22 19:46:46	2	30.53
file_server	10487	QUEEN	2	2018-10-15 19:46:46	2018-11-12 19:46:46	2018-10-17 19:46:46	2	71.07
file_server	10488	FRANK	8	2018-10-18 06:54:11	2018-11-15 06:54:11	2018-10-24 06:54:11	2	4.93
file_server	10489	PICCO	6	2018-10-20 18:01:37	2018-11-17 18:01:37	2018-11-01 18:01:37	2	5.29
file_server	10490	HILAA	7	2018-10-28 03:23:52	2018-11-25 03:23:52	2018-10-31 03:23:52	2	210.19
file_server	10491	FURIB	8	2018-10-28 03:23:52	2018-11-25 03:23:52	2018-11-05 03:23:52	3	16.96
file_server	10492	BOTTM	3	2018-10-30 14:31:18	2018-11-27 14:31:18	2018-11-09 14:31:18	1	62.89
file_server	10493	LAMAI	4	2018-11-02 01:38:43	2018-11-30 01:38:43	2018-11-10 01:38:43	3	10.64
file_server	10494	COMMI	4	2018-11-02 01:38:43	2018-11-30 01:38:43	2018-11-09 01:38:43	2	65.99
file_server	10495	LAUGB	3	2018-11-04 12:46:08	2018-12-02 12:46:08	2018-11-12 12:46:08	3	4.65
file_server	10496	TRADH	7	2018-11-06 23:53:34	2018-12-04 23:53:34	2018-11-09 23:53:34	2	46.77
file_server	10497	LEHMS	7	2018-11-06 23:53:34	2018-12-04 23:53:34	2018-11-09 23:53:34	1	36.21
file_server	10498	HILAA	8	2018-11-14 09:15:50	2018-12-12 09:15:50	2018-11-18 09:15:50	2	29.75
file_server	10499	LILAS	4	2018-11-16 20:23:15	2018-12-14 20:23:15	2018-11-24 20:23:15	2	102.02
file_server	10500	LAMAI	6	2018-11-19 07:30:40	2018-12-17 07:30:40	2018-11-27 07:30:40	1	42.68
file_server	10501	BLAUS	9	2018-11-19 07:30:40	2018-12-17 07:30:40	2018-11-26 07:30:40	3	8.85
file_server	10502	PERIC	2	2018-11-21 18:38:06	2018-12-19 18:38:06	2018-12-10 18:38:06	1	69.32
file_server	10503	HUNGO	6	2018-11-24 05:45:31	2018-12-22 05:45:31	2018-11-29 05:45:31	2	16.74
file_server	10504	WHITC	4	2018-11-24 05:45:31	2018-12-22 05:45:31	2018-12-01 05:45:31	3	59.13
file_server	10505	MEREP	3	2018-12-01 15:07:47	2018-12-29 15:07:47	2018-12-08 15:07:47	3	7.13
file_server	10506	KOENE	9	2018-12-04 02:15:12	2019-01-01 02:15:12	2018-12-21 02:15:12	2	21.19
file_server	10507	ANTON	7	2018-12-04 02:15:12	2019-01-01 02:15:12	2018-12-11 02:15:12	1	47.45
file_server	10508	OTTIK	1	2018-12-06 13:22:37	2019-01-03 13:22:37	2019-01-02 13:22:37	2	4.99
file_server	10509	BLAUS	4	2018-12-09 00:30:03	2019-01-06 00:30:03	2018-12-21 00:30:03	1	0.15
file_server	10510	SAVEA	6	2018-12-11 11:37:28	2019-01-08 11:37:28	2018-12-21 11:37:28	3	367.63
file_server	10511	BONAP	4	2018-12-11 11:37:28	2019-01-08 11:37:28	2018-12-14 11:37:28	3	350.64
file_server	10512	FAMIA	7	2018-12-18 20:59:44	2019-01-15 20:59:44	2018-12-21 20:59:44	2	3.53
file_server	10513	WANDK	7	2018-12-21 08:07:09	2019-02-01 08:07:09	2018-12-27 08:07:09	1	105.65
file_server	10514	ERNSH	3	2018-12-21 08:07:09	2019-01-18 08:07:09	2019-01-14 08:07:09	2	789.95
file_server	10515	QUICK	2	2018-12-23 19:14:35	2019-01-06 19:14:35	2019-01-22 19:14:35	1	204.47
file_server	10516	HUNGO	2	2018-12-26 06:22:00	2019-01-23 06:22:00	2019-01-02 06:22:00	3	62.78
file_server	10517	NORTS	3	2018-12-26 06:22:00	2019-01-23 06:22:00	2018-12-31 06:22:00	3	32.07
file_server	10518	TORTU	4	2018-12-28 17:29:25	2019-01-11 17:29:25	2019-01-07 17:29:25	2	218.15
\.


--
-- Data for Name: structured_file_server_orders_2019; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_orders_2019 (permission_scope_key, orderid, customerid, employeeid, orderdate, requireddate, shippeddate, shipperid, freight) FROM stdin;
file_server	10519	CHOPS	6	2019-01-05 02:51:41	2019-02-02 02:51:41	2019-01-08 02:51:41	3	91.76
file_server	10520	SANTG	7	2019-01-07 13:59:06	2019-02-04 13:59:06	2019-01-09 13:59:06	1	13.37
file_server	10521	CACTU	8	2019-01-07 13:59:06	2019-02-04 13:59:06	2019-01-10 13:59:06	2	17.22
file_server	10522	LEHMS	4	2019-01-10 01:06:32	2019-02-07 01:06:32	2019-01-16 01:06:32	1	45.33
file_server	10523	SEVES	7	2019-01-12 12:13:57	2019-02-09 12:13:57	2019-02-10 12:13:57	2	77.63
file_server	10524	BERGS	1	2019-01-12 12:13:57	2019-02-09 12:13:57	2019-01-18 12:13:57	2	244.79
file_server	10525	BONAP	1	2019-01-14 23:21:22	2019-02-11 23:21:22	2019-02-04 23:21:22	2	11.06
file_server	10526	WARTH	4	2019-01-22 08:43:38	2019-02-19 08:43:38	2019-02-01 08:43:38	2	58.59
file_server	10527	QUICK	7	2019-01-22 08:43:38	2019-02-19 08:43:38	2019-01-24 08:43:38	1	41.9
file_server	10528	GREAL	6	2019-01-24 19:51:03	2019-02-07 19:51:03	2019-01-27 19:51:03	2	3.35
file_server	10529	MAISD	5	2019-01-27 06:58:29	2019-02-24 06:58:29	2019-01-29 06:58:29	2	66.69
file_server	10530	PICCO	3	2019-01-29 18:05:54	2019-02-26 18:05:54	2019-02-02 18:05:54	2	339.22
file_server	10531	OCEAN	7	2019-01-29 18:05:54	2019-02-26 18:05:54	2019-02-09 18:05:54	1	8.12
file_server	10532	EASTC	7	2019-02-01 05:13:19	2019-03-01 05:13:19	2019-02-04 05:13:19	3	74.46
file_server	10533	FOLKO	8	2019-02-08 14:35:35	2019-03-08 14:35:35	2019-02-18 14:35:35	1	188.04
file_server	10534	LEHMS	8	2019-02-08 14:35:35	2019-03-08 14:35:35	2019-02-10 14:35:35	2	27.94
file_server	10535	ANTON	4	2019-02-11 01:43:01	2019-03-11 01:43:01	2019-02-19 01:43:01	1	15.64
file_server	10536	LEHMS	3	2019-02-13 12:50:26	2019-03-13 12:50:26	2019-03-08 12:50:26	2	58.88
file_server	10537	RICSU	1	2019-02-13 12:50:26	2019-02-27 12:50:26	2019-02-18 12:50:26	1	78.85
file_server	10538	BSBEV	9	2019-02-15 23:57:51	2019-03-15 23:57:51	2019-02-16 23:57:51	3	4.87
file_server	10539	BSBEV	6	2019-02-18 11:05:17	2019-03-18 11:05:17	2019-02-25 11:05:17	3	12.36
file_server	10540	QUICK	3	2019-02-25 20:27:32	2019-03-25 20:27:32	2019-03-22 20:27:32	3	1007.64
file_server	10541	HANAR	2	2019-02-25 20:27:32	2019-03-25 20:27:32	2019-03-07 20:27:32	1	68.65
file_server	10542	KOENE	1	2019-02-28 07:34:58	2019-03-28 07:34:58	2019-03-06 07:34:58	3	10.95
file_server	10543	LILAS	8	2019-03-02 18:42:23	2019-03-30 18:42:23	2019-03-04 18:42:23	2	48.17
file_server	10544	LONEP	4	2019-03-02 18:42:23	2019-03-30 18:42:23	2019-03-11 18:42:23	1	24.91
file_server	10545	LAZYK	8	2019-03-05 05:49:48	2019-04-02 05:49:48	2019-04-09 05:49:48	2	11.92
file_server	10546	VICTE	1	2019-03-07 16:57:14	2019-04-04 16:57:14	2019-03-11 16:57:14	3	194.72
file_server	10547	SEVES	3	2019-03-07 16:57:14	2019-04-04 16:57:14	2019-03-17 16:57:14	2	178.43
file_server	10548	TOMSP	3	2019-03-15 02:19:30	2019-04-12 02:19:30	2019-03-22 02:19:30	2	1.43
file_server	10549	QUICK	5	2019-03-17 13:26:55	2019-03-31 13:26:55	2019-03-20 13:26:55	1	171.24
file_server	10550	GODOS	7	2019-03-20 00:34:20	2019-04-17 00:34:20	2019-03-29 00:34:20	3	4.32
file_server	10551	FURIB	4	2019-03-20 00:34:20	2019-05-01 00:34:20	2019-03-29 00:34:20	3	72.95
file_server	10552	HILAA	2	2019-03-22 11:41:46	2019-04-19 11:41:46	2019-03-29 11:41:46	1	83.22
file_server	10553	WARTH	2	2019-03-24 22:49:11	2019-04-21 22:49:11	2019-03-28 22:49:11	2	149.49
file_server	10554	OTTIK	4	2019-03-24 22:49:11	2019-04-21 22:49:11	2019-03-30 22:49:11	3	120.97
file_server	10555	SAVEA	6	2019-04-01 08:11:27	2019-04-29 08:11:27	2019-04-03 08:11:27	3	252.49
file_server	10556	SIMOB	2	2019-04-03 19:18:52	2019-05-15 19:18:52	2019-04-13 19:18:52	1	9.8
file_server	10557	LEHMS	9	2019-04-03 19:18:52	2019-04-17 19:18:52	2019-04-06 19:18:52	2	96.72
file_server	10558	AROUT	1	2019-04-06 06:26:17	2019-05-04 06:26:17	2019-04-12 06:26:17	2	72.97
file_server	10559	BLONP	6	2019-04-08 17:33:43	2019-05-06 17:33:43	2019-04-16 17:33:43	1	8.05
file_server	10560	FRANK	8	2019-04-11 04:41:08	2019-05-09 04:41:08	2019-04-14 04:41:08	1	36.65
file_server	10561	FOLKO	2	2019-04-11 04:41:08	2019-05-09 04:41:08	2019-04-14 04:41:08	2	242.21
file_server	10562	REGGC	1	2019-04-18 14:03:24	2019-05-16 14:03:24	2019-04-21 14:03:24	1	22.95
file_server	10563	RICAR	2	2019-04-21 01:10:49	2019-06-02 01:10:49	2019-05-05 01:10:49	2	60.43
file_server	10564	RATTC	4	2019-04-21 01:10:49	2019-05-19 01:10:49	2019-04-27 01:10:49	3	13.75
file_server	10565	MEREP	8	2019-04-23 12:18:14	2019-05-21 12:18:14	2019-04-30 12:18:14	2	7.15
file_server	10566	BLONP	9	2019-04-25 23:25:40	2019-05-23 23:25:40	2019-05-01 23:25:40	1	88.4
file_server	10567	HUNGO	1	2019-04-25 23:25:40	2019-05-23 23:25:40	2019-04-30 23:25:40	1	33.97
file_server	10568	GALED	3	2019-04-28 10:33:05	2019-05-26 10:33:05	2019-05-24 10:33:05	3	6.54
file_server	10569	RATTC	5	2019-05-05 19:55:21	2019-06-02 19:55:21	2019-05-30 19:55:21	1	58.98
file_server	10570	MEREP	3	2019-05-08 07:02:46	2019-06-05 07:02:46	2019-05-10 07:02:46	3	188.99
file_server	10571	ERNSH	8	2019-05-08 07:02:46	2019-06-19 07:02:46	2019-05-25 07:02:46	3	26.06
file_server	10572	BERGS	3	2019-05-10 18:10:12	2019-06-07 18:10:12	2019-05-17 18:10:12	2	116.43
file_server	10573	ANTON	7	2019-05-13 05:17:37	2019-06-10 05:17:37	2019-05-14 05:17:37	3	84.84
file_server	10574	TRAIH	4	2019-05-13 05:17:37	2019-06-10 05:17:37	2019-05-24 05:17:37	2	37.6
file_server	10575	MORGK	5	2019-05-15 16:25:02	2019-05-29 16:25:02	2019-05-25 16:25:02	1	127.34
file_server	10576	TORTU	3	2019-05-23 01:47:18	2019-06-06 01:47:18	2019-05-30 01:47:18	3	18.56
file_server	10577	TRAIH	9	2019-05-23 01:47:18	2019-07-04 01:47:18	2019-05-30 01:47:18	2	25.41
file_server	10578	BSBEV	4	2019-05-25 12:54:43	2019-06-22 12:54:43	2019-06-25 12:54:43	3	29.6
file_server	10579	LETSS	1	2019-05-28 00:02:09	2019-06-25 00:02:09	2019-06-06 00:02:09	2	13.73
file_server	10580	OTTIK	4	2019-05-30 11:09:34	2019-06-27 11:09:34	2019-06-04 11:09:34	3	75.89
file_server	10581	FAMIA	3	2019-05-30 11:09:34	2019-06-27 11:09:34	2019-06-05 11:09:34	1	3.01
file_server	10582	BLAUS	3	2019-06-01 22:16:59	2019-06-29 22:16:59	2019-06-18 22:16:59	2	27.71
file_server	10583	WARTH	2	2019-06-09 07:39:15	2019-07-07 07:39:15	2019-06-13 07:39:15	2	7.28
file_server	10584	BLONP	4	2019-06-09 07:39:15	2019-07-07 07:39:15	2019-06-13 07:39:15	1	59.14
file_server	10585	WELLI	7	2019-06-11 18:46:41	2019-07-09 18:46:41	2019-06-20 18:46:41	1	13.41
file_server	10586	REGGC	9	2019-06-14 05:54:06	2019-07-12 05:54:06	2019-06-21 05:54:06	1	0.48
file_server	10587	QUEDE	1	2019-06-14 05:54:06	2019-07-12 05:54:06	2019-06-21 05:54:06	1	62.52
file_server	10588	QUICK	2	2019-06-16 17:01:31	2019-07-14 17:01:31	2019-06-23 17:01:31	3	194.67
file_server	10589	GREAL	8	2019-06-19 04:08:57	2019-07-17 04:08:57	2019-06-29 04:08:57	2	4.42
file_server	10590	MEREP	4	2019-06-26 13:31:12	2019-07-24 13:31:12	2019-07-03 13:31:12	3	44.77
file_server	10591	VAFFE	1	2019-06-26 13:31:12	2019-07-10 13:31:12	2019-07-05 13:31:12	1	55.92
file_server	10592	LEHMS	3	2019-06-29 00:38:38	2019-07-27 00:38:38	2019-07-07 00:38:38	1	32.1
file_server	10593	LEHMS	7	2019-07-01 11:46:03	2019-07-29 11:46:03	2019-08-05 11:46:03	2	174.2
file_server	10594	OLDWO	3	2019-07-01 11:46:03	2019-07-29 11:46:03	2019-07-08 11:46:03	2	5.24
file_server	10595	ERNSH	2	2019-07-03 22:53:28	2019-07-31 22:53:28	2019-07-07 22:53:28	1	96.78
file_server	10596	WHITC	8	2019-07-06 10:00:54	2019-08-03 10:00:54	2019-08-07 10:00:54	1	16.34
file_server	10597	PICCO	7	2019-07-06 10:00:54	2019-08-03 10:00:54	2019-07-13 10:00:54	3	35.12
file_server	10598	RATTC	1	2019-07-13 19:23:10	2019-08-10 19:23:10	2019-07-17 19:23:10	3	44.42
file_server	10599	BSBEV	6	2019-07-16 06:30:35	2019-08-27 06:30:35	2019-07-22 06:30:35	3	29.98
file_server	10600	HUNGC	4	2019-07-18 17:38:00	2019-08-15 17:38:00	2019-07-23 17:38:00	1	45.13
file_server	10601	HILAA	7	2019-07-18 17:38:00	2019-08-29 17:38:00	2019-07-24 17:38:00	1	58.3
file_server	10602	VAFFE	8	2019-07-21 04:45:25	2019-08-18 04:45:25	2019-07-26 04:45:25	2	2.92
file_server	10603	SAVEA	8	2019-07-23 15:52:51	2019-08-20 15:52:51	2019-08-13 15:52:51	2	48.77
file_server	10604	FURIB	1	2019-07-23 15:52:51	2019-08-20 15:52:51	2019-08-03 15:52:51	1	7.46
file_server	10605	MEREP	1	2019-07-31 01:15:07	2019-08-28 01:15:07	2019-08-08 01:15:07	2	379.13
file_server	10606	TRADH	4	2019-08-02 12:22:32	2019-08-30 12:22:32	2019-08-11 12:22:32	3	79.4
file_server	10607	SAVEA	5	2019-08-02 12:22:32	2019-08-30 12:22:32	2019-08-05 12:22:32	1	200.24
file_server	10608	TOMSP	4	2019-08-04 23:29:57	2019-09-01 23:29:57	2019-08-13 23:29:57	2	27.79
file_server	10609	DUMON	7	2019-08-07 10:37:23	2019-09-04 10:37:23	2019-08-13 10:37:23	2	1.85
file_server	10610	LAMAI	8	2019-08-09 21:44:48	2019-09-06 21:44:48	2019-08-21 21:44:48	1	26.78
file_server	10611	WOLZA	6	2019-08-09 21:44:48	2019-09-06 21:44:48	2019-08-16 21:44:48	2	80.65
file_server	10612	SAVEA	1	2019-08-17 07:07:04	2019-09-14 07:07:04	2019-08-21 07:07:04	2	544.08
file_server	10613	HILAA	4	2019-08-19 18:14:29	2019-09-16 18:14:29	2019-08-22 18:14:29	2	8.11
file_server	10614	BLAUS	8	2019-08-19 18:14:29	2019-09-16 18:14:29	2019-08-22 18:14:29	3	1.93
file_server	10615	WILMK	2	2019-08-22 05:21:54	2019-09-19 05:21:54	2019-08-29 05:21:54	3	0.75
file_server	10616	GREAL	1	2019-08-24 16:29:20	2019-09-21 16:29:20	2019-08-29 16:29:20	2	116.53
file_server	10617	GREAL	4	2019-08-24 16:29:20	2019-09-21 16:29:20	2019-08-28 16:29:20	2	18.53
file_server	10618	MEREP	1	2019-08-27 03:36:45	2019-10-08 03:36:45	2019-09-03 03:36:45	1	154.68
file_server	10619	MEREP	3	2019-09-03 12:59:01	2019-10-01 12:59:01	2019-09-06 12:59:01	3	91.05
file_server	10620	LAUGB	2	2019-09-06 00:06:26	2019-10-04 00:06:26	2019-09-15 00:06:26	3	0.94
file_server	10621	ISLAT	4	2019-09-06 00:06:26	2019-10-04 00:06:26	2019-09-12 00:06:26	2	23.73
file_server	10622	RICAR	4	2019-09-08 11:13:52	2019-10-06 11:13:52	2019-09-13 11:13:52	3	50.97
file_server	10623	FRANK	8	2019-09-10 22:21:17	2019-10-08 22:21:17	2019-09-15 22:21:17	2	97.18
file_server	10624	THECR	4	2019-09-10 22:21:17	2019-10-08 22:21:17	2019-09-22 22:21:17	2	94.8
file_server	10625	ANATR	3	2019-09-13 09:28:42	2019-10-11 09:28:42	2019-09-19 09:28:42	1	43.9
file_server	10626	BERGS	1	2019-09-20 18:50:58	2019-10-18 18:50:58	2019-09-29 18:50:58	2	138.69
file_server	10627	SAVEA	8	2019-09-20 18:50:58	2019-11-01 18:50:58	2019-09-30 18:50:58	3	107.46
file_server	10628	BLONP	4	2019-09-23 05:58:23	2019-10-21 05:58:23	2019-10-01 05:58:23	3	30.36
file_server	10629	GODOS	4	2019-09-23 05:58:23	2019-10-21 05:58:23	2019-10-01 05:58:23	3	85.46
file_server	10630	KOENE	1	2019-09-25 17:05:49	2019-10-23 17:05:49	2019-10-01 17:05:49	2	32.35
file_server	10631	LAMAI	8	2019-09-28 04:13:14	2019-10-26 04:13:14	2019-09-29 04:13:14	1	0.87
file_server	10632	WANDK	8	2019-09-28 04:13:14	2019-10-26 04:13:14	2019-10-03 04:13:14	1	41.38
file_server	10633	ERNSH	7	2019-09-30 15:20:39	2019-10-28 15:20:39	2019-10-03 15:20:39	3	477.9
file_server	10634	FOLIG	4	2019-09-30 15:20:39	2019-10-28 15:20:39	2019-10-06 15:20:39	3	487.38
file_server	10635	MAGAA	8	2019-10-08 00:42:55	2019-11-05 00:42:55	2019-10-11 00:42:55	3	47.46
file_server	10636	WARTH	4	2019-10-10 11:50:21	2019-11-07 11:50:21	2019-10-17 11:50:21	1	1.15
file_server	10637	QUEEN	6	2019-10-10 11:50:21	2019-11-07 11:50:21	2019-10-17 11:50:21	1	201.29
file_server	10638	LINOD	3	2019-10-12 22:57:46	2019-11-09 22:57:46	2019-10-24 22:57:46	1	158.44
file_server	10639	SANTG	7	2019-10-12 22:57:46	2019-11-09 22:57:46	2019-10-19 22:57:46	3	38.64
file_server	10640	WANDK	4	2019-10-15 10:05:11	2019-11-12 10:05:11	2019-10-22 10:05:11	1	23.55
file_server	10641	HILAA	4	2019-10-17 21:12:36	2019-11-14 21:12:36	2019-10-21 21:12:36	2	179.61
file_server	10642	SIMOB	7	2019-10-17 21:12:36	2019-11-14 21:12:36	2019-10-31 21:12:36	3	41.89
file_server	10643	ALFKI	6	2019-10-25 06:34:52	2019-11-22 06:34:52	2019-11-02 06:34:52	1	29.46
file_server	10644	WELLI	3	2019-10-25 06:34:52	2019-11-22 06:34:52	2019-11-01 06:34:52	2	0.14
file_server	10645	HANAR	4	2019-10-27 17:42:18	2019-11-24 17:42:18	2019-11-03 17:42:18	1	12.41
file_server	10646	HUNGO	9	2019-10-30 04:49:43	2019-12-11 04:49:43	2019-11-06 04:49:43	3	142.33
file_server	10647	QUEDE	4	2019-10-30 04:49:43	2019-11-13 04:49:43	2019-11-06 04:49:43	2	45.54
file_server	10648	RICAR	5	2019-11-01 15:57:08	2019-12-13 15:57:08	2019-11-13 15:57:08	2	14.25
file_server	10649	MAISD	5	2019-11-01 15:57:08	2019-11-29 15:57:08	2019-11-02 15:57:08	3	6.2
file_server	10650	FAMIA	5	2019-11-04 03:04:34	2019-12-02 03:04:34	2019-11-09 03:04:34	3	176.81
file_server	10651	WANDK	8	2019-11-11 12:26:50	2019-12-09 12:26:50	2019-11-21 12:26:50	2	20.6
file_server	10652	GOURL	4	2019-11-11 12:26:50	2019-12-09 12:26:50	2019-11-18 12:26:50	2	7.14
file_server	10653	FRANK	1	2019-11-13 23:34:15	2019-12-11 23:34:15	2019-11-30 23:34:15	1	93.25
file_server	10654	BERGS	5	2019-11-13 23:34:15	2019-12-11 23:34:15	2019-11-22 23:34:15	1	55.26
file_server	10655	REGGC	1	2019-11-16 10:41:40	2019-12-14 10:41:40	2019-11-24 10:41:40	2	4.41
file_server	10656	GREAL	6	2019-11-18 21:49:05	2019-12-16 21:49:05	2019-11-24 21:49:05	1	57.15
file_server	10657	SAVEA	2	2019-11-18 21:49:05	2019-12-16 21:49:05	2019-11-29 21:49:05	2	352.69
file_server	10658	QUICK	4	2019-11-21 08:56:31	2019-12-19 08:56:31	2019-11-24 08:56:31	1	364.15
file_server	10659	QUEEN	7	2019-11-21 08:56:31	2019-12-19 08:56:31	2019-11-26 08:56:31	2	105.81
file_server	10660	HUNGC	8	2019-11-28 18:18:47	2019-12-26 18:18:47	2020-01-04 18:18:47	1	111.29
file_server	10661	HUNGO	7	2019-12-01 05:26:12	2019-12-29 05:26:12	2019-12-07 05:26:12	3	17.55
file_server	10662	LONEP	3	2019-12-01 05:26:12	2019-12-29 05:26:12	2019-12-10 05:26:12	2	1.28
file_server	10663	BONAP	2	2019-12-03 16:33:37	2019-12-17 16:33:37	2019-12-26 16:33:37	2	113.15
file_server	10664	FURIB	1	2019-12-03 16:33:37	2019-12-31 16:33:37	2019-12-12 16:33:37	3	1.27
file_server	10665	LONEP	1	2019-12-06 03:41:03	2020-01-03 03:41:03	2019-12-12 03:41:03	2	26.31
file_server	10666	RICSU	7	2019-12-08 14:48:28	2020-01-05 14:48:28	2019-12-18 14:48:28	2	232.42
file_server	10667	ERNSH	7	2019-12-08 14:48:28	2020-01-05 14:48:28	2019-12-15 14:48:28	1	78.09
file_server	10668	WANDK	1	2019-12-16 00:10:44	2020-01-13 00:10:44	2019-12-24 00:10:44	2	47.22
file_server	10669	SIMOB	2	2019-12-16 00:10:44	2020-01-13 00:10:44	2019-12-23 00:10:44	1	24.39
file_server	10670	FRANK	4	2019-12-18 11:18:09	2020-01-15 11:18:09	2019-12-20 11:18:09	1	203.48
file_server	10671	FRANR	1	2019-12-20 22:25:34	2020-01-17 22:25:34	2019-12-27 22:25:34	1	30.34
file_server	10672	BERGS	9	2019-12-20 22:25:34	2020-01-03 22:25:34	2019-12-29 22:25:34	2	95.75
file_server	10673	WILMK	2	2019-12-23 09:33:00	2020-01-20 09:33:00	2019-12-24 09:33:00	1	22.76
file_server	10674	ISLAT	4	2019-12-23 09:33:00	2020-01-20 09:33:00	2020-01-04 09:33:00	2	0.9
file_server	10675	FRANK	5	2019-12-25 20:40:25	2020-01-22 20:40:25	2019-12-29 20:40:25	2	31.85
\.


--
-- Data for Name: structured_file_server_orders_2020; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_orders_2020 (permission_scope_key, orderid, customerid, employeeid, orderdate, requireddate, shippeddate, shipperid, freight) FROM stdin;
file_server	10676	TORTU	2	2020-01-02 06:02:41	2020-01-30 06:02:41	2020-01-09 06:02:41	2	2.01
file_server	10677	ANTON	1	2020-01-02 06:02:41	2020-01-30 06:02:41	2020-01-06 06:02:41	3	4.03
file_server	10678	SAVEA	7	2020-01-04 17:10:06	2020-02-01 17:10:06	2020-01-27 17:10:06	3	388.98
file_server	10679	BLONP	8	2020-01-04 17:10:06	2020-02-01 17:10:06	2020-01-11 17:10:06	3	27.94
file_server	10680	OLDWO	1	2020-01-07 04:17:32	2020-02-04 04:17:32	2020-01-09 04:17:32	1	26.61
file_server	10681	GREAL	3	2020-01-09 15:24:57	2020-02-06 15:24:57	2020-01-14 15:24:57	3	76.13
file_server	10682	ANTON	3	2020-01-09 15:24:57	2020-02-06 15:24:57	2020-01-15 15:24:57	2	36.13
file_server	10683	DUMON	2	2020-01-12 02:32:22	2020-02-09 02:32:22	2020-01-17 02:32:22	1	4.4
file_server	10684	OTTIK	3	2020-01-12 02:32:22	2020-02-09 02:32:22	2020-01-16 02:32:22	1	145.63
file_server	10685	GOURL	4	2020-01-19 11:54:38	2020-02-02 11:54:38	2020-01-23 11:54:38	2	33.75
file_server	10686	PICCO	2	2020-01-21 23:02:03	2020-02-18 23:02:03	2020-01-29 23:02:03	1	96.5
file_server	10687	HUNGO	9	2020-01-21 23:02:03	2020-02-18 23:02:03	2020-02-20 23:02:03	2	296.43
file_server	10688	VAFFE	4	2020-01-24 10:09:29	2020-02-07 10:09:29	2020-01-30 10:09:29	2	299.09
file_server	10689	BERGS	1	2020-01-24 10:09:29	2020-02-21 10:09:29	2020-01-30 10:09:29	2	13.42
file_server	10690	HANAR	1	2020-01-26 21:16:54	2020-02-23 21:16:54	2020-01-27 21:16:54	1	15.8
file_server	10691	QUICK	2	2020-01-29 08:24:19	2020-03-11 08:24:19	2020-02-17 08:24:19	2	810.05
file_server	10692	ALFKI	4	2020-01-29 08:24:19	2020-02-26 08:24:19	2020-02-08 08:24:19	2	61.02
file_server	10693	WHITC	3	2020-02-05 17:46:35	2020-02-19 17:46:35	2020-02-09 17:46:35	3	139.34
file_server	10694	QUICK	8	2020-02-05 17:46:35	2020-03-04 17:46:35	2020-02-08 17:46:35	3	398.36
file_server	10695	WILMK	7	2020-02-08 04:54:01	2020-03-21 04:54:01	2020-02-15 04:54:01	1	16.72
file_server	10696	WHITC	8	2020-02-10 16:01:26	2020-03-23 16:01:26	2020-02-16 16:01:26	3	102.55
file_server	10697	LINOD	3	2020-02-10 16:01:26	2020-03-09 16:01:26	2020-02-16 16:01:26	1	45.52
file_server	10698	ERNSH	4	2020-02-13 03:08:51	2020-03-12 03:08:51	2020-02-21 03:08:51	1	272.47
file_server	10699	MORGK	3	2020-02-13 03:08:51	2020-03-12 03:08:51	2020-02-17 03:08:51	3	0.58
file_server	10700	SAVEA	3	2020-02-15 14:16:16	2020-03-14 14:16:16	2020-02-21 14:16:16	1	65.1
file_server	10701	HUNGO	6	2020-02-22 23:38:32	2020-03-07 23:38:32	2020-02-24 23:38:32	3	220.31
file_server	10702	ALFKI	4	2020-02-22 23:38:32	2020-04-04 23:38:32	2020-03-01 23:38:32	1	23.94
file_server	10703	FOLKO	6	2020-02-25 10:45:58	2020-03-24 10:45:58	2020-03-02 10:45:58	2	152.3
file_server	10704	QUEEN	6	2020-02-25 10:45:58	2020-03-24 10:45:58	2020-03-20 10:45:58	1	4.78
file_server	10705	HILAA	9	2020-02-27 21:53:23	2020-03-26 21:53:23	2020-04-01 21:53:23	2	3.52
file_server	10706	OLDWO	8	2020-03-01 09:00:48	2020-03-29 09:00:48	2020-03-06 09:00:48	3	135.63
file_server	10707	AROUT	4	2020-03-01 09:00:48	2020-03-15 09:00:48	2020-03-08 09:00:48	3	21.74
file_server	10708	THEBI	6	2020-03-03 20:08:14	2020-04-14 20:08:14	2020-03-22 20:08:14	2	2.96
file_server	10709	GOURL	1	2020-03-03 20:08:14	2020-03-31 20:08:14	2020-04-06 20:08:14	3	210.8
file_server	10710	FRANS	1	2020-03-11 05:30:30	2020-04-08 05:30:30	2020-03-14 05:30:30	1	4.98
file_server	10711	SAVEA	5	2020-03-13 16:37:55	2020-04-24 16:37:55	2020-03-21 16:37:55	2	52.41
file_server	10712	HUNGO	3	2020-03-13 16:37:55	2020-04-10 16:37:55	2020-03-23 16:37:55	1	89.93
file_server	10713	SAVEA	1	2020-03-16 03:45:20	2020-04-13 03:45:20	2020-03-18 03:45:20	1	167.05
file_server	10714	SAVEA	5	2020-03-16 03:45:20	2020-04-13 03:45:20	2020-03-21 03:45:20	3	24.49
file_server	10715	BONAP	3	2020-03-18 14:52:45	2020-04-01 14:52:45	2020-03-24 14:52:45	1	63.2
file_server	10716	RANCH	4	2020-03-21 02:00:11	2020-04-18 02:00:11	2020-03-24 02:00:11	2	22.57
file_server	10717	FRANK	1	2020-03-21 02:00:11	2020-04-18 02:00:11	2020-03-26 02:00:11	2	59.25
file_server	10718	KOENE	1	2020-03-28 11:22:27	2020-04-25 11:22:27	2020-03-30 11:22:27	3	170.88
file_server	10719	LETSS	8	2020-03-28 11:22:27	2020-04-25 11:22:27	2020-04-06 11:22:27	2	51.44
file_server	10720	QUEDE	8	2020-03-30 22:29:52	2020-04-13 22:29:52	2020-04-07 22:29:52	2	9.53
file_server	10721	QUICK	5	2020-04-02 09:37:17	2020-04-30 09:37:17	2020-04-04 09:37:17	3	48.92
file_server	10722	SAVEA	8	2020-04-02 09:37:17	2020-05-14 09:37:17	2020-04-08 09:37:17	1	74.58
file_server	10723	WHITC	3	2020-04-04 20:44:43	2020-05-02 20:44:43	2020-04-30 20:44:43	1	21.72
file_server	10724	MEREP	8	2020-04-04 20:44:43	2020-05-16 20:44:43	2020-04-10 20:44:43	2	57.75
file_server	10725	FAMIA	4	2020-04-07 07:52:08	2020-05-05 07:52:08	2020-04-12 07:52:08	3	10.83
file_server	10726	EASTC	4	2020-04-14 17:14:24	2020-04-28 17:14:24	2020-05-16 17:14:24	1	16.56
file_server	10727	REGGC	2	2020-04-14 17:14:24	2020-05-12 17:14:24	2020-05-16 17:14:24	1	89.9
file_server	10728	QUEEN	4	2020-04-17 04:21:49	2020-05-15 04:21:49	2020-04-24 04:21:49	2	58.33
file_server	10729	LINOD	8	2020-04-17 04:21:49	2020-05-29 04:21:49	2020-04-27 04:21:49	3	141.06
file_server	10730	BONAP	5	2020-04-19 15:29:14	2020-05-17 15:29:14	2020-04-28 15:29:14	1	20.12
file_server	10731	CHOPS	7	2020-04-22 02:36:40	2020-05-20 02:36:40	2020-04-30 02:36:40	1	96.65
file_server	10732	BONAP	3	2020-04-22 02:36:40	2020-05-20 02:36:40	2020-04-23 02:36:40	1	16.97
file_server	10733	BERGS	1	2020-04-24 13:44:05	2020-05-22 13:44:05	2020-04-27 13:44:05	3	110.11
file_server	10734	GOURL	2	2020-04-24 13:44:05	2020-05-22 13:44:05	2020-04-29 13:44:05	3	1.63
file_server	10735	LETSS	6	2020-05-01 23:06:21	2020-05-29 23:06:21	2020-05-12 23:06:21	2	45.97
file_server	10736	HUNGO	9	2020-05-04 10:13:46	2020-06-01 10:13:46	2020-05-14 10:13:46	2	44.1
file_server	10737	VINET	2	2020-05-04 10:13:46	2020-06-01 10:13:46	2020-05-11 10:13:46	2	7.79
file_server	10738	SPECD	2	2020-05-06 21:21:12	2020-06-03 21:21:12	2020-05-12 21:21:12	1	2.91
file_server	10739	VINET	3	2020-05-06 21:21:12	2020-06-03 21:21:12	2020-05-11 21:21:12	3	11.08
file_server	10740	WHITC	4	2020-05-09 08:28:37	2020-06-06 08:28:37	2020-05-21 08:28:37	2	81.88
file_server	10741	AROUT	4	2020-05-11 19:36:02	2020-05-25 19:36:02	2020-05-15 19:36:02	3	10.96
file_server	10742	BOTTM	3	2020-05-11 19:36:02	2020-06-08 19:36:02	2020-05-15 19:36:02	3	243.73
file_server	10743	AROUT	1	2020-05-19 04:58:18	2020-06-16 04:58:18	2020-05-23 04:58:18	2	23.72
file_server	10744	VAFFE	6	2020-05-19 04:58:18	2020-06-16 04:58:18	2020-05-26 04:58:18	1	69.19
file_server	10745	QUICK	9	2020-05-21 16:05:43	2020-06-18 16:05:43	2020-05-30 16:05:43	1	3.52
file_server	10746	CHOPS	1	2020-05-24 03:13:09	2020-06-21 03:13:09	2020-05-26 03:13:09	3	31.43
file_server	10747	PICCO	6	2020-05-24 03:13:09	2020-06-21 03:13:09	2020-05-31 03:13:09	1	117.33
file_server	10748	SAVEA	3	2020-05-26 14:20:34	2020-06-23 14:20:34	2020-06-03 14:20:34	1	232.55
file_server	10749	ISLAT	4	2020-05-26 14:20:34	2020-06-23 14:20:34	2020-06-24 14:20:34	2	61.53
file_server	10750	WARTH	9	2020-05-29 01:27:59	2020-06-26 01:27:59	2020-06-01 01:27:59	1	79.3
file_server	10751	RICSU	3	2020-06-05 10:50:15	2020-07-03 10:50:15	2020-06-14 10:50:15	3	130.79
file_server	10752	NORTS	2	2020-06-05 10:50:15	2020-07-03 10:50:15	2020-06-09 10:50:15	3	1.39
file_server	10753	FRANS	3	2020-06-07 21:57:41	2020-07-05 21:57:41	2020-06-09 21:57:41	1	7.7
file_server	10754	MAGAA	6	2020-06-07 21:57:41	2020-07-05 21:57:41	2020-06-09 21:57:41	3	2.38
file_server	10755	BONAP	4	2020-06-10 09:05:06	2020-07-08 09:05:06	2020-06-12 09:05:06	2	16.71
file_server	10756	SPLIR	8	2020-06-12 20:12:31	2020-07-10 20:12:31	2020-06-17 20:12:31	2	73.21
file_server	10757	SAVEA	6	2020-06-12 20:12:31	2020-07-10 20:12:31	2020-06-30 20:12:31	1	8.19
file_server	10758	RICSU	3	2020-06-15 07:19:56	2020-07-13 07:19:56	2020-06-21 07:19:56	3	138.17
file_server	10759	ANATR	3	2020-06-15 07:19:56	2020-07-13 07:19:56	2020-06-29 07:19:56	3	11.99
file_server	10760	MAISD	4	2020-06-22 16:42:12	2020-07-20 16:42:12	2020-07-01 16:42:12	1	155.64
file_server	10761	RATTC	5	2020-06-25 03:49:38	2020-07-23 03:49:38	2020-07-01 03:49:38	2	18.66
file_server	10762	FOLKO	3	2020-06-25 03:49:38	2020-07-23 03:49:38	2020-07-02 03:49:38	1	328.74
file_server	10763	FOLIG	3	2020-06-27 14:57:03	2020-07-25 14:57:03	2020-07-02 14:57:03	3	37.35
file_server	10764	ERNSH	6	2020-06-27 14:57:03	2020-07-25 14:57:03	2020-07-02 14:57:03	3	145.45
file_server	10765	QUICK	3	2020-06-30 02:04:28	2020-07-28 02:04:28	2020-07-05 02:04:28	3	42.74
file_server	10766	OTTIK	4	2020-07-02 13:11:54	2020-07-30 13:11:54	2020-07-06 13:11:54	1	157.55
file_server	10767	SUPRD	4	2020-07-02 13:11:54	2020-07-30 13:11:54	2020-07-12 13:11:54	3	1.59
file_server	10768	AROUT	3	2020-07-09 22:34:09	2020-08-06 22:34:09	2020-07-16 22:34:09	2	146.32
file_server	10769	VAFFE	3	2020-07-09 22:34:09	2020-08-06 22:34:09	2020-07-13 22:34:09	1	65.06
file_server	10770	HANAR	8	2020-07-12 09:41:35	2020-08-09 09:41:35	2020-07-20 09:41:35	3	5.32
file_server	10771	ERNSH	9	2020-07-14 20:49:00	2020-08-11 20:49:00	2020-08-06 20:49:00	2	11.19
file_server	10772	LEHMS	3	2020-07-14 20:49:00	2020-08-11 20:49:00	2020-07-23 20:49:00	2	91.28
file_server	10773	ERNSH	1	2020-07-17 07:56:25	2020-08-14 07:56:25	2020-07-22 07:56:25	3	96.43
file_server	10774	FOLKO	4	2020-07-17 07:56:25	2020-07-31 07:56:25	2020-07-18 07:56:25	1	48.2
file_server	10775	THECR	7	2020-07-19 19:03:51	2020-08-16 19:03:51	2020-08-02 19:03:51	1	20.25
file_server	10776	ERNSH	1	2020-07-27 04:26:07	2020-08-24 04:26:07	2020-07-30 04:26:07	3	351.53
file_server	10777	GOURL	7	2020-07-27 04:26:07	2020-08-10 04:26:07	2020-09-02 04:26:07	2	3.01
file_server	10778	BERGS	3	2020-07-29 15:33:32	2020-08-26 15:33:32	2020-08-06 15:33:32	1	6.79
file_server	10779	MORGK	3	2020-07-29 15:33:32	2020-08-26 15:33:32	2020-08-27 15:33:32	2	58.13
file_server	10780	LILAS	2	2020-07-29 15:33:32	2020-08-12 15:33:32	2020-08-07 15:33:32	1	42.13
file_server	10781	WARTH	2	2020-08-01 02:40:57	2020-08-29 02:40:57	2020-08-03 02:40:57	3	73.16
file_server	10782	CACTU	9	2020-08-01 02:40:57	2020-08-29 02:40:57	2020-08-06 02:40:57	3	1.1
file_server	10783	HANAR	4	2020-08-03 13:48:23	2020-08-31 13:48:23	2020-08-04 13:48:23	2	124.98
file_server	10784	MAGAA	4	2020-08-03 13:48:23	2020-08-31 13:48:23	2020-08-07 13:48:23	3	70.09
file_server	10785	GROSR	1	2020-08-03 13:48:23	2020-08-31 13:48:23	2020-08-09 13:48:23	3	1.51
file_server	10786	QUEEN	8	2020-08-06 00:55:48	2020-09-03 00:55:48	2020-08-10 00:55:48	1	110.87
file_server	10787	LAMAI	2	2020-08-06 00:55:48	2020-08-20 00:55:48	2020-08-13 00:55:48	1	249.93
file_server	10788	QUICK	1	2020-08-13 10:18:04	2020-09-10 10:18:04	2020-09-10 10:18:04	2	42.7
file_server	10789	FOLIG	1	2020-08-13 10:18:04	2020-09-10 10:18:04	2020-08-22 10:18:04	2	100.6
file_server	10790	GOURL	6	2020-08-13 10:18:04	2020-09-10 10:18:04	2020-08-17 10:18:04	1	28.23
file_server	10791	FRANK	6	2020-08-15 21:25:29	2020-09-12 21:25:29	2020-08-24 21:25:29	2	16.85
file_server	10792	WOLZA	1	2020-08-15 21:25:29	2020-09-12 21:25:29	2020-08-23 21:25:29	3	23.79
file_server	10793	AROUT	3	2020-08-18 08:32:54	2020-09-15 08:32:54	2020-09-02 08:32:54	3	4.52
file_server	10794	QUEDE	6	2020-08-18 08:32:54	2020-09-15 08:32:54	2020-08-27 08:32:54	1	21.49
file_server	10795	ERNSH	8	2020-08-18 08:32:54	2020-09-15 08:32:54	2020-09-14 08:32:54	2	126.66
file_server	10796	HILAA	3	2020-08-20 19:40:20	2020-09-17 19:40:20	2020-09-09 19:40:20	1	26.52
file_server	10797	DRACD	7	2020-08-20 19:40:20	2020-09-17 19:40:20	2020-08-31 19:40:20	2	33.35
file_server	10798	ISLAT	2	2020-08-23 06:47:45	2020-09-20 06:47:45	2020-09-02 06:47:45	1	2.33
file_server	10799	KOENE	9	2020-08-23 06:47:45	2020-10-04 06:47:45	2020-09-02 06:47:45	3	30.76
file_server	10800	SEVES	1	2020-08-23 06:47:45	2020-09-20 06:47:45	2020-09-02 06:47:45	3	137.44
file_server	10801	BOLID	4	2020-08-30 16:10:01	2020-09-27 16:10:01	2020-09-01 16:10:01	2	97.09
file_server	10802	SIMOB	4	2020-08-30 16:10:01	2020-09-27 16:10:01	2020-09-03 16:10:01	2	257.26
file_server	10803	WELLI	4	2020-09-02 03:17:26	2020-09-30 03:17:26	2020-09-09 03:17:26	1	55.23
file_server	10804	SEVES	6	2020-09-02 03:17:26	2020-09-30 03:17:26	2020-09-10 03:17:26	2	27.33
file_server	10805	THEBI	2	2020-09-02 03:17:26	2020-09-30 03:17:26	2020-09-12 03:17:26	3	237.34
file_server	10806	VICTE	3	2020-09-04 14:24:52	2020-10-02 14:24:52	2020-09-09 14:24:52	2	22.11
file_server	10807	FRANS	4	2020-09-04 14:24:52	2020-10-02 14:24:52	2020-10-04 14:24:52	1	1.36
file_server	10808	OLDWO	2	2020-09-07 01:32:17	2020-10-05 01:32:17	2020-09-15 01:32:17	3	45.53
file_server	10809	WELLI	7	2020-09-07 01:32:17	2020-10-05 01:32:17	2020-09-13 01:32:17	1	4.87
file_server	10810	LAUGB	2	2020-09-07 01:32:17	2020-10-05 01:32:17	2020-09-13 01:32:17	3	4.33
file_server	10811	LINOD	8	2020-09-09 12:39:42	2020-10-07 12:39:42	2020-09-15 12:39:42	1	31.22
file_server	10812	REGGC	5	2020-09-09 12:39:42	2020-10-07 12:39:42	2020-09-19 12:39:42	1	59.78
file_server	10813	RICAR	1	2020-09-16 22:01:58	2020-10-14 22:01:58	2020-09-20 22:01:58	1	47.38
file_server	10814	VICTE	3	2020-09-16 22:01:58	2020-10-14 22:01:58	2020-09-25 22:01:58	3	130.94
file_server	10815	SAVEA	2	2020-09-16 22:01:58	2020-10-14 22:01:58	2020-09-25 22:01:58	3	14.62
file_server	10816	GREAL	4	2020-09-19 09:09:23	2020-10-17 09:09:23	2020-10-18 09:09:23	2	719.78
file_server	10817	KOENE	3	2020-09-19 09:09:23	2020-10-03 09:09:23	2020-09-26 09:09:23	2	306.07
file_server	10818	MAGAA	7	2020-09-21 20:16:49	2020-10-19 20:16:49	2020-09-26 20:16:49	3	65.48
file_server	10819	CACTU	2	2020-09-21 20:16:49	2020-10-19 20:16:49	2020-09-30 20:16:49	3	19.76
file_server	10820	RATTC	3	2020-09-21 20:16:49	2020-10-19 20:16:49	2020-09-27 20:16:49	2	37.52
file_server	10821	SPLIR	1	2020-09-24 07:24:14	2020-10-22 07:24:14	2020-10-01 07:24:14	1	36.68
file_server	10822	TRAIH	6	2020-09-24 07:24:14	2020-10-22 07:24:14	2020-10-02 07:24:14	3	7
file_server	10823	LILAS	5	2020-09-26 18:31:39	2020-10-24 18:31:39	2020-09-30 18:31:39	2	163.97
file_server	10824	FOLKO	8	2020-09-26 18:31:39	2020-10-24 18:31:39	2020-10-17 18:31:39	1	1.23
file_server	10825	DRACD	1	2020-09-26 18:31:39	2020-10-24 18:31:39	2020-10-01 18:31:39	1	79.25
file_server	10826	BLONP	6	2020-10-04 03:53:55	2020-11-01 03:53:55	2020-10-29 03:53:55	1	7.09
file_server	10827	BONAP	1	2020-10-04 03:53:55	2020-10-18 03:53:55	2020-10-29 03:53:55	2	63.54
file_server	10828	RANCH	9	2020-10-06 15:01:20	2020-10-20 15:01:20	2020-10-28 15:01:20	1	90.85
file_server	10829	ISLAT	9	2020-10-06 15:01:20	2020-11-03 15:01:20	2020-10-16 15:01:20	1	154.72
file_server	10830	TRADH	4	2020-10-06 15:01:20	2020-11-17 15:01:20	2020-10-14 15:01:20	2	81.83
file_server	10831	SANTG	3	2020-10-09 02:08:46	2020-11-06 02:08:46	2020-10-18 02:08:46	2	72.19
file_server	10832	LAMAI	2	2020-10-09 02:08:46	2020-11-06 02:08:46	2020-10-14 02:08:46	2	43.26
file_server	10833	OTTIK	6	2020-10-11 13:16:11	2020-11-08 13:16:11	2020-10-19 13:16:11	2	71.49
file_server	10834	TRADH	1	2020-10-11 13:16:11	2020-11-08 13:16:11	2020-10-15 13:16:11	3	29.78
file_server	10835	ALFKI	1	2020-10-11 13:16:11	2020-11-08 13:16:11	2020-10-17 13:16:11	3	69.53
file_server	10836	ERNSH	7	2020-10-14 00:23:36	2020-11-11 00:23:36	2020-10-19 00:23:36	1	411.88
file_server	10837	BERGS	9	2020-10-14 00:23:36	2020-11-11 00:23:36	2020-10-21 00:23:36	3	13.32
file_server	10838	LINOD	3	2020-10-21 09:45:52	2020-11-18 09:45:52	2020-10-25 09:45:52	3	59.28
file_server	10839	TRADH	3	2020-10-21 09:45:52	2020-11-18 09:45:52	2020-10-24 09:45:52	3	35.43
file_server	10840	LINOD	4	2020-10-21 09:45:52	2020-12-02 09:45:52	2020-11-18 09:45:52	2	2.71
file_server	10841	SUPRD	5	2020-10-23 20:53:18	2020-11-20 20:53:18	2020-11-01 20:53:18	2	424.3
file_server	10842	TORTU	1	2020-10-23 20:53:18	2020-11-20 20:53:18	2020-11-01 20:53:18	3	54.42
file_server	10843	VICTE	4	2020-10-26 08:00:43	2020-11-23 08:00:43	2020-10-31 08:00:43	2	9.26
file_server	10844	PICCO	8	2020-10-26 08:00:43	2020-11-23 08:00:43	2020-10-31 08:00:43	2	25.22
file_server	10845	QUICK	8	2020-10-26 08:00:43	2020-11-09 08:00:43	2020-11-04 08:00:43	1	212.98
file_server	10846	SUPRD	2	2020-10-28 19:08:08	2020-12-09 19:08:08	2020-10-29 19:08:08	3	56.46
file_server	10847	SAVEA	4	2020-10-28 19:08:08	2020-11-11 19:08:08	2020-11-16 19:08:08	3	487.57
file_server	10848	CONSH	7	2020-10-31 06:15:34	2020-11-28 06:15:34	2020-11-06 06:15:34	2	38.24
file_server	10849	KOENE	9	2020-10-31 06:15:34	2020-11-28 06:15:34	2020-11-07 06:15:34	2	0.56
file_server	10850	VICTE	1	2020-10-31 06:15:34	2020-12-12 06:15:34	2020-11-07 06:15:34	1	49.19
file_server	10851	RICAR	5	2020-11-07 15:37:49	2020-12-05 15:37:49	2020-11-14 15:37:49	1	160.55
file_server	10852	RATTC	8	2020-11-07 15:37:49	2020-11-21 15:37:49	2020-11-11 15:37:49	1	174.05
file_server	10853	BLAUS	9	2020-11-10 02:45:15	2020-12-08 02:45:15	2020-11-17 02:45:15	2	53.83
file_server	10854	ERNSH	3	2020-11-10 02:45:15	2020-12-08 02:45:15	2020-11-19 02:45:15	2	100.22
file_server	10855	OLDWO	3	2020-11-10 02:45:15	2020-12-08 02:45:15	2020-11-18 02:45:15	1	170.97
file_server	10856	ANTON	3	2020-11-12 13:52:40	2020-12-10 13:52:40	2020-11-25 13:52:40	2	58.43
file_server	10857	BERGS	8	2020-11-12 13:52:40	2020-12-10 13:52:40	2020-11-21 13:52:40	2	188.85
file_server	10858	LACOR	2	2020-11-15 01:00:05	2020-12-13 01:00:05	2020-11-20 01:00:05	1	52.51
file_server	10859	FRANK	1	2020-11-15 01:00:05	2020-12-13 01:00:05	2020-11-19 01:00:05	2	76.1
file_server	10860	FRANR	3	2020-11-15 01:00:05	2020-12-13 01:00:05	2020-11-21 01:00:05	3	19.26
file_server	10861	WHITC	4	2020-11-17 12:07:31	2020-12-15 12:07:31	2020-12-05 12:07:31	2	14.93
file_server	10862	LEHMS	8	2020-11-17 12:07:31	2020-12-29 12:07:31	2020-11-20 12:07:31	2	53.23
file_server	10863	HILAA	4	2020-11-24 21:29:47	2020-12-22 21:29:47	2020-12-09 21:29:47	2	30.26
file_server	10864	AROUT	4	2020-11-24 21:29:47	2020-12-22 21:29:47	2020-12-01 21:29:47	2	3.04
file_server	10865	QUICK	2	2020-11-24 21:29:47	2020-12-08 21:29:47	2020-12-04 21:29:47	1	348.14
file_server	10866	BERGS	5	2020-11-27 08:37:12	2020-12-25 08:37:12	2020-12-06 08:37:12	1	109.11
file_server	10867	LONEP	6	2020-11-27 08:37:12	2021-01-08 08:37:12	2020-12-05 08:37:12	1	1.93
file_server	10868	QUEEN	7	2020-11-29 19:44:37	2020-12-27 19:44:37	2020-12-18 19:44:37	2	191.27
file_server	10869	SEVES	5	2020-11-29 19:44:37	2020-12-27 19:44:37	2020-12-04 19:44:37	1	143.28
file_server	10870	WOLZA	5	2020-11-29 19:44:37	2020-12-27 19:44:37	2020-12-08 19:44:37	3	12.04
file_server	10871	BONAP	9	2020-12-02 06:52:03	2020-12-30 06:52:03	2020-12-07 06:52:03	2	112.27
file_server	10872	GODOS	5	2020-12-02 06:52:03	2020-12-30 06:52:03	2020-12-06 06:52:03	2	175.32
file_server	10873	WILMK	4	2020-12-04 17:59:28	2021-01-01 17:59:28	2020-12-07 17:59:28	1	0.82
file_server	10874	GODOS	5	2020-12-04 17:59:28	2021-01-01 17:59:28	2020-12-09 17:59:28	2	19.58
file_server	10875	BERGS	4	2020-12-04 17:59:28	2021-01-01 17:59:28	2020-12-29 17:59:28	2	32.37
file_server	10876	BONAP	7	2020-12-12 03:21:44	2021-01-09 03:21:44	2020-12-15 03:21:44	3	60.42
file_server	10877	RICAR	1	2020-12-12 03:21:44	2021-01-09 03:21:44	2020-12-22 03:21:44	1	38.06
file_server	10878	QUICK	4	2020-12-14 14:29:09	2021-01-11 14:29:09	2020-12-16 14:29:09	1	46.69
file_server	10879	WILMK	3	2020-12-14 14:29:09	2021-01-11 14:29:09	2020-12-16 14:29:09	3	8.5
file_server	10880	FOLKO	7	2020-12-14 14:29:09	2021-01-25 14:29:09	2020-12-22 14:29:09	1	88.01
file_server	10881	CACTU	4	2020-12-17 01:36:34	2021-01-14 01:36:34	2020-12-24 01:36:34	1	2.84
file_server	10882	SAVEA	4	2020-12-17 01:36:34	2021-01-14 01:36:34	2020-12-26 01:36:34	3	23.1
file_server	10883	LONEP	8	2020-12-19 12:44:00	2021-01-16 12:44:00	2020-12-27 12:44:00	3	0.53
file_server	10884	LETSS	4	2020-12-19 12:44:00	2021-01-16 12:44:00	2020-12-20 12:44:00	2	90.97
file_server	10885	SUPRD	6	2020-12-19 12:44:00	2021-01-16 12:44:00	2020-12-25 12:44:00	3	5.64
file_server	10886	HANAR	1	2020-12-21 23:51:25	2021-01-18 23:51:25	2021-01-07 23:51:25	1	4.99
file_server	10887	GALED	8	2020-12-21 23:51:25	2021-01-18 23:51:25	2020-12-24 23:51:25	3	1.25
file_server	10888	GODOS	1	2020-12-29 09:13:41	2021-01-26 09:13:41	2021-01-05 09:13:41	2	51.87
file_server	10889	RATTC	9	2020-12-29 09:13:41	2021-01-26 09:13:41	2021-01-05 09:13:41	3	280.61
file_server	10890	DUMON	7	2020-12-29 09:13:41	2021-01-26 09:13:41	2020-12-31 09:13:41	1	32.76
file_server	10891	LEHMS	7	2020-12-31 20:21:06	2021-01-28 20:21:06	2021-01-02 20:21:06	2	20.37
file_server	10892	MAISD	4	2020-12-31 20:21:06	2021-01-28 20:21:06	2021-01-02 20:21:06	2	120.27
\.


--
-- Data for Name: structured_file_server_orders_2021; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_orders_2021 (permission_scope_key, orderid, customerid, employeeid, orderdate, requireddate, shippeddate, shipperid, freight) FROM stdin;
file_server	10893	KOENE	9	2021-01-03 07:28:31	2021-01-31 07:28:31	2021-01-05 07:28:31	2	77.78
file_server	10894	SAVEA	1	2021-01-03 07:28:31	2021-01-31 07:28:31	2021-01-05 07:28:31	1	116.13
file_server	10895	ERNSH	3	2021-01-03 07:28:31	2021-01-31 07:28:31	2021-01-08 07:28:31	1	162.75
file_server	10896	MAISD	7	2021-01-05 18:35:57	2021-02-02 18:35:57	2021-01-13 18:35:57	3	32.45
file_server	10897	HUNGO	3	2021-01-05 18:35:57	2021-02-02 18:35:57	2021-01-11 18:35:57	2	603.54
file_server	10898	OCEAN	4	2021-01-08 05:43:22	2021-02-05 05:43:22	2021-01-22 05:43:22	2	1.27
file_server	10899	LILAS	5	2021-01-08 05:43:22	2021-02-05 05:43:22	2021-01-14 05:43:22	3	1.21
file_server	10900	WELLI	1	2021-01-08 05:43:22	2021-02-05 05:43:22	2021-01-20 05:43:22	2	1.66
file_server	10901	HILAA	4	2021-01-15 15:05:38	2021-02-12 15:05:38	2021-01-18 15:05:38	1	62.09
file_server	10902	FOLKO	1	2021-01-15 15:05:38	2021-02-12 15:05:38	2021-01-23 15:05:38	1	44.15
file_server	10903	HANAR	3	2021-01-18 02:13:03	2021-02-15 02:13:03	2021-01-26 02:13:03	3	36.71
file_server	10904	WHITC	3	2021-01-18 02:13:03	2021-02-15 02:13:03	2021-01-21 02:13:03	3	162.95
file_server	10905	WELLI	9	2021-01-18 02:13:03	2021-02-15 02:13:03	2021-01-28 02:13:03	2	13.72
file_server	10906	WOLZA	4	2021-01-20 13:20:29	2021-02-03 13:20:29	2021-01-26 13:20:29	3	26.29
file_server	10907	SPECD	6	2021-01-20 13:20:29	2021-02-17 13:20:29	2021-01-22 13:20:29	3	9.19
file_server	10908	REGGC	4	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-01-31 00:27:54	2	32.96
file_server	10909	SANTG	1	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-02-04 00:27:54	2	53.05
file_server	10910	WILMK	1	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-01-29 00:27:54	3	38.11
file_server	10911	GODOS	3	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-01-30 00:27:54	1	38.19
file_server	10912	HUNGO	2	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-02-12 00:27:54	2	580.91
file_server	10913	QUEEN	4	2021-01-23 00:27:54	2021-02-20 00:27:54	2021-01-29 00:27:54	1	33.05
file_server	10914	QUEEN	6	2021-01-25 11:35:19	2021-02-22 11:35:19	2021-01-28 11:35:19	1	21.19
file_server	10915	TORTU	2	2021-01-25 11:35:19	2021-02-22 11:35:19	2021-01-28 11:35:19	2	3.51
file_server	10916	RANCH	1	2021-01-25 11:35:19	2021-02-22 11:35:19	2021-02-04 11:35:19	2	63.77
file_server	10917	ROMEY	4	2021-02-01 20:57:35	2021-03-01 20:57:35	2021-02-10 20:57:35	2	8.29
file_server	10918	BOTTM	3	2021-02-01 20:57:35	2021-03-01 20:57:35	2021-02-10 20:57:35	3	48.83
file_server	10919	LINOD	2	2021-02-01 20:57:35	2021-03-01 20:57:35	2021-02-03 20:57:35	2	19.8
file_server	10920	AROUT	4	2021-02-04 08:05:00	2021-03-04 08:05:00	2021-02-10 08:05:00	2	29.61
file_server	10921	VAFFE	1	2021-02-04 08:05:00	2021-03-18 08:05:00	2021-02-10 08:05:00	1	176.48
file_server	10922	HANAR	5	2021-02-04 08:05:00	2021-03-04 08:05:00	2021-02-06 08:05:00	3	62.74
file_server	10923	LAMAI	7	2021-02-04 08:05:00	2021-03-18 08:05:00	2021-02-14 08:05:00	3	68.26
file_server	10924	BERGS	3	2021-02-06 19:12:26	2021-03-06 19:12:26	2021-03-13 19:12:26	2	151.52
file_server	10925	HANAR	3	2021-02-06 19:12:26	2021-03-06 19:12:26	2021-02-15 19:12:26	1	2.27
file_server	10926	ANATR	4	2021-02-06 19:12:26	2021-03-06 19:12:26	2021-02-13 19:12:26	3	39.92
file_server	10927	LACOR	4	2021-02-09 06:19:51	2021-03-09 06:19:51	2021-03-15 06:19:51	1	19.79
file_server	10928	GALED	1	2021-02-09 06:19:51	2021-03-09 06:19:51	2021-02-22 06:19:51	1	1.36
file_server	10929	FRANK	6	2021-02-09 06:19:51	2021-03-09 06:19:51	2021-02-16 06:19:51	1	33.93
file_server	10930	SUPRD	4	2021-02-11 17:27:16	2021-03-25 17:27:16	2021-02-23 17:27:16	3	15.55
file_server	10931	RICSU	4	2021-02-11 17:27:16	2021-02-25 17:27:16	2021-02-24 17:27:16	2	13.6
file_server	10932	BONAP	8	2021-02-11 17:27:16	2021-03-11 17:27:16	2021-03-01 17:27:16	1	134.64
file_server	10933	ISLAT	6	2021-02-11 17:27:16	2021-03-11 17:27:16	2021-02-21 17:27:16	3	54.15
file_server	10934	LEHMS	3	2021-02-19 02:49:32	2021-03-19 02:49:32	2021-02-22 02:49:32	3	32.01
file_server	10935	WELLI	4	2021-02-19 02:49:32	2021-03-19 02:49:32	2021-02-28 02:49:32	3	47.59
file_server	10936	GREAL	3	2021-02-19 02:49:32	2021-03-19 02:49:32	2021-02-28 02:49:32	2	33.68
file_server	10937	CACTU	7	2021-02-21 13:56:58	2021-03-07 13:56:58	2021-02-24 13:56:58	3	31.51
file_server	10938	QUICK	3	2021-02-21 13:56:58	2021-03-21 13:56:58	2021-02-27 13:56:58	2	31.89
file_server	10939	MAGAA	2	2021-02-21 13:56:58	2021-03-21 13:56:58	2021-02-24 13:56:58	2	76.33
file_server	10940	BONAP	8	2021-02-24 01:04:23	2021-03-24 01:04:23	2021-03-08 01:04:23	3	19.77
file_server	10941	SAVEA	7	2021-02-24 01:04:23	2021-03-24 01:04:23	2021-03-05 01:04:23	2	400.81
file_server	10942	REGGC	9	2021-02-24 01:04:23	2021-03-24 01:04:23	2021-03-03 01:04:23	3	17.95
file_server	10943	BSBEV	4	2021-02-24 01:04:23	2021-03-24 01:04:23	2021-03-04 01:04:23	2	2.17
file_server	10944	BOTTM	6	2021-02-26 12:11:48	2021-03-12 12:11:48	2021-02-27 12:11:48	3	52.92
file_server	10945	MORGK	4	2021-02-26 12:11:48	2021-03-26 12:11:48	2021-03-04 12:11:48	1	10.22
file_server	10946	VAFFE	1	2021-02-26 12:11:48	2021-03-26 12:11:48	2021-03-05 12:11:48	2	27.2
file_server	10947	BSBEV	3	2021-02-28 23:19:14	2021-03-28 23:19:14	2021-03-03 23:19:14	2	3.26
file_server	10948	GODOS	3	2021-02-28 23:19:14	2021-03-28 23:19:14	2021-03-06 23:19:14	3	23.39
file_server	10949	BOTTM	2	2021-02-28 23:19:14	2021-03-28 23:19:14	2021-03-04 23:19:14	3	74.44
file_server	10950	MAGAA	1	2021-03-08 08:41:29	2021-04-05 08:41:29	2021-03-15 08:41:29	2	2.5
file_server	10951	RICSU	9	2021-03-08 08:41:29	2021-04-19 08:41:29	2021-03-30 08:41:29	2	30.85
file_server	10952	ALFKI	1	2021-03-08 08:41:29	2021-04-19 08:41:29	2021-03-16 08:41:29	1	40.42
file_server	10953	AROUT	9	2021-03-08 08:41:29	2021-03-22 08:41:29	2021-03-17 08:41:29	2	23.72
file_server	10954	LINOD	5	2021-03-10 19:48:55	2021-04-21 19:48:55	2021-03-13 19:48:55	1	27.91
file_server	10955	FOLKO	8	2021-03-10 19:48:55	2021-04-07 19:48:55	2021-03-13 19:48:55	2	3.26
file_server	10956	BLAUS	6	2021-03-10 19:48:55	2021-04-21 19:48:55	2021-03-13 19:48:55	2	44.65
file_server	10957	HILAA	8	2021-03-13 06:56:20	2021-04-10 06:56:20	2021-03-22 06:56:20	3	105.36
file_server	10958	OCEAN	7	2021-03-13 06:56:20	2021-04-10 06:56:20	2021-03-22 06:56:20	2	49.56
file_server	10959	GOURL	6	2021-03-13 06:56:20	2021-04-24 06:56:20	2021-03-18 06:56:20	2	4.98
file_server	10960	HILAA	3	2021-03-15 18:03:45	2021-03-29 18:03:45	2021-04-04 18:03:45	1	2.08
file_server	10961	QUEEN	8	2021-03-15 18:03:45	2021-04-12 18:03:45	2021-03-26 18:03:45	1	104.47
file_server	10962	QUICK	8	2021-03-15 18:03:45	2021-04-12 18:03:45	2021-03-19 18:03:45	2	275.79
file_server	10963	FURIB	9	2021-03-15 18:03:45	2021-04-12 18:03:45	2021-03-22 18:03:45	3	2.7
file_server	10964	SPECD	3	2021-03-18 05:11:11	2021-04-15 05:11:11	2021-03-22 05:11:11	2	87.38
file_server	10965	OLDWO	6	2021-03-18 05:11:11	2021-04-15 05:11:11	2021-03-28 05:11:11	3	144.38
file_server	10966	CHOPS	4	2021-03-18 05:11:11	2021-04-15 05:11:11	2021-04-06 05:11:11	1	27.19
file_server	10967	TOMSP	2	2021-03-25 14:33:27	2021-04-22 14:33:27	2021-04-04 14:33:27	2	62.22
file_server	10968	ERNSH	1	2021-03-25 14:33:27	2021-04-22 14:33:27	2021-04-03 14:33:27	3	74.6
file_server	10969	COMMI	1	2021-03-25 14:33:27	2021-04-22 14:33:27	2021-04-01 14:33:27	2	0.21
file_server	10970	BOLID	9	2021-03-28 01:40:52	2021-04-11 01:40:52	2021-04-28 01:40:52	1	16.16
file_server	10971	FRANR	2	2021-03-28 01:40:52	2021-04-25 01:40:52	2021-04-06 01:40:52	2	121.82
file_server	10972	LACOR	4	2021-03-28 01:40:52	2021-04-25 01:40:52	2021-03-30 01:40:52	2	0.02
file_server	10973	LACOR	6	2021-03-28 01:40:52	2021-04-25 01:40:52	2021-03-31 01:40:52	2	15.17
file_server	10974	SPLIR	3	2021-03-30 12:48:17	2021-04-13 12:48:17	2021-04-08 12:48:17	3	12.96
file_server	10975	BOTTM	1	2021-03-30 12:48:17	2021-04-27 12:48:17	2021-04-01 12:48:17	3	32.27
file_server	10976	HILAA	1	2021-03-30 12:48:17	2021-05-11 12:48:17	2021-04-08 12:48:17	1	37.97
file_server	10977	FOLKO	8	2021-04-01 23:55:42	2021-04-29 23:55:42	2021-04-16 23:55:42	3	208.5
file_server	10978	MAISD	9	2021-04-01 23:55:42	2021-04-29 23:55:42	2021-04-29 23:55:42	2	32.82
file_server	10979	ERNSH	8	2021-04-01 23:55:42	2021-04-29 23:55:42	2021-04-06 23:55:42	2	353.07
file_server	10980	FOLKO	4	2021-04-04 11:03:08	2021-05-16 11:03:08	2021-04-25 11:03:08	1	1.26
file_server	10981	HANAR	1	2021-04-04 11:03:08	2021-05-02 11:03:08	2021-04-10 11:03:08	2	193.37
file_server	10982	BOTTM	2	2021-04-04 11:03:08	2021-05-02 11:03:08	2021-04-16 11:03:08	1	14.01
file_server	10983	SAVEA	2	2021-04-04 11:03:08	2021-05-02 11:03:08	2021-04-14 11:03:08	2	657.54
file_server	10984	SAVEA	1	2021-04-11 20:25:24	2021-05-09 20:25:24	2021-04-15 20:25:24	3	211.22
file_server	10985	HUNGO	2	2021-04-11 20:25:24	2021-05-09 20:25:24	2021-04-14 20:25:24	1	91.51
file_server	10986	OCEAN	8	2021-04-11 20:25:24	2021-05-09 20:25:24	2021-05-03 20:25:24	2	217.86
file_server	10987	EASTC	8	2021-04-14 07:32:49	2021-05-12 07:32:49	2021-04-20 07:32:49	1	185.48
file_server	10988	RATTC	3	2021-04-14 07:32:49	2021-05-12 07:32:49	2021-04-24 07:32:49	2	61.14
file_server	10989	QUEDE	2	2021-04-14 07:32:49	2021-05-12 07:32:49	2021-04-16 07:32:49	1	34.76
file_server	10990	ERNSH	2	2021-04-16 18:40:14	2021-05-28 18:40:14	2021-04-22 18:40:14	3	117.61
file_server	10991	QUICK	1	2021-04-16 18:40:14	2021-05-14 18:40:14	2021-04-22 18:40:14	1	38.51
file_server	10992	THEBI	1	2021-04-16 18:40:14	2021-05-14 18:40:14	2021-04-18 18:40:14	3	4.27
file_server	10993	FOLKO	7	2021-04-16 18:40:14	2021-05-14 18:40:14	2021-04-25 18:40:14	3	8.81
file_server	10994	VAFFE	2	2021-04-19 05:47:40	2021-05-03 05:47:40	2021-04-26 05:47:40	3	65.53
file_server	10995	PERIC	1	2021-04-19 05:47:40	2021-05-17 05:47:40	2021-04-23 05:47:40	3	46
file_server	10996	QUICK	4	2021-04-19 05:47:40	2021-05-17 05:47:40	2021-04-27 05:47:40	2	1.12
file_server	10997	LILAS	8	2021-04-21 16:55:05	2021-06-02 16:55:05	2021-05-01 16:55:05	2	73.91
file_server	10998	WOLZA	8	2021-04-21 16:55:05	2021-05-05 16:55:05	2021-05-05 16:55:05	2	20.31
file_server	10999	OTTIK	6	2021-04-21 16:55:05	2021-05-19 16:55:05	2021-04-28 16:55:05	2	96.35
file_server	11000	RATTC	2	2021-04-29 02:17:21	2021-05-27 02:17:21	2021-05-07 02:17:21	3	55.12
file_server	11001	FOLKO	2	2021-04-29 02:17:21	2021-05-27 02:17:21	2021-05-07 02:17:21	2	197.3
file_server	11002	SAVEA	4	2021-04-29 02:17:21	2021-05-27 02:17:21	2021-05-09 02:17:21	1	141.16
file_server	11003	THECR	3	2021-04-29 02:17:21	2021-05-27 02:17:21	2021-05-01 02:17:21	3	14.91
file_server	11004	MAISD	3	2021-05-01 13:24:46	2021-05-29 13:24:46	2021-05-14 13:24:46	1	44.84
file_server	11005	WILMK	2	2021-05-01 13:24:46	2021-05-29 13:24:46	2021-05-04 13:24:46	1	0.75
file_server	11006	GREAL	3	2021-05-01 13:24:46	2021-05-29 13:24:46	2021-05-09 13:24:46	2	25.19
file_server	11007	PRINI	8	2021-05-04 00:32:11	2021-06-01 00:32:11	2021-05-09 00:32:11	2	202.24
file_server	11008	ERNSH	7	2021-05-04 00:32:11	2021-06-01 00:32:11	\N	3	79.46
file_server	11009	GODOS	2	2021-05-04 00:32:11	2021-06-01 00:32:11	2021-05-06 00:32:11	1	59.11
file_server	11010	REGGC	2	2021-05-06 11:39:37	2021-06-03 11:39:37	2021-05-18 11:39:37	2	28.71
file_server	11011	ALFKI	3	2021-05-06 11:39:37	2021-06-03 11:39:37	2021-05-10 11:39:37	1	1.21
file_server	11012	FRANK	1	2021-05-06 11:39:37	2021-05-20 11:39:37	2021-05-14 11:39:37	3	242.95
file_server	11013	ROMEY	2	2021-05-06 11:39:37	2021-06-03 11:39:37	2021-05-07 11:39:37	1	32.99
file_server	11014	LINOD	2	2021-05-08 22:47:02	2021-06-05 22:47:02	2021-05-13 22:47:02	3	23.6
file_server	11015	SANTG	2	2021-05-08 22:47:02	2021-05-22 22:47:02	2021-05-18 22:47:02	2	4.62
file_server	11016	AROUT	9	2021-05-08 22:47:02	2021-06-05 22:47:02	2021-05-11 22:47:02	2	33.8
file_server	11017	ERNSH	9	2021-05-16 08:09:18	2021-06-13 08:09:18	2021-05-23 08:09:18	2	754.26
file_server	11018	LONEP	4	2021-05-16 08:09:18	2021-06-13 08:09:18	2021-05-19 08:09:18	2	11.65
file_server	11019	RANCH	6	2021-05-16 08:09:18	2021-06-13 08:09:18	\N	3	3.17
file_server	11020	OTTIK	2	2021-05-18 19:16:43	2021-06-15 19:16:43	2021-05-20 19:16:43	2	43.3
file_server	11021	QUICK	3	2021-05-18 19:16:43	2021-06-15 19:16:43	2021-05-25 19:16:43	1	297.18
file_server	11022	HANAR	9	2021-05-18 19:16:43	2021-06-15 19:16:43	2021-06-07 19:16:43	2	6.27
file_server	11023	BSBEV	1	2021-05-18 19:16:43	2021-06-01 19:16:43	2021-05-28 19:16:43	2	123.83
file_server	11024	EASTC	4	2021-05-21 06:24:09	2021-06-18 06:24:09	2021-05-26 06:24:09	1	74.36
file_server	11025	WARTH	6	2021-05-21 06:24:09	2021-06-18 06:24:09	2021-05-30 06:24:09	3	29.17
file_server	11026	FRANS	4	2021-05-21 06:24:09	2021-06-18 06:24:09	2021-06-03 06:24:09	1	47.09
file_server	11027	BOTTM	1	2021-05-23 17:31:34	2021-06-20 17:31:34	2021-05-27 17:31:34	1	52.52
file_server	11028	KOENE	2	2021-05-23 17:31:34	2021-06-20 17:31:34	2021-05-29 17:31:34	1	29.59
file_server	11029	CHOPS	4	2021-05-23 17:31:34	2021-06-20 17:31:34	2021-06-03 17:31:34	1	47.84
file_server	11030	SAVEA	7	2021-05-26 04:38:59	2021-06-23 04:38:59	2021-06-05 04:38:59	2	830.75
file_server	11031	SAVEA	6	2021-05-26 04:38:59	2021-06-23 04:38:59	2021-06-02 04:38:59	2	227.22
file_server	11032	WHITC	2	2021-05-26 04:38:59	2021-06-23 04:38:59	2021-06-01 04:38:59	3	606.19
file_server	11033	RICSU	7	2021-05-26 04:38:59	2021-06-23 04:38:59	2021-06-01 04:38:59	3	84.74
file_server	11034	OLDWO	8	2021-06-02 14:01:15	2021-07-14 14:01:15	2021-06-09 14:01:15	1	40.32
file_server	11035	SUPRD	2	2021-06-02 14:01:15	2021-06-30 14:01:15	2021-06-06 14:01:15	2	0.17
file_server	11036	DRACD	8	2021-06-02 14:01:15	2021-06-30 14:01:15	2021-06-04 14:01:15	3	149.47
file_server	11037	GODOS	7	2021-06-05 01:08:40	2021-07-03 01:08:40	2021-06-11 01:08:40	1	3.2
file_server	11038	SUPRD	1	2021-06-05 01:08:40	2021-07-03 01:08:40	2021-06-14 01:08:40	2	29.59
file_server	11039	LINOD	1	2021-06-05 01:08:40	2021-07-03 01:08:40	\N	2	65
file_server	11040	GREAL	4	2021-06-07 12:16:06	2021-07-05 12:16:06	\N	3	18.84
file_server	11041	CHOPS	3	2021-06-07 12:16:06	2021-07-05 12:16:06	2021-06-13 12:16:06	2	48.22
file_server	11042	COMMI	2	2021-06-07 12:16:06	2021-06-21 12:16:06	2021-06-16 12:16:06	1	29.99
file_server	11043	SPECD	5	2021-06-07 12:16:06	2021-07-05 12:16:06	2021-06-14 12:16:06	2	8.8
file_server	11044	WOLZA	4	2021-06-09 23:23:31	2021-07-07 23:23:31	2021-06-17 23:23:31	1	8.72
file_server	11045	BOTTM	6	2021-06-09 23:23:31	2021-07-07 23:23:31	\N	2	70.58
file_server	11046	WANDK	8	2021-06-09 23:23:31	2021-07-07 23:23:31	2021-06-10 23:23:31	2	71.64
file_server	11047	EASTC	7	2021-06-12 10:30:56	2021-07-10 10:30:56	2021-06-19 10:30:56	3	46.62
file_server	11048	BOTTM	7	2021-06-12 10:30:56	2021-07-10 10:30:56	2021-06-18 10:30:56	3	24.12
file_server	11049	GOURL	3	2021-06-12 10:30:56	2021-07-10 10:30:56	2021-06-22 10:30:56	1	8.34
file_server	11050	FOLKO	8	2021-06-19 19:53:12	2021-07-17 19:53:12	2021-06-27 19:53:12	2	59.41
file_server	11051	LAMAI	7	2021-06-19 19:53:12	2021-07-17 19:53:12	\N	3	2.79
file_server	11052	HANAR	3	2021-06-19 19:53:12	2021-07-17 19:53:12	2021-06-23 19:53:12	1	67.26
file_server	11053	PICCO	2	2021-06-19 19:53:12	2021-07-17 19:53:12	2021-06-21 19:53:12	2	53.05
file_server	11054	CACTU	8	2021-06-22 07:00:38	2021-07-20 07:00:38	\N	1	0.33
file_server	11055	HILAA	7	2021-06-22 07:00:38	2021-07-20 07:00:38	2021-06-29 07:00:38	2	120.92
file_server	11056	EASTC	8	2021-06-22 07:00:38	2021-07-06 07:00:38	2021-06-25 07:00:38	2	278.96
file_server	11057	NORTS	3	2021-06-24 18:08:03	2021-07-22 18:08:03	2021-06-26 18:08:03	3	4.13
file_server	11058	BLAUS	9	2021-06-24 18:08:03	2021-07-22 18:08:03	\N	3	31.14
file_server	11059	RICAR	2	2021-06-24 18:08:03	2021-08-05 18:08:03	\N	2	85.8
file_server	11060	FRANS	2	2021-06-27 05:15:28	2021-07-25 05:15:28	2021-07-01 05:15:28	2	10.98
file_server	11061	GREAL	4	2021-06-27 05:15:28	2021-08-08 05:15:28	\N	3	14.01
file_server	11062	REGGC	4	2021-06-27 05:15:28	2021-07-25 05:15:28	\N	2	29.93
file_server	11063	HUNGO	3	2021-06-27 05:15:28	2021-07-25 05:15:28	2021-07-03 05:15:28	2	81.73
file_server	11064	SAVEA	1	2021-06-29 16:22:53	2021-07-27 16:22:53	2021-07-02 16:22:53	1	30.09
file_server	11065	LILAS	8	2021-06-29 16:22:53	2021-07-27 16:22:53	\N	1	12.91
file_server	11066	WHITC	7	2021-06-29 16:22:53	2021-07-27 16:22:53	2021-07-02 16:22:53	2	44.72
file_server	11067	DRACD	1	2021-07-07 01:45:09	2021-07-21 01:45:09	2021-07-09 01:45:09	2	7.98
file_server	11068	QUEEN	8	2021-07-07 01:45:09	2021-08-04 01:45:09	\N	2	81.75
file_server	11069	TORTU	1	2021-07-07 01:45:09	2021-08-04 01:45:09	2021-07-09 01:45:09	2	15.67
file_server	11070	LEHMS	2	2021-07-09 12:52:35	2021-08-06 12:52:35	\N	1	136
file_server	11071	LILAS	1	2021-07-09 12:52:35	2021-08-06 12:52:35	\N	1	0.93
file_server	11072	ERNSH	4	2021-07-09 12:52:35	2021-08-06 12:52:35	\N	2	258.64
file_server	11073	PERIC	2	2021-07-09 12:52:35	2021-08-06 12:52:35	\N	2	24.95
file_server	11074	SIMOB	7	2021-07-12	2021-08-09	\N	2	18.44
file_server	11075	RICSU	8	2021-07-12	2021-08-09	\N	2	6.19
file_server	11076	BONAP	4	2021-07-12	2021-08-09	\N	2	38.28
file_server	11077	RATTC	1	2021-07-12	2021-08-09	\N	2	8.53
\.


--
-- Data for Name: structured_file_server_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_products (permission_scope_key, productid, productname, quantityperunit, currentprice, discontinued, categoryid) FROM stdin;
file_server	1	Chai	10 boxes x 20 bags	18.0	0	1
file_server	2	Chang	24 - 12 oz bottles	19.0	0	1
file_server	3	Aniseed Syrup	12 - 550 ml bottles	10.0	0	2
file_server	4	Chef Anton's Cajun Seasoning	48 - 6 oz jars	22.0	0	2
file_server	5	Chef Anton's Gumbo Mix	36 boxes	21.35	1	2
file_server	6	Grandma's Boysenberry Spread	12 - 8 oz jars	25.0	0	2
file_server	7	Uncle Bob's Organic Dried Pears	12 - 1 lb pkgs.	30.0	0	7
file_server	8	Northwoods Cranberry Sauce	12 - 12 oz jars	40.0	0	2
file_server	9	Mishi Kobe Niku	18 - 500 g pkgs.	97.0	1	6
file_server	10	Ikura	12 - 200 ml jars	31.0	0	8
file_server	11	Queso Cabrales	1 kg pkg.	21.0	0	4
file_server	12	Queso Manchego La Pastora	10 - 500 g pkgs.	38.0	0	4
file_server	13	Konbu	2 kg box	6.0	0	8
file_server	14	Tofu	40 - 100 g pkgs.	23.25	0	7
file_server	15	Genen Shouyu	24 - 250 ml bottles	15.5	0	2
file_server	16	Pavlova	32 - 500 g boxes	17.45	0	3
file_server	17	Alice Mutton	20 - 1 kg tins	39.0	1	6
file_server	18	Carnarvon Tigers	16 kg pkg.	62.5	0	8
file_server	19	Teatime Chocolate Biscuits	10 boxes x 12 pieces	9.2	0	3
file_server	20	Sir Rodney's Marmalade	30 gift boxes	81.0	0	3
file_server	21	Sir Rodney's Scones	24 pkgs. x 4 pieces	10.0	0	3
file_server	22	Gustaf's Knackebröd	24 - 500 g pkgs.	21.0	0	5
file_server	23	Tunnbröd	12 - 250 g pkgs.	9.0	0	5
file_server	24	Guarana Fantastica	12 - 355 ml cans	4.5	1	1
file_server	25	NuNuCa Nuß-Nougat-Creme	20 - 450 g glasses	14.0	0	3
file_server	26	Gumbär Gummibärchen	100 - 250 g bags	31.23	0	3
file_server	27	Schoggi Schokolade	100 - 100 g pieces	43.9	0	3
file_server	28	Rössle Sauerkraut	25 - 825 g cans	45.6	1	7
file_server	29	Thüringer Rostbratwurst	50 bags x 30 sausgs.	123.79	1	6
file_server	30	Nord-Ost Matjeshering	10 - 200 g glasses	25.89	0	8
file_server	31	Gorgonzola Telino	12 - 100 g pkgs	12.5	0	4
file_server	32	Mascarpone Fabioli	24 - 200 g pkgs.	32.0	0	4
file_server	33	Geitost	500 g	2.5	0	4
file_server	34	Sasquatch Ale	24 - 12 oz bottles	14.0	0	1
file_server	35	Steeleye Stout	24 - 12 oz bottles	18.0	0	1
file_server	36	Inlagd Sill	24 - 250 g  jars	19.0	0	8
file_server	37	Gravad lax	12 - 500 g pkgs.	26.0	0	8
file_server	38	Côte de Blaye	12 - 75 cl bottles	263.5	0	1
file_server	39	Chartreuse verte	750 cc per bottle	18.0	0	1
file_server	40	Boston Crab Meat	24 - 4 oz tins	18.4	0	8
file_server	41	Jack's New England Clam Chowder	12 - 12 oz cans	9.65	0	8
file_server	42	Singaporean Hokkien Fried Mee	32 - 1 kg pkgs.	14.0	1	5
file_server	43	Ipoh Coffee	16 - 500 g tins	46.0	0	1
file_server	44	Gula Malacca	20 - 2 kg bags	19.45	0	2
file_server	45	Rogede sild	1k pkg.	9.5	0	8
file_server	46	Spegesild	4 - 450 g glasses	12.0	0	8
file_server	47	Zaanse koeken	10 - 4 oz boxes	9.5	0	3
file_server	48	Chocolade	10 pkgs.	12.75	0	3
file_server	49	Maxilaku	24 - 50 g pkgs.	20.0	0	3
file_server	50	Valkoinen suklaa	12 - 100 g bars	16.25	0	3
file_server	51	Manjimup Dried Apples	50 - 300 g pkgs.	53.0	0	7
file_server	52	Filo Mix	16 - 2 kg boxes	7.0	0	5
file_server	53	Perth Pasties	48 pieces	32.8	1	6
file_server	54	Tourtière	16 pies	7.45	0	6
file_server	55	Pâté chinois	24 boxes x 2 pies	24.0	0	6
file_server	56	Gnocchi di nonna Alice	24 - 250 g pkgs.	38.0	0	5
file_server	57	Ravioli Angelo	24 - 250 g pkgs.	19.5	0	5
file_server	58	Escargots de Bourgogne	24 pieces	13.25	0	8
file_server	59	Raclette Courdavault	5 kg pkg.	55.0	0	4
file_server	60	Camembert Pierrot	15 - 300 g rounds	34.0	0	4
file_server	61	Sirop d'érable	24 - 500 ml bottles	28.5	0	2
file_server	62	Tarte au sucre	48 pies	49.3	0	3
file_server	63	Vegie-spread	15 - 625 g jars	43.9	0	2
file_server	64	Wimmers gute Semmelknödel	20 bags x 4 pieces	33.25	0	5
file_server	65	Louisiana Fiery Hot Pepper Sauce	32 - 8 oz bottles	21.05	0	2
file_server	66	Louisiana Hot Spiced Okra	24 - 8 oz jars	17.0	0	2
file_server	67	Laughing Lumberjack Lager	24 - 12 oz bottles	14.0	0	1
file_server	68	Scottish Longbreads	10 boxes x 8 pieces	12.5	0	3
file_server	69	Gudbrandsdalsost	10 kg pkg.	36.0	0	4
file_server	70	Outback Lager	24 - 355 ml bottles	15.0	0	1
file_server	71	Flotemysost	10 - 500 g pkgs.	21.5	0	4
file_server	72	Mozzarella di Giovanni	24 - 200 g pkgs.	34.8	0	4
file_server	73	Röd Kaviar	24 - 150 g jars	15.0	0	8
file_server	74	Longlife Tofu	5 kg pkg.	10.0	0	7
file_server	75	Rhönbräu Klosterbier	24 - 0.5 l bottles	7.75	0	1
file_server	76	Lakkaliköri	500 ml	18.0	0	1
file_server	77	Original Frankfurter Grüne Soße	12 boxes	13.0	0	2
\.


--
-- Data for Name: structured_file_server_shippers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_file_server_shippers (permission_scope_key, shipperid, companyname) FROM stdin;
file_server	1	Speedy Express
file_server	2	United Package
file_server	3	Federal Shipping
\.


--
-- Data for Name: structured_finance_company_expense_sheet1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_finance_company_expense_sheet1 (permission_scope_key, transaction_id, date, account, type, category, description_merchant, amount, payment_method, is_recurring) FROM stdin;
finance	50000	2017-01-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110248	2017-01-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.38	Bank Transfer	No
finance	110249	2017-01-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.61	Bank Transfer	No
finance	110251	2017-01-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.34	Bank Transfer	No
finance	110250	2017-01-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.83	Bank Transfer	No
finance	50002	2017-01-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110252	2017-01-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-51.3	Bank Transfer	No
finance	110253	2017-01-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.17	Bank Transfer	No
finance	110254	2017-01-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.98	Bank Transfer	No
finance	50003	2017-01-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110255	2017-01-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-148.33	Bank Transfer	No
finance	50001	2017-01-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110256	2017-01-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.97	Bank Transfer	No
finance	110257	2017-01-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-81.91	Bank Transfer	No
finance	50004	2017-02-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110258	2017-02-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-140.51	Bank Transfer	No
finance	50007	2017-02-03	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110259	2017-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.25	Bank Transfer	No
finance	110260	2017-02-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.09	Bank Transfer	No
finance	110261	2017-02-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.05	Bank Transfer	No
finance	50006	2017-02-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110262	2017-02-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.29	Bank Transfer	No
finance	110263	2017-02-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-146.06	Bank Transfer	No
finance	110264	2017-02-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.67	Bank Transfer	No
finance	110265	2017-02-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.28	Bank Transfer	No
finance	110266	2017-02-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.73	Bank Transfer	No
finance	50005	2017-02-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50008	2017-03-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110267	2017-03-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-208.58	Bank Transfer	No
finance	50011	2017-03-05	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110268	2017-03-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-66.29	Bank Transfer	No
finance	110269	2017-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.56	Bank Transfer	No
finance	110271	2017-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.54	Bank Transfer	No
finance	110270	2017-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-136.54	Bank Transfer	No
finance	50010	2017-03-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110272	2017-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-98.03	Bank Transfer	No
finance	110273	2017-03-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.07	Bank Transfer	No
finance	110274	2017-03-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.01	Bank Transfer	No
finance	110275	2017-03-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.93	Bank Transfer	No
finance	50009	2017-03-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110276	2017-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.84	Bank Transfer	No
finance	110277	2017-03-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-125.77	Bank Transfer	No
finance	50012	2017-04-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50015	2017-04-07	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110278	2017-04-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-92.69	Bank Transfer	No
finance	110279	2017-04-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.83	Bank Transfer	No
finance	50014	2017-04-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110280	2017-04-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.98	Bank Transfer	No
finance	110281	2017-04-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.94	Bank Transfer	No
finance	110282	2017-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.69	Bank Transfer	No
finance	110283	2017-04-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-84.81	Bank Transfer	No
finance	110284	2017-04-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.56	Bank Transfer	No
finance	110285	2017-04-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.83	Bank Transfer	No
finance	50013	2017-04-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110286	2017-04-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-229.24	Bank Transfer	No
finance	50016	2017-05-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110287	2017-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.76	Bank Transfer	No
finance	110288	2017-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.45	Bank Transfer	No
finance	50018	2017-05-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110289	2017-05-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.77	Bank Transfer	No
finance	110290	2017-05-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-79.7	Bank Transfer	No
finance	110291	2017-05-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.4	Bank Transfer	No
finance	50019	2017-05-15	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110292	2017-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.35	Bank Transfer	No
finance	110293	2017-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.18	Bank Transfer	No
finance	110294	2017-05-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-147.26	Bank Transfer	No
finance	50017	2017-05-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110295	2017-05-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.15	Bank Transfer	No
finance	110296	2017-05-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.12	Bank Transfer	No
finance	50020	2017-06-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110297	2017-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.74	Bank Transfer	No
finance	110298	2017-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-168.22	Bank Transfer	No
finance	110299	2017-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.76	Bank Transfer	No
finance	50022	2017-06-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110301	2017-06-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.08	Bank Transfer	No
finance	110300	2017-06-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.68	Bank Transfer	No
finance	110302	2017-06-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.27	Bank Transfer	No
finance	110303	2017-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-107.83	Bank Transfer	No
finance	50023	2017-06-21	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110304	2017-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-63.79	Bank Transfer	No
finance	110305	2017-06-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-257.62	Bank Transfer	No
finance	50021	2017-06-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50024	2017-07-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110306	2017-07-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.56	Bank Transfer	No
finance	110307	2017-07-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.56	Bank Transfer	No
finance	110308	2017-07-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.61	Bank Transfer	No
finance	50027	2017-07-09	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110309	2017-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.3	Bank Transfer	No
finance	50026	2017-07-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110311	2017-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.69	Bank Transfer	No
finance	110310	2017-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.52	Bank Transfer	No
finance	110312	2017-07-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-40.26	Bank Transfer	No
finance	110313	2017-07-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.96	Bank Transfer	No
finance	110314	2017-07-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.16	Bank Transfer	No
finance	110315	2017-07-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.76	Bank Transfer	No
finance	50025	2017-07-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110316	2017-07-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-150.15	Bank Transfer	No
finance	50028	2017-08-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50031	2017-08-02	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110317	2017-08-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.69	Bank Transfer	No
finance	110318	2017-08-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.73	Bank Transfer	No
finance	110319	2017-08-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.5	Bank Transfer	No
finance	50030	2017-08-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110321	2017-08-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.43	Bank Transfer	No
finance	110320	2017-08-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.57	Bank Transfer	No
finance	110322	2017-08-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.4	Bank Transfer	No
finance	110323	2017-08-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.88	Bank Transfer	No
finance	110324	2017-08-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-214.27	Bank Transfer	No
finance	110325	2017-08-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.86	Bank Transfer	No
finance	50029	2017-08-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110326	2017-08-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-77.92	Bank Transfer	No
finance	50032	2017-09-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110327	2017-09-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-63.36	Bank Transfer	No
finance	110328	2017-09-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-87.03	Bank Transfer	No
finance	50034	2017-09-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110329	2017-09-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-191.67	Bank Transfer	No
finance	50035	2017-09-12	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110330	2017-09-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.75	Bank Transfer	No
finance	110331	2017-09-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.19	Bank Transfer	No
finance	110332	2017-09-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-52.84	Bank Transfer	No
finance	110333	2017-09-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.59	Bank Transfer	No
finance	110334	2017-09-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.56	Bank Transfer	No
finance	50033	2017-09-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110335	2017-09-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-42.11	Bank Transfer	No
finance	50036	2017-10-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110336	2017-10-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.51	Bank Transfer	No
finance	110337	2017-10-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-108.26	Bank Transfer	No
finance	50039	2017-10-04	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110338	2017-10-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-84.21	Bank Transfer	No
finance	50038	2017-10-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110339	2017-10-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.66	Bank Transfer	No
finance	110341	2017-10-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.78	Bank Transfer	No
finance	110340	2017-10-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-166.31	Bank Transfer	No
finance	110342	2017-10-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-54.83	Bank Transfer	No
finance	110343	2017-10-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-110.37	Bank Transfer	No
finance	110344	2017-10-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.29	Bank Transfer	No
finance	50037	2017-10-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110345	2017-10-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-249.06	Bank Transfer	No
finance	50040	2017-11-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110346	2017-11-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-142.08	Bank Transfer	No
finance	110347	2017-11-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.1	Bank Transfer	No
finance	110348	2017-11-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.78	Bank Transfer	No
finance	50043	2017-11-09	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110349	2017-11-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.63	Bank Transfer	No
finance	50042	2017-11-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110350	2017-11-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.19	Bank Transfer	No
finance	110351	2017-11-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-162.33	Bank Transfer	No
finance	110352	2017-11-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.3	Bank Transfer	No
finance	110353	2017-11-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-360.63	Bank Transfer	No
finance	110354	2017-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.8	Bank Transfer	No
finance	110355	2017-11-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.95	Bank Transfer	No
finance	50041	2017-11-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50044	2017-12-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50047	2017-12-03	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110356	2017-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.71	Bank Transfer	No
finance	110357	2017-12-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.88	Bank Transfer	No
finance	110358	2017-12-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.64	Bank Transfer	No
finance	50046	2017-12-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110359	2017-12-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-288.43	Bank Transfer	No
finance	110360	2017-12-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-131.7	Bank Transfer	No
finance	110361	2017-12-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-183.17	Bank Transfer	No
finance	110362	2017-12-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.04	Bank Transfer	No
finance	110363	2017-12-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.54	Bank Transfer	No
finance	110364	2017-12-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-71.97	Bank Transfer	No
finance	110365	2017-12-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22	Bank Transfer	No
finance	50045	2017-12-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110366	2017-12-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.14	Bank Transfer	No
finance	110367	2017-12-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.55	Bank Transfer	No
finance	110368	2017-12-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-101.95	Bank Transfer	No
finance	50048	2018-01-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110369	2018-01-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-195.68	Bank Transfer	No
finance	50051	2018-01-08	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110370	2018-01-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.17	Bank Transfer	No
finance	110371	2018-01-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.45	Bank Transfer	No
finance	50050	2018-01-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110372	2018-01-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-890.78	Bank Transfer	No
finance	110374	2018-01-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.94	Bank Transfer	No
finance	110373	2018-01-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-124.12	Bank Transfer	No
finance	110375	2018-01-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.12	Bank Transfer	No
finance	110377	2018-01-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.21	Bank Transfer	No
finance	110376	2018-01-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.39	Bank Transfer	No
finance	110378	2018-01-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.44	Bank Transfer	No
finance	50049	2018-01-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110379	2018-01-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.03	Bank Transfer	No
finance	50052	2018-02-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110380	2018-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-35.03	Bank Transfer	No
finance	110381	2018-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.99	Bank Transfer	No
finance	110382	2018-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-94.77	Bank Transfer	No
finance	50054	2018-02-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110383	2018-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.24	Bank Transfer	No
finance	110384	2018-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-168.64	Bank Transfer	No
finance	110385	2018-02-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.96	Bank Transfer	No
finance	110386	2018-02-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.99	Bank Transfer	No
finance	110387	2018-02-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-93.63	Bank Transfer	No
finance	110388	2018-02-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.86	Bank Transfer	No
finance	50055	2018-02-19	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110389	2018-02-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.42	Bank Transfer	No
finance	50053	2018-02-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110390	2018-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-126.38	Bank Transfer	No
finance	110391	2018-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.45	Bank Transfer	No
finance	50056	2018-03-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110392	2018-03-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-122.46	Bank Transfer	No
finance	110394	2018-03-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.34	Bank Transfer	No
finance	110393	2018-03-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-126.56	Bank Transfer	No
finance	110395	2018-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-184.41	Bank Transfer	No
finance	110397	2018-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-60.26	Bank Transfer	No
finance	110396	2018-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-135.35	Bank Transfer	No
finance	50058	2018-03-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	50059	2018-03-14	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110398	2018-03-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-89.16	Bank Transfer	No
finance	110399	2018-03-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.36	Bank Transfer	No
finance	110400	2018-03-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-83.93	Bank Transfer	No
finance	110401	2018-03-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.51	Bank Transfer	No
finance	110402	2018-03-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-67.88	Bank Transfer	No
finance	110403	2018-03-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.79	Bank Transfer	No
finance	110404	2018-03-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-155.97	Bank Transfer	No
finance	50057	2018-03-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50060	2018-04-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110405	2018-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.82	Bank Transfer	No
finance	110407	2018-04-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-91.48	Bank Transfer	No
finance	110406	2018-04-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-108.04	Bank Transfer	No
finance	50063	2018-04-08	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110408	2018-04-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.26	Bank Transfer	No
finance	50062	2018-04-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110409	2018-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.83	Bank Transfer	No
finance	110410	2018-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.4	Bank Transfer	No
finance	110411	2018-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.65	Bank Transfer	No
finance	110412	2018-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.77	Bank Transfer	No
finance	110414	2018-04-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.48	Bank Transfer	No
finance	110413	2018-04-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-95.66	Bank Transfer	No
finance	110415	2018-04-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.2	Bank Transfer	No
finance	50061	2018-04-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110417	2018-04-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-70.29	Bank Transfer	No
finance	110416	2018-04-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.72	Bank Transfer	No
finance	50064	2018-05-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110418	2018-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.55	Bank Transfer	No
finance	50067	2018-05-08	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110419	2018-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-137.35	Bank Transfer	No
finance	50066	2018-05-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110421	2018-05-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-99.23	Bank Transfer	No
finance	110420	2018-05-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.12	Bank Transfer	No
finance	110422	2018-05-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.02	Bank Transfer	No
finance	110424	2018-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-370.61	Bank Transfer	No
finance	110423	2018-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.5	Bank Transfer	No
finance	110425	2018-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.93	Bank Transfer	No
finance	110426	2018-05-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.69	Bank Transfer	No
finance	110427	2018-05-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.29	Bank Transfer	No
finance	50065	2018-05-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110428	2018-05-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.09	Bank Transfer	No
finance	110429	2018-05-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-56.63	Bank Transfer	No
finance	50068	2018-06-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110431	2018-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.17	Bank Transfer	No
finance	110430	2018-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-458.78	Bank Transfer	No
finance	110432	2018-06-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.34	Bank Transfer	No
finance	50070	2018-06-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110434	2018-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.92	Bank Transfer	No
finance	110433	2018-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.83	Bank Transfer	No
finance	110435	2018-06-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.21	Bank Transfer	No
finance	110436	2018-06-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-156.66	Bank Transfer	No
finance	110437	2018-06-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.97	Bank Transfer	No
finance	110438	2018-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.24	Bank Transfer	No
finance	50071	2018-06-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110439	2018-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.07	Bank Transfer	No
finance	50069	2018-06-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110440	2018-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-86.53	Bank Transfer	No
finance	110441	2018-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.02	Bank Transfer	No
finance	50072	2018-07-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110442	2018-07-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.94	Bank Transfer	No
finance	50075	2018-07-03	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110444	2018-07-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.5	Bank Transfer	No
finance	110443	2018-07-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.95	Bank Transfer	No
finance	110445	2018-07-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.3	Bank Transfer	No
finance	110446	2018-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.68	Bank Transfer	No
finance	110447	2018-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-68.66	Bank Transfer	No
finance	50074	2018-07-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110448	2018-07-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.82	Bank Transfer	No
finance	110449	2018-07-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.3	Bank Transfer	No
finance	110450	2018-07-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.23	Bank Transfer	No
finance	110451	2018-07-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-189.09	Bank Transfer	No
finance	110452	2018-07-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-140.26	Bank Transfer	No
finance	110453	2018-07-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.36	Bank Transfer	No
finance	110454	2018-07-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.74	Bank Transfer	No
finance	50073	2018-07-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50076	2018-08-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110455	2018-08-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-180.45	Bank Transfer	No
finance	110457	2018-08-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.57	Bank Transfer	No
finance	110456	2018-08-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.12	Bank Transfer	No
finance	50079	2018-08-06	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110458	2018-08-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-147.06	Bank Transfer	No
finance	110459	2018-08-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.09	Bank Transfer	No
finance	50078	2018-08-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110460	2018-08-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.27	Bank Transfer	No
finance	110461	2018-08-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-148.61	Bank Transfer	No
finance	110462	2018-08-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.17	Bank Transfer	No
finance	110464	2018-08-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-89	Bank Transfer	No
finance	110463	2018-08-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.78	Bank Transfer	No
finance	110465	2018-08-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-145.04	Bank Transfer	No
finance	110467	2018-08-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.93	Bank Transfer	No
finance	110466	2018-08-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.93	Bank Transfer	No
finance	50077	2018-08-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110468	2018-08-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.12	Bank Transfer	No
finance	50080	2018-09-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50083	2018-09-03	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110469	2018-09-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-60.18	Bank Transfer	No
finance	110471	2018-09-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.59	Bank Transfer	No
finance	110470	2018-09-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.56	Bank Transfer	No
finance	50082	2018-09-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110472	2018-09-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.2	Bank Transfer	No
finance	110473	2018-09-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.37	Bank Transfer	No
finance	110474	2018-09-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-83.49	Bank Transfer	No
finance	110475	2018-09-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-68.52	Bank Transfer	No
finance	110476	2018-09-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.41	Bank Transfer	No
finance	110477	2018-09-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.02	Bank Transfer	No
finance	110478	2018-09-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.81	Bank Transfer	No
finance	50081	2018-09-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110479	2018-09-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-708.95	Bank Transfer	No
finance	50084	2018-10-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110481	2018-10-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.33	Bank Transfer	No
finance	110480	2018-10-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.35	Bank Transfer	No
finance	110482	2018-10-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.48	Bank Transfer	No
finance	110484	2018-10-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.88	Bank Transfer	No
finance	110483	2018-10-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.28	Bank Transfer	No
finance	50086	2018-10-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110485	2018-10-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-64.45	Bank Transfer	No
finance	110486	2018-10-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.53	Bank Transfer	No
finance	110487	2018-10-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-71.07	Bank Transfer	No
finance	50087	2018-10-16	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110488	2018-10-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.93	Bank Transfer	No
finance	110489	2018-10-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.29	Bank Transfer	No
finance	50085	2018-10-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110491	2018-10-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.96	Bank Transfer	No
finance	110490	2018-10-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-210.19	Bank Transfer	No
finance	110492	2018-10-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.89	Bank Transfer	No
finance	50088	2018-11-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110494	2018-11-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.99	Bank Transfer	No
finance	110493	2018-11-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.64	Bank Transfer	No
finance	110495	2018-11-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.65	Bank Transfer	No
finance	110496	2018-11-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-46.77	Bank Transfer	No
finance	110497	2018-11-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.21	Bank Transfer	No
finance	50091	2018-11-07	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	50090	2018-11-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110498	2018-11-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.75	Bank Transfer	No
finance	110499	2018-11-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-102.02	Bank Transfer	No
finance	110501	2018-11-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.85	Bank Transfer	No
finance	110500	2018-11-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-42.68	Bank Transfer	No
finance	110502	2018-11-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-69.32	Bank Transfer	No
finance	110504	2018-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.13	Bank Transfer	No
finance	110503	2018-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.74	Bank Transfer	No
finance	50089	2018-11-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50092	2018-12-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110505	2018-12-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.13	Bank Transfer	No
finance	110507	2018-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.45	Bank Transfer	No
finance	110506	2018-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.19	Bank Transfer	No
finance	110508	2018-12-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.99	Bank Transfer	No
finance	110509	2018-12-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.15	Bank Transfer	No
finance	50094	2018-12-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110511	2018-12-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-350.64	Bank Transfer	No
finance	110510	2018-12-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-367.63	Bank Transfer	No
finance	50095	2018-12-15	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110512	2018-12-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.53	Bank Transfer	No
finance	110514	2018-12-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-789.95	Bank Transfer	No
finance	110513	2018-12-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-105.65	Bank Transfer	No
finance	110515	2018-12-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-204.47	Bank Transfer	No
finance	110516	2018-12-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.78	Bank Transfer	No
finance	110517	2018-12-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.07	Bank Transfer	No
finance	50093	2018-12-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110518	2018-12-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-218.15	Bank Transfer	No
finance	50096	2019-01-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110519	2019-01-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-91.76	Bank Transfer	No
finance	110520	2019-01-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.37	Bank Transfer	No
finance	110521	2019-01-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.22	Bank Transfer	No
finance	50099	2019-01-08	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110522	2019-01-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.33	Bank Transfer	No
finance	50098	2019-01-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110523	2019-01-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-77.63	Bank Transfer	No
finance	110524	2019-01-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-244.79	Bank Transfer	No
finance	110525	2019-01-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.06	Bank Transfer	No
finance	110526	2019-01-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.59	Bank Transfer	No
finance	110527	2019-01-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.9	Bank Transfer	No
finance	110528	2019-01-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.35	Bank Transfer	No
finance	110529	2019-01-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-66.69	Bank Transfer	No
finance	50097	2019-01-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110530	2019-01-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-339.22	Bank Transfer	No
finance	110531	2019-01-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.12	Bank Transfer	No
finance	50100	2019-02-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110532	2019-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.46	Bank Transfer	No
finance	110534	2019-02-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.94	Bank Transfer	No
finance	110533	2019-02-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-188.04	Bank Transfer	No
finance	50102	2019-02-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110535	2019-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.64	Bank Transfer	No
finance	110537	2019-02-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-78.85	Bank Transfer	No
finance	110536	2019-02-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.88	Bank Transfer	No
finance	50103	2019-02-15	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110538	2019-02-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.87	Bank Transfer	No
finance	110539	2019-02-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.36	Bank Transfer	No
finance	110540	2019-02-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1007.64	Bank Transfer	No
finance	110541	2019-02-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-68.65	Bank Transfer	No
finance	50101	2019-02-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110542	2019-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.95	Bank Transfer	No
finance	50104	2019-03-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110544	2019-03-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.91	Bank Transfer	No
finance	110543	2019-03-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.17	Bank Transfer	No
finance	110545	2019-03-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.92	Bank Transfer	No
finance	110547	2019-03-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-178.43	Bank Transfer	No
finance	110546	2019-03-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-194.72	Bank Transfer	No
finance	50106	2019-03-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110548	2019-03-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.43	Bank Transfer	No
finance	50107	2019-03-17	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110549	2019-03-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-171.24	Bank Transfer	No
finance	110551	2019-03-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-72.95	Bank Transfer	No
finance	110550	2019-03-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.32	Bank Transfer	No
finance	110552	2019-03-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-83.22	Bank Transfer	No
finance	110554	2019-03-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-120.97	Bank Transfer	No
finance	110553	2019-03-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-149.49	Bank Transfer	No
finance	50105	2019-03-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50108	2019-04-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110555	2019-04-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-252.49	Bank Transfer	No
finance	110557	2019-04-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.72	Bank Transfer	No
finance	110556	2019-04-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.8	Bank Transfer	No
finance	50111	2019-04-06	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110558	2019-04-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-72.97	Bank Transfer	No
finance	110559	2019-04-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.05	Bank Transfer	No
finance	50110	2019-04-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110560	2019-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.65	Bank Transfer	No
finance	110561	2019-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-242.21	Bank Transfer	No
finance	110562	2019-04-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.95	Bank Transfer	No
finance	110563	2019-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-60.43	Bank Transfer	No
finance	110564	2019-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.75	Bank Transfer	No
finance	110565	2019-04-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.15	Bank Transfer	No
finance	110567	2019-04-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.97	Bank Transfer	No
finance	110566	2019-04-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-88.4	Bank Transfer	No
finance	50109	2019-04-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110568	2019-04-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.54	Bank Transfer	No
finance	50112	2019-05-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110569	2019-05-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.98	Bank Transfer	No
finance	110571	2019-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.06	Bank Transfer	No
finance	110570	2019-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-188.99	Bank Transfer	No
finance	110572	2019-05-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-116.43	Bank Transfer	No
finance	50114	2019-05-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110574	2019-05-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-37.6	Bank Transfer	No
finance	110573	2019-05-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-84.84	Bank Transfer	No
finance	110575	2019-05-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-127.34	Bank Transfer	No
finance	50115	2019-05-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110577	2019-05-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.41	Bank Transfer	No
finance	110576	2019-05-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.56	Bank Transfer	No
finance	110578	2019-05-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.6	Bank Transfer	No
finance	50113	2019-05-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110579	2019-05-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.73	Bank Transfer	No
finance	110581	2019-05-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.01	Bank Transfer	No
finance	110580	2019-05-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-75.89	Bank Transfer	No
finance	50116	2019-06-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110582	2019-06-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.71	Bank Transfer	No
finance	50119	2019-06-03	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110583	2019-06-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.28	Bank Transfer	No
finance	110584	2019-06-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.14	Bank Transfer	No
finance	50118	2019-06-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110585	2019-06-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.41	Bank Transfer	No
finance	110586	2019-06-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.48	Bank Transfer	No
finance	110587	2019-06-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.52	Bank Transfer	No
finance	110588	2019-06-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-194.67	Bank Transfer	No
finance	110589	2019-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.42	Bank Transfer	No
finance	110590	2019-06-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.77	Bank Transfer	No
finance	110591	2019-06-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.92	Bank Transfer	No
finance	50117	2019-06-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110592	2019-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.1	Bank Transfer	No
finance	50120	2019-07-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110593	2019-07-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-174.2	Bank Transfer	No
finance	110594	2019-07-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.24	Bank Transfer	No
finance	110595	2019-07-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.78	Bank Transfer	No
finance	110597	2019-07-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-35.12	Bank Transfer	No
finance	110596	2019-07-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.34	Bank Transfer	No
finance	50122	2019-07-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110598	2019-07-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.42	Bank Transfer	No
finance	50123	2019-07-15	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110599	2019-07-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.98	Bank Transfer	No
finance	110600	2019-07-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.13	Bank Transfer	No
finance	110601	2019-07-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.3	Bank Transfer	No
finance	110602	2019-07-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.92	Bank Transfer	No
finance	110603	2019-07-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.77	Bank Transfer	No
finance	110604	2019-07-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.46	Bank Transfer	No
finance	50121	2019-07-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110605	2019-07-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-379.13	Bank Transfer	No
finance	50124	2019-08-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110606	2019-08-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-79.4	Bank Transfer	No
finance	110607	2019-08-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-200.24	Bank Transfer	No
finance	110608	2019-08-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.79	Bank Transfer	No
finance	110609	2019-08-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.85	Bank Transfer	No
finance	110610	2019-08-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.78	Bank Transfer	No
finance	110611	2019-08-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-80.65	Bank Transfer	No
finance	50127	2019-08-11	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	50126	2019-08-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110612	2019-08-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-544.08	Bank Transfer	No
finance	110613	2019-08-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.11	Bank Transfer	No
finance	110614	2019-08-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.93	Bank Transfer	No
finance	110615	2019-08-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.75	Bank Transfer	No
finance	110617	2019-08-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.53	Bank Transfer	No
finance	110616	2019-08-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-116.53	Bank Transfer	No
finance	110618	2019-08-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-154.68	Bank Transfer	No
finance	50125	2019-08-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50128	2019-09-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110619	2019-09-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-91.05	Bank Transfer	No
finance	110620	2019-09-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.94	Bank Transfer	No
finance	110621	2019-09-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.73	Bank Transfer	No
finance	110622	2019-09-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-50.97	Bank Transfer	No
finance	110623	2019-09-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-97.18	Bank Transfer	No
finance	110624	2019-09-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-94.8	Bank Transfer	No
finance	50130	2019-09-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110625	2019-09-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-43.9	Bank Transfer	No
finance	50131	2019-09-19	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110626	2019-09-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-138.69	Bank Transfer	No
finance	110627	2019-09-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-107.46	Bank Transfer	No
finance	110628	2019-09-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.36	Bank Transfer	No
finance	110629	2019-09-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-85.46	Bank Transfer	No
finance	110630	2019-09-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.35	Bank Transfer	No
finance	50129	2019-09-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110631	2019-09-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.87	Bank Transfer	No
finance	110632	2019-09-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.38	Bank Transfer	No
finance	110634	2019-09-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-487.38	Bank Transfer	No
finance	110633	2019-09-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-477.9	Bank Transfer	No
finance	50132	2019-10-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110635	2019-10-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.46	Bank Transfer	No
finance	110636	2019-10-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.15	Bank Transfer	No
finance	110637	2019-10-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-201.29	Bank Transfer	No
finance	50134	2019-10-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110638	2019-10-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-158.44	Bank Transfer	No
finance	110639	2019-10-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.64	Bank Transfer	No
finance	110640	2019-10-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.55	Bank Transfer	No
finance	110641	2019-10-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-179.61	Bank Transfer	No
finance	110642	2019-10-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-41.89	Bank Transfer	No
finance	50135	2019-10-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110643	2019-10-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.46	Bank Transfer	No
finance	110644	2019-10-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.14	Bank Transfer	No
finance	110645	2019-10-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.41	Bank Transfer	No
finance	50133	2019-10-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110646	2019-10-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-142.33	Bank Transfer	No
finance	110647	2019-10-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.54	Bank Transfer	No
finance	50136	2019-11-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110648	2019-11-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.25	Bank Transfer	No
finance	110649	2019-11-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.2	Bank Transfer	No
finance	110650	2019-11-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-176.81	Bank Transfer	No
finance	50138	2019-11-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110651	2019-11-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.6	Bank Transfer	No
finance	110652	2019-11-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.14	Bank Transfer	No
finance	110654	2019-11-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.26	Bank Transfer	No
finance	110653	2019-11-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-93.25	Bank Transfer	No
finance	50139	2019-11-16	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110655	2019-11-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.41	Bank Transfer	No
finance	110657	2019-11-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-352.69	Bank Transfer	No
finance	110656	2019-11-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-57.15	Bank Transfer	No
finance	110658	2019-11-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-364.15	Bank Transfer	No
finance	110659	2019-11-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-105.81	Bank Transfer	No
finance	50137	2019-11-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110660	2019-11-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-111.29	Bank Transfer	No
finance	50140	2019-12-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110661	2019-12-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.55	Bank Transfer	No
finance	110662	2019-12-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.28	Bank Transfer	No
finance	110663	2019-12-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-113.15	Bank Transfer	No
finance	110664	2019-12-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.27	Bank Transfer	No
finance	110665	2019-12-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.31	Bank Transfer	No
finance	110666	2019-12-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-232.42	Bank Transfer	No
finance	110667	2019-12-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-78.09	Bank Transfer	No
finance	50142	2019-12-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110669	2019-12-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.39	Bank Transfer	No
finance	110668	2019-12-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.22	Bank Transfer	No
finance	110670	2019-12-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-203.48	Bank Transfer	No
finance	50143	2019-12-19	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110672	2019-12-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-95.75	Bank Transfer	No
finance	110671	2019-12-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.34	Bank Transfer	No
finance	110674	2019-12-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.9	Bank Transfer	No
finance	110673	2019-12-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.76	Bank Transfer	No
finance	110675	2019-12-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.85	Bank Transfer	No
finance	50141	2019-12-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50144	2020-01-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110676	2020-01-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.01	Bank Transfer	No
finance	110677	2020-01-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.03	Bank Transfer	No
finance	50147	2020-01-04	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110678	2020-01-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-388.98	Bank Transfer	No
finance	110679	2020-01-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.94	Bank Transfer	No
finance	110680	2020-01-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.61	Bank Transfer	No
finance	110682	2020-01-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.13	Bank Transfer	No
finance	110681	2020-01-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.13	Bank Transfer	No
finance	50146	2020-01-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110683	2020-01-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.4	Bank Transfer	No
finance	110684	2020-01-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-145.63	Bank Transfer	No
finance	110685	2020-01-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.75	Bank Transfer	No
finance	110687	2020-01-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-296.43	Bank Transfer	No
finance	110686	2020-01-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.5	Bank Transfer	No
finance	110689	2020-01-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.42	Bank Transfer	No
finance	110688	2020-01-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-299.09	Bank Transfer	No
finance	110690	2020-01-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.8	Bank Transfer	No
finance	50145	2020-01-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110692	2020-01-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-61.02	Bank Transfer	No
finance	110691	2020-01-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-810.05	Bank Transfer	No
finance	50148	2020-02-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110694	2020-02-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-398.36	Bank Transfer	No
finance	110693	2020-02-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-139.34	Bank Transfer	No
finance	110695	2020-02-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.72	Bank Transfer	No
finance	110697	2020-02-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.52	Bank Transfer	No
finance	110696	2020-02-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-102.55	Bank Transfer	No
finance	50150	2020-02-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110699	2020-02-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.58	Bank Transfer	No
finance	110698	2020-02-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-272.47	Bank Transfer	No
finance	110700	2020-02-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.1	Bank Transfer	No
finance	50151	2020-02-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110702	2020-02-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.94	Bank Transfer	No
finance	110701	2020-02-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-220.31	Bank Transfer	No
finance	110703	2020-02-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-152.3	Bank Transfer	No
finance	110704	2020-02-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.78	Bank Transfer	No
finance	110705	2020-02-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.52	Bank Transfer	No
finance	50149	2020-02-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50152	2020-03-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110706	2020-03-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-135.63	Bank Transfer	No
finance	110707	2020-03-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.74	Bank Transfer	No
finance	110709	2020-03-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-210.8	Bank Transfer	No
finance	110708	2020-03-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.96	Bank Transfer	No
finance	50154	2020-03-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110710	2020-03-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.98	Bank Transfer	No
finance	50155	2020-03-12	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110712	2020-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-89.93	Bank Transfer	No
finance	110711	2020-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-52.41	Bank Transfer	No
finance	110713	2020-03-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-167.05	Bank Transfer	No
finance	110714	2020-03-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.49	Bank Transfer	No
finance	110715	2020-03-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-63.2	Bank Transfer	No
finance	110717	2020-03-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.25	Bank Transfer	No
finance	110716	2020-03-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.57	Bank Transfer	No
finance	50153	2020-03-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110718	2020-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-170.88	Bank Transfer	No
finance	110719	2020-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-51.44	Bank Transfer	No
finance	110720	2020-03-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.53	Bank Transfer	No
finance	50156	2020-04-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110721	2020-04-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.92	Bank Transfer	No
finance	110722	2020-04-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.58	Bank Transfer	No
finance	110723	2020-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.72	Bank Transfer	No
finance	110724	2020-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-57.75	Bank Transfer	No
finance	110725	2020-04-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.83	Bank Transfer	No
finance	50158	2020-04-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	50159	2020-04-13	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110726	2020-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.56	Bank Transfer	No
finance	110727	2020-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-89.9	Bank Transfer	No
finance	110729	2020-04-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-141.06	Bank Transfer	No
finance	110728	2020-04-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.33	Bank Transfer	No
finance	110730	2020-04-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.12	Bank Transfer	No
finance	110732	2020-04-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.97	Bank Transfer	No
finance	110731	2020-04-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.65	Bank Transfer	No
finance	110734	2020-04-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.63	Bank Transfer	No
finance	110733	2020-04-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-110.11	Bank Transfer	No
finance	50157	2020-04-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50160	2020-05-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110735	2020-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.97	Bank Transfer	No
finance	110736	2020-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.1	Bank Transfer	No
finance	110737	2020-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.79	Bank Transfer	No
finance	50163	2020-05-06	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110739	2020-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.08	Bank Transfer	No
finance	110738	2020-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.91	Bank Transfer	No
finance	110740	2020-05-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-81.88	Bank Transfer	No
finance	50162	2020-05-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110741	2020-05-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.96	Bank Transfer	No
finance	110742	2020-05-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-243.73	Bank Transfer	No
finance	110743	2020-05-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.72	Bank Transfer	No
finance	110744	2020-05-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-69.19	Bank Transfer	No
finance	110745	2020-05-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.52	Bank Transfer	No
finance	110747	2020-05-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-117.33	Bank Transfer	No
finance	110746	2020-05-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.43	Bank Transfer	No
finance	110749	2020-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-61.53	Bank Transfer	No
finance	110748	2020-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-232.55	Bank Transfer	No
finance	50161	2020-05-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110750	2020-05-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-79.3	Bank Transfer	No
finance	50164	2020-06-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110751	2020-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-130.79	Bank Transfer	No
finance	110752	2020-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.39	Bank Transfer	No
finance	110753	2020-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.7	Bank Transfer	No
finance	50181	2020-10-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110754	2020-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.38	Bank Transfer	No
finance	50167	2020-06-08	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110755	2020-06-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.71	Bank Transfer	No
finance	50166	2020-06-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110757	2020-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.19	Bank Transfer	No
finance	110756	2020-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.21	Bank Transfer	No
finance	110759	2020-06-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.99	Bank Transfer	No
finance	110758	2020-06-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-138.17	Bank Transfer	No
finance	110760	2020-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-155.64	Bank Transfer	No
finance	110762	2020-06-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-328.74	Bank Transfer	No
finance	110761	2020-06-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.66	Bank Transfer	No
finance	110763	2020-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-37.35	Bank Transfer	No
finance	110764	2020-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-145.45	Bank Transfer	No
finance	50165	2020-06-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110765	2020-06-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-42.74	Bank Transfer	No
finance	50168	2020-07-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110766	2020-07-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-157.55	Bank Transfer	No
finance	110767	2020-07-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.59	Bank Transfer	No
finance	50171	2020-07-04	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110768	2020-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-146.32	Bank Transfer	No
finance	110769	2020-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.06	Bank Transfer	No
finance	50170	2020-07-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110770	2020-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.32	Bank Transfer	No
finance	110772	2020-07-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-91.28	Bank Transfer	No
finance	110771	2020-07-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.19	Bank Transfer	No
finance	110774	2020-07-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.2	Bank Transfer	No
finance	110773	2020-07-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.43	Bank Transfer	No
finance	110775	2020-07-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.25	Bank Transfer	No
finance	110776	2020-07-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-351.53	Bank Transfer	No
finance	110777	2020-07-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.01	Bank Transfer	No
finance	50169	2020-07-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110778	2020-07-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.79	Bank Transfer	No
finance	110779	2020-07-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.13	Bank Transfer	No
finance	110780	2020-07-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-42.13	Bank Transfer	No
finance	50172	2020-08-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110781	2020-08-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.16	Bank Transfer	No
finance	110782	2020-08-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.1	Bank Transfer	No
finance	110783	2020-08-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-124.98	Bank Transfer	No
finance	110785	2020-08-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.51	Bank Transfer	No
finance	110784	2020-08-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-70.09	Bank Transfer	No
finance	110787	2020-08-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-249.93	Bank Transfer	No
finance	110786	2020-08-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-110.87	Bank Transfer	No
finance	50174	2020-08-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110790	2020-08-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-28.23	Bank Transfer	No
finance	110789	2020-08-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-100.6	Bank Transfer	No
finance	110788	2020-08-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-42.7	Bank Transfer	No
finance	50175	2020-08-15	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110792	2020-08-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.79	Bank Transfer	No
finance	110791	2020-08-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.85	Bank Transfer	No
finance	110795	2020-08-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-126.66	Bank Transfer	No
finance	110794	2020-08-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.49	Bank Transfer	No
finance	110793	2020-08-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.52	Bank Transfer	No
finance	110797	2020-08-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.35	Bank Transfer	No
finance	110796	2020-08-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.52	Bank Transfer	No
finance	110799	2020-08-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.76	Bank Transfer	No
finance	110798	2020-08-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.33	Bank Transfer	No
finance	110800	2020-08-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-137.44	Bank Transfer	No
finance	50173	2020-08-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110802	2020-08-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-257.26	Bank Transfer	No
finance	110801	2020-08-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-97.09	Bank Transfer	No
finance	50176	2020-09-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110805	2020-09-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-237.34	Bank Transfer	No
finance	110803	2020-09-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.23	Bank Transfer	No
finance	110804	2020-09-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.33	Bank Transfer	No
finance	50179	2020-09-04	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110807	2020-09-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.36	Bank Transfer	No
finance	110806	2020-09-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-22.11	Bank Transfer	No
finance	110810	2020-09-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.33	Bank Transfer	No
finance	110808	2020-09-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-45.53	Bank Transfer	No
finance	110809	2020-09-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.87	Bank Transfer	No
finance	110811	2020-09-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.22	Bank Transfer	No
finance	110812	2020-09-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.78	Bank Transfer	No
finance	50178	2020-09-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110813	2020-09-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.38	Bank Transfer	No
finance	110814	2020-09-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-130.94	Bank Transfer	No
finance	110815	2020-09-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.62	Bank Transfer	No
finance	110816	2020-09-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-719.78	Bank Transfer	No
finance	110817	2020-09-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-306.07	Bank Transfer	No
finance	110820	2020-09-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-37.52	Bank Transfer	No
finance	110818	2020-09-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.48	Bank Transfer	No
finance	110819	2020-09-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.76	Bank Transfer	No
finance	110822	2020-09-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7	Bank Transfer	No
finance	110821	2020-09-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.68	Bank Transfer	No
finance	110823	2020-09-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-163.97	Bank Transfer	No
finance	110824	2020-09-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.23	Bank Transfer	No
finance	110825	2020-09-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-79.25	Bank Transfer	No
finance	50177	2020-09-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50180	2020-10-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110826	2020-10-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.09	Bank Transfer	No
finance	110827	2020-10-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-63.54	Bank Transfer	No
finance	110829	2020-10-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-154.72	Bank Transfer	No
finance	110830	2020-10-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-81.83	Bank Transfer	No
finance	110828	2020-10-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-90.85	Bank Transfer	No
finance	110831	2020-10-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-72.19	Bank Transfer	No
finance	110832	2020-10-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-43.26	Bank Transfer	No
finance	50183	2020-10-10	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	50182	2020-10-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110835	2020-10-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-69.53	Bank Transfer	No
finance	110834	2020-10-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.78	Bank Transfer	No
finance	110833	2020-10-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-71.49	Bank Transfer	No
finance	110836	2020-10-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-411.88	Bank Transfer	No
finance	110837	2020-10-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.32	Bank Transfer	No
finance	110838	2020-10-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.28	Bank Transfer	No
finance	110839	2020-10-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-35.43	Bank Transfer	No
finance	110840	2020-10-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.71	Bank Transfer	No
finance	110841	2020-10-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-424.3	Bank Transfer	No
finance	110842	2020-10-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-54.42	Bank Transfer	No
finance	110843	2020-10-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.26	Bank Transfer	No
finance	110845	2020-10-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-212.98	Bank Transfer	No
finance	110844	2020-10-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.22	Bank Transfer	No
finance	110846	2020-10-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-56.46	Bank Transfer	No
finance	110847	2020-10-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-487.57	Bank Transfer	No
finance	110848	2020-10-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.24	Bank Transfer	No
finance	110849	2020-10-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.56	Bank Transfer	No
finance	110850	2020-10-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-49.19	Bank Transfer	No
finance	50184	2020-11-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110851	2020-11-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-160.55	Bank Transfer	No
finance	110852	2020-11-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-174.05	Bank Transfer	No
finance	110853	2020-11-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.83	Bank Transfer	No
finance	110854	2020-11-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-100.22	Bank Transfer	No
finance	110855	2020-11-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-170.97	Bank Transfer	No
finance	50186	2020-11-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	50187	2020-11-12	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110856	2020-11-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-58.43	Bank Transfer	No
finance	110857	2020-11-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-188.85	Bank Transfer	No
finance	110859	2020-11-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.1	Bank Transfer	No
finance	110860	2020-11-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.26	Bank Transfer	No
finance	110858	2020-11-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-52.51	Bank Transfer	No
finance	110861	2020-11-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.93	Bank Transfer	No
finance	110862	2020-11-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.23	Bank Transfer	No
finance	110865	2020-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-348.14	Bank Transfer	No
finance	110864	2020-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.04	Bank Transfer	No
finance	110863	2020-11-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.26	Bank Transfer	No
finance	110867	2020-11-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.93	Bank Transfer	No
finance	110866	2020-11-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-109.11	Bank Transfer	No
finance	50185	2020-11-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110870	2020-11-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.04	Bank Transfer	No
finance	110869	2020-11-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-143.28	Bank Transfer	No
finance	110868	2020-11-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-191.27	Bank Transfer	No
finance	50188	2020-12-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110871	2020-12-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-112.27	Bank Transfer	No
finance	110872	2020-12-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-175.32	Bank Transfer	No
finance	110873	2020-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.82	Bank Transfer	No
finance	110875	2020-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.37	Bank Transfer	No
finance	110874	2020-12-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.58	Bank Transfer	No
finance	50190	2020-12-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110877	2020-12-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.06	Bank Transfer	No
finance	110876	2020-12-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-60.42	Bank Transfer	No
finance	50191	2020-12-14	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110878	2020-12-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-46.69	Bank Transfer	No
finance	110880	2020-12-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-88.01	Bank Transfer	No
finance	110879	2020-12-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.5	Bank Transfer	No
finance	110881	2020-12-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.84	Bank Transfer	No
finance	110882	2020-12-17	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.1	Bank Transfer	No
finance	110883	2020-12-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.53	Bank Transfer	No
finance	110884	2020-12-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-90.97	Bank Transfer	No
finance	110885	2020-12-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-5.64	Bank Transfer	No
finance	110886	2020-12-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.99	Bank Transfer	No
finance	110887	2020-12-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.25	Bank Transfer	No
finance	50189	2020-12-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110890	2020-12-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.76	Bank Transfer	No
finance	110888	2020-12-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-51.87	Bank Transfer	No
finance	110889	2020-12-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-280.61	Bank Transfer	No
finance	110891	2020-12-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.37	Bank Transfer	No
finance	110892	2020-12-31	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-120.27	Bank Transfer	No
finance	50192	2021-01-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110893	2021-01-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-77.78	Bank Transfer	No
finance	110894	2021-01-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-116.13	Bank Transfer	No
finance	110895	2021-01-03	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-162.75	Bank Transfer	No
finance	110897	2021-01-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-603.54	Bank Transfer	No
finance	110896	2021-01-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.45	Bank Transfer	No
finance	110898	2021-01-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.27	Bank Transfer	No
finance	110900	2021-01-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.66	Bank Transfer	No
finance	110899	2021-01-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.21	Bank Transfer	No
finance	50194	2021-01-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110901	2021-01-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.09	Bank Transfer	No
finance	110902	2021-01-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.15	Bank Transfer	No
finance	50195	2021-01-18	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110903	2021-01-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-36.71	Bank Transfer	No
finance	110904	2021-01-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-162.95	Bank Transfer	No
finance	110905	2021-01-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.72	Bank Transfer	No
finance	110906	2021-01-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-26.29	Bank Transfer	No
finance	110907	2021-01-20	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-9.19	Bank Transfer	No
finance	110908	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.96	Bank Transfer	No
finance	110910	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.11	Bank Transfer	No
finance	110911	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.19	Bank Transfer	No
finance	110912	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-580.91	Bank Transfer	No
finance	110913	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.05	Bank Transfer	No
finance	110909	2021-01-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.05	Bank Transfer	No
finance	110914	2021-01-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-21.19	Bank Transfer	No
finance	110915	2021-01-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.51	Bank Transfer	No
finance	110916	2021-01-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-63.77	Bank Transfer	No
finance	50193	2021-01-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50196	2021-02-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110917	2021-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.29	Bank Transfer	No
finance	110918	2021-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.83	Bank Transfer	No
finance	110919	2021-02-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.8	Bank Transfer	No
finance	110920	2021-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.61	Bank Transfer	No
finance	110922	2021-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.74	Bank Transfer	No
finance	110923	2021-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-68.26	Bank Transfer	No
finance	110921	2021-02-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-176.48	Bank Transfer	No
finance	110924	2021-02-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-151.52	Bank Transfer	No
finance	110925	2021-02-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.27	Bank Transfer	No
finance	110926	2021-02-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-39.92	Bank Transfer	No
finance	110927	2021-02-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.79	Bank Transfer	No
finance	110928	2021-02-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.36	Bank Transfer	No
finance	110929	2021-02-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.93	Bank Transfer	No
finance	50198	2021-02-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110932	2021-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-134.64	Bank Transfer	No
finance	110931	2021-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-13.6	Bank Transfer	No
finance	110933	2021-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-54.15	Bank Transfer	No
finance	110930	2021-02-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.55	Bank Transfer	No
finance	110934	2021-02-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.01	Bank Transfer	No
finance	110935	2021-02-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.59	Bank Transfer	No
finance	110936	2021-02-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.68	Bank Transfer	No
finance	50199	2021-02-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110937	2021-02-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.51	Bank Transfer	No
finance	110938	2021-02-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.89	Bank Transfer	No
finance	110939	2021-02-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-76.33	Bank Transfer	No
finance	110940	2021-02-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-19.77	Bank Transfer	No
finance	110942	2021-02-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-17.95	Bank Transfer	No
finance	110943	2021-02-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.17	Bank Transfer	No
finance	110941	2021-02-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-400.81	Bank Transfer	No
finance	110944	2021-02-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-52.92	Bank Transfer	No
finance	110945	2021-02-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.22	Bank Transfer	No
finance	110946	2021-02-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.2	Bank Transfer	No
finance	50197	2021-02-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110947	2021-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.26	Bank Transfer	No
finance	110948	2021-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.39	Bank Transfer	No
finance	110949	2021-02-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.44	Bank Transfer	No
finance	50200	2021-03-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50203	2021-03-02	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110951	2021-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.85	Bank Transfer	No
finance	110952	2021-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-40.42	Bank Transfer	No
finance	110953	2021-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.72	Bank Transfer	No
finance	110950	2021-03-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.5	Bank Transfer	No
finance	110954	2021-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.91	Bank Transfer	No
finance	110955	2021-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.26	Bank Transfer	No
finance	110956	2021-03-10	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.65	Bank Transfer	No
finance	50202	2021-03-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110957	2021-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-105.36	Bank Transfer	No
finance	110958	2021-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-49.56	Bank Transfer	No
finance	110959	2021-03-13	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.98	Bank Transfer	No
finance	110962	2021-03-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-275.79	Bank Transfer	No
finance	110960	2021-03-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.08	Bank Transfer	No
finance	110961	2021-03-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-104.47	Bank Transfer	No
finance	110963	2021-03-15	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.7	Bank Transfer	No
finance	110964	2021-03-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-87.38	Bank Transfer	No
finance	110965	2021-03-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-144.38	Bank Transfer	No
finance	110966	2021-03-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-27.19	Bank Transfer	No
finance	110968	2021-03-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.6	Bank Transfer	No
finance	110969	2021-03-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.21	Bank Transfer	No
finance	110967	2021-03-25	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-62.22	Bank Transfer	No
finance	50201	2021-03-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	110973	2021-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.17	Bank Transfer	No
finance	110972	2021-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.02	Bank Transfer	No
finance	110971	2021-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-121.82	Bank Transfer	No
finance	110970	2021-03-28	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-16.16	Bank Transfer	No
finance	110976	2021-03-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-37.97	Bank Transfer	No
finance	110974	2021-03-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.96	Bank Transfer	No
finance	110975	2021-03-30	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.27	Bank Transfer	No
finance	50204	2021-04-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	110979	2021-04-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-353.07	Bank Transfer	No
finance	110978	2021-04-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.82	Bank Transfer	No
finance	110977	2021-04-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-208.5	Bank Transfer	No
finance	110981	2021-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-193.37	Bank Transfer	No
finance	110980	2021-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.26	Bank Transfer	No
finance	110982	2021-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.01	Bank Transfer	No
finance	110983	2021-04-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-657.54	Bank Transfer	No
finance	50206	2021-04-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	110986	2021-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-217.86	Bank Transfer	No
finance	110985	2021-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-91.51	Bank Transfer	No
finance	110984	2021-04-11	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-211.22	Bank Transfer	No
finance	110988	2021-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-61.14	Bank Transfer	No
finance	110987	2021-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-185.48	Bank Transfer	No
finance	110989	2021-04-14	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-34.76	Bank Transfer	No
finance	110990	2021-04-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-117.61	Bank Transfer	No
finance	110991	2021-04-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.51	Bank Transfer	No
finance	110992	2021-04-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.27	Bank Transfer	No
finance	110993	2021-04-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.81	Bank Transfer	No
finance	110996	2021-04-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.12	Bank Transfer	No
finance	110994	2021-04-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65.53	Bank Transfer	No
finance	110995	2021-04-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-46	Bank Transfer	No
finance	50207	2021-04-21	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	110997	2021-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-73.91	Bank Transfer	No
finance	110998	2021-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-20.31	Bank Transfer	No
finance	110999	2021-04-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-96.35	Bank Transfer	No
finance	50205	2021-04-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	111000	2021-04-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-55.12	Bank Transfer	No
finance	111001	2021-04-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-197.3	Bank Transfer	No
finance	111002	2021-04-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-141.16	Bank Transfer	No
finance	111003	2021-04-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.91	Bank Transfer	No
finance	50208	2021-05-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	111004	2021-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.84	Bank Transfer	No
finance	111005	2021-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.75	Bank Transfer	No
finance	111006	2021-05-01	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-25.19	Bank Transfer	No
finance	111009	2021-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.11	Bank Transfer	No
finance	111007	2021-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-202.24	Bank Transfer	No
finance	111008	2021-05-04	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-79.46	Bank Transfer	No
finance	111011	2021-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-1.21	Bank Transfer	No
finance	111013	2021-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-32.99	Bank Transfer	No
finance	111012	2021-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-242.95	Bank Transfer	No
finance	111010	2021-05-06	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-28.71	Bank Transfer	No
finance	111016	2021-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-33.8	Bank Transfer	No
finance	111015	2021-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.62	Bank Transfer	No
finance	111014	2021-05-08	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-23.6	Bank Transfer	No
finance	50210	2021-05-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	111019	2021-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.17	Bank Transfer	No
finance	111018	2021-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-11.65	Bank Transfer	No
finance	111017	2021-05-16	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-754.26	Bank Transfer	No
finance	111020	2021-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-43.3	Bank Transfer	No
finance	111021	2021-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-297.18	Bank Transfer	No
finance	111022	2021-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.27	Bank Transfer	No
finance	111023	2021-05-18	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-123.83	Bank Transfer	No
finance	50211	2021-05-20	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	111025	2021-05-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.17	Bank Transfer	No
finance	111026	2021-05-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.09	Bank Transfer	No
finance	111024	2021-05-21	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-74.36	Bank Transfer	No
finance	111027	2021-05-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-52.52	Bank Transfer	No
finance	111028	2021-05-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.59	Bank Transfer	No
finance	111029	2021-05-23	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-47.84	Bank Transfer	No
finance	111030	2021-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-830.75	Bank Transfer	No
finance	111032	2021-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-606.19	Bank Transfer	No
finance	111033	2021-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-84.74	Bank Transfer	No
finance	111031	2021-05-26	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-227.22	Bank Transfer	No
finance	50209	2021-05-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	50212	2021-06-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	111036	2021-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-149.47	Bank Transfer	No
finance	111035	2021-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.17	Bank Transfer	No
finance	111034	2021-06-02	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-40.32	Bank Transfer	No
finance	111037	2021-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-3.2	Bank Transfer	No
finance	111038	2021-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.59	Bank Transfer	No
finance	111039	2021-06-05	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-65	Bank Transfer	No
finance	111042	2021-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.99	Bank Transfer	No
finance	111040	2021-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.84	Bank Transfer	No
finance	111041	2021-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-48.22	Bank Transfer	No
finance	111043	2021-06-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.8	Bank Transfer	No
finance	111044	2021-06-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.72	Bank Transfer	No
finance	111046	2021-06-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-71.64	Bank Transfer	No
finance	111045	2021-06-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-70.58	Bank Transfer	No
finance	50214	2021-06-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	111048	2021-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.12	Bank Transfer	No
finance	111049	2021-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.34	Bank Transfer	No
finance	111047	2021-06-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-46.62	Bank Transfer	No
finance	50215	2021-06-16	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	111050	2021-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-59.41	Bank Transfer	No
finance	111051	2021-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-2.79	Bank Transfer	No
finance	111052	2021-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-67.26	Bank Transfer	No
finance	111053	2021-06-19	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-53.05	Bank Transfer	No
finance	111054	2021-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.33	Bank Transfer	No
finance	111055	2021-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-120.92	Bank Transfer	No
finance	111056	2021-06-22	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-278.96	Bank Transfer	No
finance	111059	2021-06-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-85.8	Bank Transfer	No
finance	111058	2021-06-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-31.14	Bank Transfer	No
finance	111057	2021-06-24	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-4.13	Bank Transfer	No
finance	111061	2021-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-14.01	Bank Transfer	No
finance	111060	2021-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-10.98	Bank Transfer	No
finance	111063	2021-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-81.73	Bank Transfer	No
finance	111062	2021-06-27	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-29.93	Bank Transfer	No
finance	50213	2021-06-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
finance	111064	2021-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-30.09	Bank Transfer	No
finance	111066	2021-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-44.72	Bank Transfer	No
finance	111065	2021-06-29	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-12.91	Bank Transfer	No
finance	50216	2021-07-01	Corporate Checking	Expense	Office Rent	Downtown Property Management	-15000	Bank Transfer	Yes
finance	50219	2021-07-04	Corporate Credit Card	Expense	IT Services	AWS Cloud Hosting	-3500	Credit Card	Yes
finance	111067	2021-07-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-7.98	Bank Transfer	No
finance	111068	2021-07-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-81.75	Bank Transfer	No
finance	111069	2021-07-07	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-15.67	Bank Transfer	No
finance	111072	2021-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-258.64	Bank Transfer	No
finance	111070	2021-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-136	Bank Transfer	No
finance	111073	2021-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-24.95	Bank Transfer	No
finance	111071	2021-07-09	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-0.93	Bank Transfer	No
finance	50218	2021-07-11	Corporate Checking	Expense	Utilities	City Water & Power	-1200.5	Auto-Pay	Yes
finance	111074	2021-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-18.44	Bank Transfer	No
finance	111075	2021-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-6.19	Bank Transfer	No
finance	111076	2021-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-38.28	Bank Transfer	No
finance	111077	2021-07-12	Corporate Checking	Expense	Logistics & Freight	Shipping Provider	-8.53	Bank Transfer	No
finance	50217	2021-07-28	Corporate Checking	Expense	Payroll	Employee Salaries	-120000	Direct Deposit	Yes
\.


--
-- Data for Name: structured_finance_company_revenue_sheet1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_finance_company_revenue_sheet1 (permission_scope_key, transaction_id, date, description_merchant, amount) FROM stdin;
finance	10248	2017-01-01	Vins et alcools Chevalier	440
finance	10249	2017-01-03	Toms Spezialitäten	1863.4
finance	10250	2017-01-10	Hanari Carnes	1552.6
finance	10251	2017-01-10	Victuailles en stock	654.06
finance	10252	2017-01-13	Suprêmes délices	3597.9
finance	10253	2017-01-15	Hanari Carnes	1444.8
finance	10254	2017-01-18	Chop-suey Chinese	556.6199999999999
finance	10255	2017-01-20	Richter Supermarkt	2490.5
finance	10256	2017-01-28	Wellington Importadora	517.8
finance	10257	2017-01-30	HILARION-Abastos	1119.9
finance	10258	2017-02-02	Ernst Handel	1614.88
finance	10259	2017-02-04	Centro comercial Moctezuma	100.8
finance	10261	2017-02-06	Que Delícia	448
finance	10260	2017-02-06	Ottilies Käseladen	1504.65
finance	10262	2017-02-14	Rattlesnake Canyon Grocery	584
finance	10263	2017-02-16	Ernst Handel	1873.8
finance	10264	2017-02-19	Folk och fä HB	695.625
finance	10265	2017-02-21	Blondesddsl père et fils	1176
finance	10266	2017-02-24	Wartian Herkku	346.5599999999999
finance	10267	2017-03-03	Frankenversand	3536.6
finance	10268	2017-03-06	GROSELLA-Restaurante	1101.2
finance	10269	2017-03-08	White Clover Markets	642.1999999999999
finance	10270	2017-03-10	Wartian Herkku	1376
finance	10271	2017-03-10	Split Rail Beer & Ale	48
finance	10272	2017-03-13	Rattlesnake Canyon Grocery	1456
finance	10273	2017-03-20	QUICK-Stop	2037.28
finance	10274	2017-03-23	Vins et alcools Chevalier	538.6
finance	10275	2017-03-25	Magazzini Alimentari Riuniti	291.84
finance	10276	2017-03-28	Tortuga Restaurante	420
finance	10277	2017-03-30	Morgenstern Gesundkost	1200.8
finance	10278	2017-04-07	Berglunds snabbköp	1488.8
finance	10279	2017-04-09	Lehmanns Marktstand	351
finance	10280	2017-04-12	Berglunds snabbköp	613.2
finance	10281	2017-04-12	Romero y tomillo	86.5
finance	10282	2017-04-14	Romero y tomillo	155.4
finance	10283	2017-04-16	LILA-Supermercado	1414.8
finance	10284	2017-04-24	Lehmanns Marktstand	1170.375
finance	10285	2017-04-26	QUICK-Stop	1743.36
finance	10286	2017-04-29	QUICK-Stop	3016
finance	10287	2017-05-01	Ricardo Adocicados	819
finance	10288	2017-05-04	Reggiani Caseifici	80.1
finance	10289	2017-05-11	B's Beverages	479.4
finance	10290	2017-05-14	Comércio Mineiro	2169
finance	10291	2017-05-14	Que Delícia	497.52
finance	10292	2017-05-16	Tradição Hipermercados	1296
finance	10293	2017-05-18	Tortuga Restaurante	848.7
finance	10294	2017-05-21	Rattlesnake Canyon Grocery	1887.6
finance	10295	2017-05-28	Vins et alcools Chevalier	121.6
finance	10296	2017-05-31	LILA-Supermercado	1050.6
finance	10297	2017-06-02	Blondesddsl père et fils	1420
finance	10298	2017-06-05	Hungry Owl All-Night Grocers	2645
finance	10299	2017-06-07	Ricardo Adocicados	349.5
finance	10300	2017-06-15	Magazzini Alimentari Riuniti	608
finance	10301	2017-06-15	Die Wandernde Kuh	755
finance	10302	2017-06-17	Suprêmes délices	2708.8
finance	10303	2017-06-19	Godos Cocina Típica	1117.8
finance	10304	2017-06-22	Tortuga Restaurante	954.4
finance	10305	2017-06-24	Old World Delicatessen	3741.3
finance	10306	2017-07-02	Romero y tomillo	498.5
finance	10307	2017-07-04	Lonesome Pine Restaurant	424
finance	10308	2017-07-07	Ana Trujillo Emparedados y helados	88.8
finance	10309	2017-07-09	Hungry Owl All-Night Grocers	1762
finance	10310	2017-07-12	The Big Cheese	336
finance	10311	2017-07-12	Du monde entier	268.8
finance	10312	2017-07-19	Die Wandernde Kuh	1614.8
finance	10313	2017-07-22	QUICK-Stop	182.4
finance	10314	2017-07-24	Rattlesnake Canyon Grocery	2094.3
finance	10315	2017-07-26	Island Trading	516.8
finance	10316	2017-07-29	Rattlesnake Canyon Grocery	2835
finance	10317	2017-08-05	Lonesome Pine Restaurant	288
finance	10318	2017-08-08	Island Trading	240.4
finance	10319	2017-08-10	Tortuga Restaurante	1191.2
finance	10320	2017-08-13	Wartian Herkku	516
finance	10321	2017-08-13	Island Trading	144
finance	10322	2017-08-15	Pericles Comidas clásicas	112
finance	10323	2017-08-23	Königlich Essen	164.4
finance	10324	2017-08-25	Save-a-lot Markets	5275.715
finance	10325	2017-08-27	Königlich Essen	1497
finance	10326	2017-08-30	Bólido Comidas preparadas	982
finance	10327	2017-09-01	Folk och fä HB	1810
finance	10328	2017-09-09	Furia Bacalhau e Frutos do Mar	1168
finance	10329	2017-09-11	Split Rail Beer & Ale	4578.43
finance	10330	2017-09-14	LILA-Supermercado	1649
finance	10331	2017-09-14	Bon app'	88.5
finance	10332	2017-09-16	Mère Paillarde	1786.88
finance	10333	2017-09-19	Wartian Herkku	877.2
finance	10334	2017-09-26	Victuailles en stock	144.8
finance	10335	2017-09-28	Hungry Owl All-Night Grocers	2036.16
finance	10336	2017-10-01	Princesa Isabel Vinhos	285.12
finance	10337	2017-10-03	Frankenversand	2467
finance	10338	2017-10-06	Old World Delicatessen	934.5
finance	10339	2017-10-13	Mère Paillarde	3354
finance	10340	2017-10-16	Bon app'	2436.18
finance	10341	2017-10-16	Simons bistro	352.6
finance	10342	2017-10-18	Frankenversand	1840.64
finance	10343	2017-10-21	Lehmanns Marktstand	1584
finance	10344	2017-10-23	White Clover Markets	2296
finance	10345	2017-10-31	QUICK-Stop	2924.8
finance	10346	2017-11-02	Rattlesnake Canyon Grocery	1618.88
finance	10347	2017-11-04	Familia Arquibaldo	814.42
finance	10348	2017-11-07	Die Wandernde Kuh	363.6
finance	10349	2017-11-09	Split Rail Beer & Ale	141.6
finance	10351	2017-11-17	Ernst Handel	5398.724999999999
finance	10350	2017-11-17	La maison d'Asie	642.06
finance	10352	2017-11-19	Furia Bacalhau e Frutos do Mar	136.3
finance	10353	2017-11-22	Piccolo und mehr	8593.28
finance	10354	2017-11-24	Pericles Comidas clásicas	568.8
finance	10355	2017-11-27	Around the Horn	480
finance	10356	2017-12-04	Die Wandernde Kuh	1106.4
finance	10357	2017-12-06	LILA-Supermercado	1167.68
finance	10358	2017-12-09	La maison d'Asie	429.4
finance	10359	2017-12-11	Seven Seas Imports	3471.68
finance	10360	2017-12-14	Blondesddsl père et fils	7390.2
finance	10361	2017-12-14	QUICK-Stop	2046.24
finance	10362	2017-12-21	Bon app'	1549.6
finance	10364	2017-12-24	Eastern Connection	950
finance	10363	2017-12-24	Drachenblut Delikatessen	447.2
finance	10365	2017-12-26	Antonio Moreno Taquería	403.2
finance	10366	2017-12-29	Galería del gastrónomo	136
finance	10367	2017-12-29	Vaffeljernet	834.1999999999999
finance	10368	2017-12-31	Ernst Handel	1689.78
finance	10369	2018-01-07	Split Rail Beer & Ale	2390.4
finance	10370	2018-01-10	Chop-suey Chinese	1117.6
finance	10371	2018-01-10	La maison d'Asie	72.96
finance	10372	2018-01-12	Queen Cozinha	9210.9
finance	10373	2018-01-15	Hungry Owl All-Night Grocers	1366.4
finance	10374	2018-01-15	Wolski  Zajazd	459
finance	10375	2018-01-17	Hungry Coyote Import Store	338
finance	10377	2018-01-25	Seven Seas Imports	863.5999999999999
finance	10376	2018-01-25	Mère Paillarde	399
finance	10378	2018-01-27	Folk och fä HB	103.2
finance	10379	2018-01-30	Que Delícia	863.2800000000001
finance	10380	2018-02-01	Hungry Owl All-Night Grocers	1313.82
finance	10381	2018-02-01	LILA-Supermercado	112
finance	10382	2018-02-04	Ernst Handel	2900
finance	10383	2018-02-11	Around the Horn	899
finance	10384	2018-02-11	Berglunds snabbköp	2222.4
finance	10385	2018-02-13	Split Rail Beer & Ale	691.2
finance	10386	2018-02-16	Familia Arquibaldo	166
finance	10387	2018-02-16	Santé Gourmet	1058.4
finance	10388	2018-02-18	Seven Seas Imports	1228.8
finance	10389	2018-02-21	Bottom-Dollar Markets	1832.8
finance	10390	2018-02-28	Ernst Handel	2090.88
finance	10391	2018-02-28	Drachenblut Delikatessen	86.39999999999999
finance	10392	2018-03-03	Piccolo und mehr	1440
finance	10393	2018-03-05	Save-a-lot Markets	2556.95
finance	10394	2018-03-05	Hungry Coyote Import Store	442
finance	10395	2018-03-08	HILARION-Abastos	2122.92
finance	10396	2018-03-10	Frankenversand	1903.8
finance	10397	2018-03-10	Princesa Isabel Vinhos	716.7199999999999
finance	10398	2018-03-17	Save-a-lot Markets	2505.6
finance	10399	2018-03-20	Vaffeljernet	1765.6
finance	10400	2018-03-22	Eastern Connection	3063
finance	10401	2018-03-22	Rattlesnake Canyon Grocery	3868.6
finance	10402	2018-03-25	Ernst Handel	2713.5
finance	10403	2018-03-27	Ernst Handel	855.015
finance	10404	2018-03-27	Magazzini Alimentari Riuniti	1591.25
finance	10405	2018-04-04	LINO-Delicateses	400
finance	10406	2018-04-06	Queen Cozinha	1830.78
finance	10407	2018-04-06	Ottilies Käseladen	1194
finance	10408	2018-04-09	Folies gourmandes	1622.4
finance	10409	2018-04-11	Océano Atlántico Ltda.	319.2
finance	10410	2018-04-14	Bottom-Dollar Markets	802
finance	10411	2018-04-14	Bottom-Dollar Markets	966.8
finance	10412	2018-04-21	Wartian Herkku	334.8
finance	10414	2018-04-23	Familia Arquibaldo	224.83
finance	10413	2018-04-23	La maison d'Asie	2123.2
finance	10415	2018-04-26	Hungry Coyote Import Store	102.4
finance	10416	2018-04-28	Wartian Herkku	720
finance	10417	2018-04-28	Simons bistro	11188.4
finance	10418	2018-05-01	QUICK-Stop	1814.8
finance	10419	2018-05-08	Richter Supermarkt	2097.6
finance	10420	2018-05-11	Wellington Importadora	1707.84
finance	10421	2018-05-11	Que Delícia	1194.27
finance	10422	2018-05-13	Franchi S.p.A.	49.8
finance	10424	2018-05-16	Mère Paillarde	9194.560000000001
finance	10423	2018-05-16	Gourmet Lanchonetes	1020
finance	10425	2018-05-18	La maison d'Asie	360
finance	10427	2018-05-25	Piccolo und mehr	651
finance	10426	2018-05-25	Galería del gastrónomo	338.2
finance	10428	2018-05-28	Reggiani Caseifici	192
finance	10429	2018-05-30	Hungry Owl All-Night Grocers	1441.375
finance	10430	2018-06-02	Ernst Handel	4899.2
finance	10431	2018-06-02	Bottom-Dollar Markets	1892.25
finance	10432	2018-06-04	Split Rail Beer & Ale	485
finance	10433	2018-06-12	Princesa Isabel Vinhos	851.1999999999999
finance	10434	2018-06-12	Folk och fä HB	321.12
finance	10435	2018-06-14	Consolidated Holdings	631.6
finance	10436	2018-06-17	Blondesddsl père et fils	1994.52
finance	10437	2018-06-17	Wartian Herkku	393
finance	10438	2018-06-19	Toms Spezialitäten	454.0000000000001
finance	10439	2018-06-22	Mère Paillarde	1078
finance	10440	2018-06-29	Save-a-lot Markets	4924.135
finance	10441	2018-06-29	Old World Delicatessen	1755
finance	10442	2018-07-01	Ernst Handel	1792
finance	10443	2018-07-04	Reggiani Caseifici	517.4399999999999
finance	10444	2018-07-04	Berglunds snabbköp	1031.7
finance	10445	2018-07-06	Berglunds snabbköp	174.9
finance	10446	2018-07-09	Toms Spezialitäten	246.24
finance	10447	2018-07-09	Ricardo Adocicados	914.4
finance	10448	2018-07-16	Rancho grande	443.4
finance	10449	2018-07-19	Blondesddsl père et fils	1838.2
finance	10451	2018-07-21	QUICK-Stop	3849.66
finance	10450	2018-07-21	Victuailles en stock	425.12
finance	10452	2018-07-24	Save-a-lot Markets	2018.5
finance	10454	2018-07-26	La maison d'Asie	331.2
finance	10453	2018-07-26	Around the Horn	407.7
finance	10455	2018-08-02	Wartian Herkku	2684
finance	10456	2018-08-05	Königlich Essen	557.5999999999999
finance	10457	2018-08-05	Königlich Essen	1584
finance	10458	2018-08-07	Suprêmes délices	3891
finance	10459	2018-08-10	Victuailles en stock	1659.2
finance	10460	2018-08-12	Folk och fä HB	176.1
finance	10461	2018-08-12	LILA-Supermercado	1538.7
finance	10462	2018-08-20	Consolidated Holdings	156
finance	10463	2018-08-22	Suprêmes délices	713.3
finance	10464	2018-08-22	Furia Bacalhau e Frutos do Mar	1609.28
finance	10465	2018-08-25	Vaffeljernet	2518
finance	10466	2018-08-27	Comércio Mineiro	216
finance	10467	2018-08-27	Magazzini Alimentari Riuniti	235.2
finance	10468	2018-08-30	Königlich Essen	717.6
finance	10469	2018-09-06	White Clover Markets	956.675
finance	10470	2018-09-08	Bon app'	1820.8
finance	10471	2018-09-08	B's Beverages	1328
finance	10472	2018-09-11	Seven Seas Imports	1036.8
finance	10473	2018-09-13	Island Trading	230.4
finance	10474	2018-09-13	Pericles Comidas clásicas	1249.1
finance	10475	2018-09-16	Suprêmes délices	1505.18
finance	10476	2018-09-23	HILARION-Abastos	180.48
finance	10477	2018-09-23	Princesa Isabel Vinhos	558
finance	10478	2018-09-26	Victuailles en stock	471.2
finance	10479	2018-09-28	Rattlesnake Canyon Grocery	10495.6
finance	10480	2018-10-01	Folies gourmandes	756
finance	10481	2018-10-01	Ricardo Adocicados	1472
finance	10482	2018-10-03	Lazy K Kountry Store	147
finance	10483	2018-10-10	White Clover Markets	668.8
finance	10484	2018-10-10	B's Beverages	386.2
finance	10485	2018-10-13	LINO-Delicateses	1584
finance	10486	2018-10-15	HILARION-Abastos	1272
finance	10487	2018-10-15	Queen Cozinha	889.7
finance	10488	2018-10-18	Frankenversand	1512
finance	10489	2018-10-20	Piccolo und mehr	439.2
finance	10491	2018-10-28	Furia Bacalhau e Frutos do Mar	259.505
finance	10490	2018-10-28	HILARION-Abastos	3163.2
finance	10492	2018-10-30	Bottom-Dollar Markets	851.1999999999999
finance	10493	2018-11-02	La maison d'Asie	608.4
finance	10494	2018-11-02	Comércio Mineiro	912
finance	10495	2018-11-04	Laughing Bacchus Wine Cellars	278
finance	10496	2018-11-06	Tradição Hipermercados	190
finance	10497	2018-11-06	Lehmanns Marktstand	1380.6
finance	10498	2018-11-14	HILARION-Abastos	575
finance	10499	2018-11-16	LILA-Supermercado	1412
finance	10500	2018-11-19	La maison d'Asie	523.26
finance	10501	2018-11-19	Blauer See Delikatessen	149
finance	10502	2018-11-21	Pericles Comidas clásicas	816.3
finance	10504	2018-11-24	White Clover Markets	1388.5
finance	10503	2018-11-24	Hungry Owl All-Night Grocers	2048.5
finance	10505	2018-12-01	Mère Paillarde	147.9
finance	10506	2018-12-04	Königlich Essen	415.8
finance	10507	2018-12-04	Antonio Moreno Taquería	749.0625
finance	10508	2018-12-06	Ottilies Käseladen	240
finance	10509	2018-12-09	Blauer See Delikatessen	136.8
finance	10510	2018-12-11	Save-a-lot Markets	4707.540000000001
finance	10511	2018-12-11	Bon app'	2550
finance	10512	2018-12-18	Familia Arquibaldo	525.3
finance	10513	2018-12-21	Die Wandernde Kuh	1942
finance	10514	2018-12-21	Ernst Handel	8623.45
finance	10515	2018-12-23	QUICK-Stop	9921.3
finance	10517	2018-12-26	North/South	352
finance	10516	2018-12-26	Hungry Owl All-Night Grocers	2381.05
finance	10518	2018-12-28	Tortuga Restaurante	4150.05
finance	10519	2019-01-05	Chop-suey Chinese	2314.2
finance	10520	2019-01-07	Santé Gourmet	200
finance	10521	2019-01-07	Cactus Comidas para llevar	225.5
finance	10522	2019-01-10	Lehmanns Marktstand	2318.24
finance	10523	2019-01-12	Seven Seas Imports	2444.31
finance	10524	2019-01-12	Berglunds snabbköp	3192.65
finance	10525	2019-01-14	Bon app'	818.4
finance	10526	2019-01-22	Wartian Herkku	1151.4
finance	10527	2019-01-22	QUICK-Stop	1503
finance	10528	2019-01-24	Great Lakes Food Market	392.2
finance	10529	2019-01-27	Maison Dewey	946
finance	10530	2019-01-29	Piccolo und mehr	4180
finance	10531	2019-01-29	Océano Atlántico Ltda.	110
finance	10532	2019-02-01	Eastern Connection	796.35
finance	10533	2019-02-08	Folk och fä HB	2222.2
finance	10534	2019-02-08	Lehmanns Marktstand	465.7
finance	10535	2019-02-11	Antonio Moreno Taquería	1940.85
finance	10536	2019-02-13	Lehmanns Marktstand	1645
finance	10537	2019-02-13	Richter Supermarkt	1823.8
finance	10538	2019-02-15	B's Beverages	139.8
finance	10539	2019-02-18	B's Beverages	355.5
finance	10541	2019-02-25	Hanari Carnes	1946.52
finance	10540	2019-02-25	QUICK-Stop	10191.7
finance	10542	2019-02-28	Königlich Essen	469.11
finance	10543	2019-03-02	LILA-Supermercado	1504.5
finance	10544	2019-03-02	Lonesome Pine Restaurant	417.2
finance	10545	2019-03-05	Lazy K Kountry Store	210
finance	10546	2019-03-07	Victuailles en stock	2812
finance	10547	2019-03-07	Seven Seas Imports	1792.8
finance	10548	2019-03-15	Toms Spezialitäten	240.1
finance	10549	2019-03-17	QUICK-Stop	3554.275
finance	10551	2019-03-20	Furia Bacalhau e Frutos do Mar	1677.3
finance	10550	2019-03-20	Godos Cocina Típica	683.3
finance	10552	2019-03-22	HILARION-Abastos	880.5
finance	10554	2019-03-24	Ottilies Käseladen	1728.525
finance	10553	2019-03-24	Wartian Herkku	1546.3
finance	10555	2019-04-01	Save-a-lot Markets	2944.4
finance	10557	2019-04-03	Lehmanns Marktstand	1152.5
finance	10556	2019-04-03	Simons bistro	835.1999999999999
finance	10558	2019-04-06	Around the Horn	2142.9
finance	10559	2019-04-08	Blondesddsl père et fils	520.41
finance	10560	2019-04-11	Frankenversand	1072.425
finance	10561	2019-04-11	Folk och fä HB	2844.5
finance	10562	2019-04-18	Reggiani Caseifici	488.7
finance	10563	2019-04-21	Ricardo Adocicados	965
finance	10564	2019-04-21	Rattlesnake Canyon Grocery	1234.05
finance	10565	2019-04-23	Mère Paillarde	639.9
finance	10566	2019-04-25	Blondesddsl père et fils	1761
finance	10567	2019-04-25	Hungry Owl All-Night Grocers	2519
finance	10568	2019-04-28	Galería del gastrónomo	155
finance	10569	2019-05-05	Rattlesnake Canyon Grocery	890
finance	10570	2019-05-08	Mère Paillarde	2465.25
finance	10571	2019-05-08	Ernst Handel	550.5875
finance	10572	2019-05-10	Berglunds snabbköp	1501.085
finance	10573	2019-05-13	Antonio Moreno Taquería	2082
finance	10574	2019-05-13	Trail's Head Gourmet Provisioners	764.3
finance	10575	2019-05-15	Morgenstern Gesundkost	2147.4
finance	10576	2019-05-23	Tortuga Restaurante	838.45
finance	10577	2019-05-23	Trail's Head Gourmet Provisioners	569
finance	10578	2019-05-25	B's Beverages	477
finance	10579	2019-05-28	Let's Stop N Shop	317.75
finance	10581	2019-05-30	Familia Arquibaldo	310
finance	10580	2019-05-30	Ottilies Käseladen	1013.745
finance	10582	2019-06-01	Blauer See Delikatessen	330
finance	10583	2019-06-09	Wartian Herkku	2237.5
finance	10584	2019-06-09	Blondesddsl père et fils	593.75
finance	10585	2019-06-11	Wellington Importadora	142.5
finance	10586	2019-06-14	Reggiani Caseifici	23.8
finance	10587	2019-06-14	Que Delícia	807.38
finance	10588	2019-06-16	QUICK-Stop	3120
finance	10589	2019-06-19	Great Lakes Food Market	72
finance	10590	2019-06-26	Mère Paillarde	1101
finance	10591	2019-06-26	Vaffeljernet	812.5
finance	10592	2019-06-29	Lehmanns Marktstand	516.4675
finance	10594	2019-07-01	Old World Delicatessen	565.5
finance	10593	2019-07-01	Lehmanns Marktstand	1994.4
finance	10595	2019-07-03	Ernst Handel	4725
finance	10596	2019-07-06	White Clover Markets	1180.88
finance	10597	2019-07-06	Piccolo und mehr	718.08
finance	10598	2019-07-13	Rattlesnake Canyon Grocery	2388.5
finance	10599	2019-07-16	B's Beverages	493
finance	10600	2019-07-18	Hungry Coyote Import Store	479.8
finance	10601	2019-07-18	HILARION-Abastos	2285
finance	10602	2019-07-21	Vaffeljernet	48.75
finance	10603	2019-07-23	Save-a-lot Markets	1483
finance	10604	2019-07-23	Furia Bacalhau e Frutos do Mar	230.85
finance	10605	2019-07-31	Mère Paillarde	4109.7
finance	10607	2019-08-02	Save-a-lot Markets	6475.4
finance	10606	2019-08-02	Tradição Hipermercados	1130.4
finance	10608	2019-08-04	Toms Spezialitäten	1064
finance	10609	2019-08-07	Du monde entier	424
finance	10610	2019-08-09	La maison d'Asie	299.25
finance	10611	2019-08-09	Wolski  Zajazd	808
finance	10612	2019-08-17	Save-a-lot Markets	6375
finance	10613	2019-08-19	HILARION-Abastos	353.2
finance	10614	2019-08-19	Blauer See Delikatessen	464
finance	10615	2019-08-22	Wilman Kala	120
finance	10616	2019-08-24	Great Lakes Food Market	4807
finance	10617	2019-08-24	Great Lakes Food Market	1402.5
finance	10618	2019-08-27	Mère Paillarde	2697.5
finance	10619	2019-09-03	Mère Paillarde	1260
finance	10620	2019-09-06	Laughing Bacchus Wine Cellars	57.5
finance	10621	2019-09-06	Island Trading	758.5
finance	10622	2019-09-08	Ricardo Adocicados	560
finance	10623	2019-09-10	Frankenversand	1336.95
finance	10624	2019-09-10	The Cracker Box	1393.24
finance	10625	2019-09-13	Ana Trujillo Emparedados y helados	479.75
finance	10626	2019-09-20	Berglunds snabbköp	1503.6
finance	10627	2019-09-20	Save-a-lot Markets	1185.75
finance	10628	2019-09-23	Blondesddsl père et fils	450
finance	10629	2019-09-23	Godos Cocina Típica	2775.05
finance	10630	2019-09-25	Königlich Essen	903.5999999999999
finance	10632	2019-09-28	Die Wandernde Kuh	589
finance	10631	2019-09-28	La maison d'Asie	55.8
finance	10633	2019-09-30	Ernst Handel	5510.5925
finance	10634	2019-09-30	Folies gourmandes	4985.5
finance	10635	2019-10-08	Magazzini Alimentari Riuniti	1326.225
finance	10636	2019-10-10	Wartian Herkku	629.5
finance	10637	2019-10-10	Queen Cozinha	2761.9375
finance	10638	2019-10-12	LINO-Delicateses	2720.05
finance	10639	2019-10-12	Santé Gourmet	500
finance	10640	2019-10-15	Die Wandernde Kuh	708.75
finance	10641	2019-10-17	HILARION-Abastos	2054
finance	10642	2019-10-17	Simons bistro	696
finance	10644	2019-10-25	Wellington Importadora	1371.8
finance	10643	2019-10-25	Alfreds Futterkiste	814.5
finance	10645	2019-10-27	Hanari Carnes	1535
finance	10646	2019-10-30	Hungry Owl All-Night Grocers	1446
finance	10647	2019-10-30	Que Delícia	636
finance	10648	2019-11-01	Ricardo Adocicados	372.375
finance	10649	2019-11-01	Maison Dewey	1434
finance	10650	2019-11-04	Familia Arquibaldo	1779.2
finance	10651	2019-11-11	Die Wandernde Kuh	397.8
finance	10652	2019-11-11	Gourmet Lanchonetes	318.835
finance	10654	2019-11-13	Berglunds snabbköp	601.83
finance	10653	2019-11-13	Frankenversand	1083.15
finance	10655	2019-11-16	Reggiani Caseifici	154.4
finance	10656	2019-11-18	Great Lakes Food Market	604.215
finance	10657	2019-11-18	Save-a-lot Markets	4371.6
finance	10659	2019-11-21	Queen Cozinha	1227.02
finance	10658	2019-11-21	QUICK-Stop	4464.6
finance	10660	2019-11-28	Hungry Coyote Import Store	1701
finance	10662	2019-12-01	Lonesome Pine Restaurant	125
finance	10661	2019-12-01	Hungry Owl All-Night Grocers	562.6
finance	10663	2019-12-03	Bon app'	1930.4
finance	10664	2019-12-03	Furia Bacalhau e Frutos do Mar	1288.3875
finance	10665	2019-12-06	Lonesome Pine Restaurant	1295
finance	10666	2019-12-08	Richter Supermarkt	4666.940000000001
finance	10667	2019-12-08	Ernst Handel	1536.8
finance	10668	2019-12-16	Die Wandernde Kuh	625.275
finance	10669	2019-12-16	Simons bistro	570
finance	10670	2019-12-18	Frankenversand	2301.75
finance	10671	2019-12-20	France restauration	920.1
finance	10672	2019-12-20	Berglunds snabbköp	3815.25
finance	10674	2019-12-23	Island Trading	45
finance	10673	2019-12-23	Wilman Kala	412.35
finance	10675	2019-12-25	Frankenversand	1423
finance	10676	2020-01-02	Tortuga Restaurante	534.85
finance	10677	2020-01-02	Antonio Moreno Taquería	813.365
finance	10678	2020-01-04	Save-a-lot Markets	5256.5
finance	10679	2020-01-04	Blondesddsl père et fils	660
finance	10680	2020-01-07	Old World Delicatessen	1261.875
finance	10681	2020-01-09	Great Lakes Food Market	1287.4
finance	10682	2020-01-09	Antonio Moreno Taquería	375.5
finance	10683	2020-01-12	Du monde entier	63
finance	10684	2020-01-12	Ottilies Käseladen	1768
finance	10685	2020-01-19	Gourmet Lanchonetes	801.1
finance	10687	2020-01-21	Hungry Owl All-Night Grocers	4960.9
finance	10686	2020-01-21	Piccolo und mehr	1404.45
finance	10688	2020-01-24	Vaffeljernet	3160.6
finance	10689	2020-01-24	Berglunds snabbköp	472.5
finance	10690	2020-01-26	Hanari Carnes	862.5
finance	10691	2020-01-29	QUICK-Stop	10164.8
finance	10692	2020-01-29	Alfreds Futterkiste	878
finance	10693	2020-02-05	White Clover Markets	2071.2
finance	10694	2020-02-05	QUICK-Stop	4825
finance	10695	2020-02-08	Wilman Kala	642
finance	10696	2020-02-10	White Clover Markets	996
finance	10697	2020-02-10	LINO-Delicateses	805.425
finance	10698	2020-02-13	Ernst Handel	3436.4435
finance	10699	2020-02-13	Morgenstern Gesundkost	114
finance	10700	2020-02-15	Save-a-lot Markets	1638.4
finance	10701	2020-02-22	Hungry Owl All-Night Grocers	2864.5
finance	10702	2020-02-22	Alfreds Futterkiste	330
finance	10703	2020-02-25	Folk och fä HB	2545
finance	10704	2020-02-25	Queen Cozinha	595.5
finance	10705	2020-02-27	HILARION-Abastos	378
finance	10706	2020-03-01	Old World Delicatessen	1893
finance	10707	2020-03-01	Around the Horn	1641
finance	10708	2020-03-03	The Big Cheese	180.4
finance	10709	2020-03-03	Gourmet Lanchonetes	3424
finance	10710	2020-03-11	Franchi S.p.A.	93.5
finance	10712	2020-03-13	Hungry Owl All-Night Grocers	1233.48
finance	10711	2020-03-13	Save-a-lot Markets	4451.7
finance	10714	2020-03-16	Save-a-lot Markets	2205.75
finance	10713	2020-03-16	Save-a-lot Markets	2827.9
finance	10715	2020-03-18	Bon app'	1296
finance	10716	2020-03-21	Rancho grande	706
finance	10717	2020-03-21	Frankenversand	1270.75
finance	10718	2020-03-28	Königlich Essen	3463
finance	10719	2020-03-28	Let's Stop N Shop	844.2525
finance	10720	2020-03-30	Que Delícia	550
finance	10721	2020-04-02	QUICK-Stop	923.875
finance	10722	2020-04-02	Save-a-lot Markets	1570
finance	10723	2020-04-04	White Clover Markets	468.45
finance	10724	2020-04-04	Mère Paillarde	638.5
finance	10725	2020-04-07	Familia Arquibaldo	287.8
finance	10727	2020-04-14	Reggiani Caseifici	1624.5
finance	10726	2020-04-14	Eastern Connection	655
finance	10728	2020-04-17	Queen Cozinha	1296.75
finance	10729	2020-04-17	LINO-Delicateses	1850
finance	10730	2020-04-19	Bon app'	484.2625
finance	10731	2020-04-22	Chop-suey Chinese	1890.5
finance	10732	2020-04-22	Bon app'	360
finance	10733	2020-04-24	Berglunds snabbköp	1459
finance	10734	2020-04-24	Gourmet Lanchonetes	1498.35
finance	10735	2020-05-01	Let's Stop N Shop	536.4
finance	10736	2020-05-04	Hungry Owl All-Night Grocers	997
finance	10737	2020-05-04	Vins et alcools Chevalier	139.8
finance	10739	2020-05-06	Vins et alcools Chevalier	240
finance	10738	2020-05-06	Spécialités du monde	52.34999999999999
finance	10740	2020-05-09	White Clover Markets	1416
finance	10741	2020-05-11	Around the Horn	228
finance	10742	2020-05-11	Bottom-Dollar Markets	3118
finance	10743	2020-05-19	Around the Horn	319.2
finance	10744	2020-05-19	Vaffeljernet	736
finance	10745	2020-05-21	QUICK-Stop	4529.8
finance	10746	2020-05-24	Chop-suey Chinese	2311.7
finance	10747	2020-05-24	Piccolo und mehr	1912.85
finance	10748	2020-05-26	Save-a-lot Markets	2196
finance	10749	2020-05-26	Island Trading	1080
finance	10750	2020-05-29	Wartian Herkku	1590.5625
finance	10752	2020-06-05	North/South	252
finance	10751	2020-06-05	Richter Supermarkt	1631.484
finance	10753	2020-06-07	Franchi S.p.A.	88
finance	10754	2020-06-07	Magazzini Alimentari Riuniti	55.2
finance	10755	2020-06-10	Bon app'	1948.5
finance	10756	2020-06-12	Split Rail Beer & Ale	1990
finance	10757	2020-06-12	Save-a-lot Markets	3082
finance	10758	2020-06-15	Richter Supermarkt	1644.6
finance	10759	2020-06-15	Ana Trujillo Emparedados y helados	320
finance	10760	2020-06-22	Maison Dewey	2917
finance	10761	2020-06-25	Rattlesnake Canyon Grocery	507
finance	10762	2020-06-25	Folk och fä HB	4337
finance	10763	2020-06-27	Folies gourmandes	616
finance	10764	2020-06-27	Ernst Handel	2286
finance	10765	2020-06-30	QUICK-Stop	1515.6
finance	10766	2020-07-02	Ottilies Käseladen	2310
finance	10767	2020-07-02	Suprêmes délices	28
finance	10768	2020-07-09	Around the Horn	1477
finance	10769	2020-07-09	Vaffeljernet	1684.275
finance	10770	2020-07-12	Hanari Carnes	236.25
finance	10771	2020-07-14	Ernst Handel	344
finance	10772	2020-07-14	Lehmanns Marktstand	3603.22
finance	10773	2020-07-17	Ernst Handel	2030.4
finance	10774	2020-07-17	Folk och fä HB	868.75
finance	10775	2020-07-19	The Cracker Box	228
finance	10777	2020-07-27	Gourmet Lanchonetes	224
finance	10776	2020-07-27	Ernst Handel	6635.275
finance	10778	2020-07-29	Berglunds snabbköp	96.5
finance	10779	2020-07-29	Morgenstern Gesundkost	1335
finance	10780	2020-07-29	LILA-Supermercado	720
finance	10781	2020-08-01	Wartian Herkku	975.88
finance	10782	2020-08-01	Cactus Comidas para llevar	12.5
finance	10783	2020-08-03	Hanari Carnes	1442.5
finance	10784	2020-08-03	Magazzini Alimentari Riuniti	1488
finance	10785	2020-08-03	GROSELLA-Restaurante	387.5
finance	10787	2020-08-06	La maison d'Asie	2622.76
finance	10786	2020-08-06	Queen Cozinha	1531.08
finance	10789	2020-08-13	Folies gourmandes	3687
finance	10790	2020-08-13	Gourmet Lanchonetes	722.5
finance	10788	2020-08-13	QUICK-Stop	731.5
finance	10791	2020-08-15	Frankenversand	1829.757
finance	10792	2020-08-15	Wolski  Zajazd	399.85
finance	10793	2020-08-18	Around the Horn	191.1
finance	10794	2020-08-18	Que Delícia	314.76
finance	10795	2020-08-18	Ernst Handel	2158
finance	10796	2020-08-20	HILARION-Abastos	2341.364
finance	10797	2020-08-20	Drachenblut Delikatessen	420
finance	10798	2020-08-23	Island Trading	446.6
finance	10799	2020-08-23	Königlich Essen	1553.5
finance	10800	2020-08-23	Seven Seas Imports	1468.935
finance	10802	2020-08-30	Simons bistro	2942.8125
finance	10801	2020-08-30	Bólido Comidas preparadas	3026.85
finance	10803	2020-09-02	Wellington Importadora	1193.01
finance	10804	2020-09-02	Seven Seas Imports	2278.4
finance	10805	2020-09-02	The Big Cheese	2775
finance	10806	2020-09-04	Victuailles en stock	439.6
finance	10807	2020-09-04	Franchi S.p.A.	18.4
finance	10808	2020-09-07	Old World Delicatessen	1411
finance	10809	2020-09-07	Wellington Importadora	140
finance	10810	2020-09-07	Laughing Bacchus Wine Cellars	187
finance	10811	2020-09-09	LINO-Delicateses	852
finance	10812	2020-09-09	Reggiani Caseifici	1692.8
finance	10814	2020-09-16	Victuailles en stock	1788.45
finance	10813	2020-09-16	Ricardo Adocicados	602.4
finance	10815	2020-09-16	Save-a-lot Markets	40
finance	10817	2020-09-19	Königlich Essen	10952.845
finance	10816	2020-09-19	Great Lakes Food Market	8446.45
finance	10818	2020-09-21	Magazzini Alimentari Riuniti	833
finance	10819	2020-09-21	Cactus Comidas para llevar	477
finance	10820	2020-09-21	Rattlesnake Canyon Grocery	1140
finance	10821	2020-09-24	Split Rail Beer & Ale	678
finance	10822	2020-09-24	Trail's Head Gourmet Provisioners	237.9
finance	10823	2020-09-26	LILA-Supermercado	2826
finance	10824	2020-09-26	Folk och fä HB	250.8
finance	10825	2020-09-26	Drachenblut Delikatessen	1030.76
finance	10826	2020-10-04	Blondesddsl père et fils	730
finance	10827	2020-10-04	Bon app'	843
finance	10829	2020-10-06	Island Trading	1764
finance	10830	2020-10-06	Tradição Hipermercados	1974
finance	10828	2020-10-06	Rancho grande	932
finance	10831	2020-10-09	Santé Gourmet	2684.4
finance	10832	2020-10-09	La maison d'Asie	475.11
finance	10833	2020-10-11	Ottilies Käseladen	906.9300000000001
finance	10834	2020-10-11	Tradição Hipermercados	1432.714
finance	10835	2020-10-11	Alfreds Futterkiste	845.8
finance	10836	2020-10-14	Ernst Handel	4705.5
finance	10837	2020-10-14	Berglunds snabbköp	1064.5
finance	10838	2020-10-21	LINO-Delicateses	1938.375
finance	10839	2020-10-21	Tradição Hipermercados	827.55
finance	10840	2020-10-21	LINO-Delicateses	211.2
finance	10841	2020-10-23	Suprêmes délices	4581
finance	10842	2020-10-23	Tortuga Restaurante	975
finance	10845	2020-10-26	QUICK-Stop	3812.7
finance	10843	2020-10-26	Victuailles en stock	159
finance	10844	2020-10-26	Piccolo und mehr	735
finance	10846	2020-10-28	Suprêmes délices	1112
finance	10847	2020-10-28	Save-a-lot Markets	4931.92
finance	10848	2020-10-31	Consolidated Holdings	931.5
finance	10849	2020-10-31	Königlich Essen	967.819
finance	10850	2020-10-31	Victuailles en stock	629
finance	10851	2020-11-07	Ricardo Adocicados	2603
finance	10852	2020-11-07	Rattlesnake Canyon Grocery	2984
finance	10855	2020-11-10	Old World Delicatessen	2227.8875
finance	10853	2020-11-10	Blauer See Delikatessen	625
finance	10854	2020-11-10	Ernst Handel	2966.5
finance	10857	2020-11-12	Berglunds snabbköp	2048.2125
finance	10856	2020-11-12	Antonio Moreno Taquería	660
finance	10858	2020-11-15	La corne d'abondance	649
finance	10859	2020-11-15	Frankenversand	1078.6875
finance	10860	2020-11-15	France restauration	519
finance	10861	2020-11-17	White Clover Markets	3523.4
finance	10862	2020-11-17	Lehmanns Marktstand	581
finance	10863	2020-11-24	HILARION-Abastos	441.15
finance	10864	2020-11-24	Around the Horn	282
finance	10865	2020-11-24	QUICK-Stop	16387.5
finance	10866	2020-11-27	Berglunds snabbköp	1096.2
finance	10867	2020-11-27	Lonesome Pine Restaurant	98.39999999999999
finance	10870	2020-11-29	Wolski  Zajazd	160
finance	10869	2020-11-29	Seven Seas Imports	1630
finance	10868	2020-11-29	Queen Cozinha	1920.6
finance	10871	2020-12-02	Bon app'	1979.23
finance	10872	2020-12-02	Godos Cocina Típica	2058.46
finance	10873	2020-12-04	Wilman Kala	336.8
finance	10874	2020-12-04	Godos Cocina Típica	310
finance	10875	2020-12-04	Berglunds snabbköp	709.55
finance	10876	2020-12-12	Bon app'	917
finance	10877	2020-12-12	Ricardo Adocicados	1955.125
finance	10878	2020-12-14	QUICK-Stop	1539
finance	10879	2020-12-14	Wilman Kala	611.3
finance	10880	2020-12-14	Folk och fä HB	1500
finance	10881	2020-12-17	Cactus Comidas para llevar	150
finance	10882	2020-12-17	Save-a-lot Markets	892.64
finance	10885	2020-12-19	Suprêmes délices	1209
finance	10883	2020-12-19	Lonesome Pine Restaurant	36
finance	10884	2020-12-19	Let's Stop N Shop	1378.07
finance	10886	2020-12-21	Hanari Carnes	3127.5
finance	10887	2020-12-21	Galería del gastrónomo	70
finance	10888	2020-12-29	Godos Cocina Típica	605
finance	10889	2020-12-29	Rattlesnake Canyon Grocery	11380
finance	10890	2020-12-29	Du monde entier	860.1
finance	10891	2020-12-31	Lehmanns Marktstand	368.9325
finance	10892	2020-12-31	Maison Dewey	2090
finance	10895	2021-01-03	Ernst Handel	6379.4
finance	10893	2021-01-03	Königlich Essen	5502.11
finance	10894	2021-01-03	Save-a-lot Markets	2753.1
finance	10897	2021-01-05	Hungry Owl All-Night Grocers	10835.24
finance	10896	2021-01-05	Maison Dewey	750.5
finance	10898	2021-01-08	Océano Atlántico Ltda.	30
finance	10899	2021-01-08	LILA-Supermercado	122.4
finance	10900	2021-01-08	Wellington Importadora	33.75
finance	10901	2021-01-15	HILARION-Abastos	934.5
finance	10902	2021-01-15	Folk och fä HB	863.43
finance	10903	2021-01-18	Hanari Carnes	932.05
finance	10904	2021-01-18	White Clover Markets	1924.25
finance	10905	2021-01-18	Wellington Importadora	342
finance	10906	2021-01-20	Wolski  Zajazd	427.5
finance	10907	2021-01-20	Spécialités du monde	108.5
finance	10913	2021-01-23	Queen Cozinha	768.75
finance	10912	2021-01-23	Hungry Owl All-Night Grocers	6200.55
finance	10911	2021-01-23	Godos Cocina Típica	858
finance	10909	2021-01-23	Santé Gourmet	670
finance	10908	2021-01-23	Reggiani Caseifici	663.1
finance	10910	2021-01-23	Wilman Kala	452.9
finance	10914	2021-01-25	Queen Cozinha	537.5
finance	10915	2021-01-25	Tortuga Restaurante	539.5
finance	10916	2021-01-25	Rancho grande	686.7
finance	10917	2021-02-01	Romero y tomillo	365.89
finance	10918	2021-02-01	Bottom-Dollar Markets	1447.5
finance	10919	2021-02-01	LINO-Delicateses	1122.8
finance	10923	2021-02-04	La maison d'Asie	748.8
finance	10922	2021-02-04	Hanari Carnes	742.5
finance	10920	2021-02-04	Around the Horn	390
finance	10921	2021-02-04	Vaffeljernet	1936
finance	10924	2021-02-06	Berglunds snabbköp	1835.7
finance	10925	2021-02-06	Hanari Carnes	475.15
finance	10926	2021-02-06	Ana Trujillo Emparedados y helados	514.4
finance	10927	2021-02-09	La corne d'abondance	800
finance	10928	2021-02-09	Galería del gastrónomo	137.5
finance	10929	2021-02-09	Frankenversand	1174.75
finance	10932	2021-02-11	Bon app'	1788.63
finance	10933	2021-02-11	Island Trading	920.6
finance	10930	2021-02-11	Suprêmes délices	2255.5
finance	10931	2021-02-11	Richter Supermarkt	799.2
finance	10934	2021-02-19	Lehmanns Marktstand	500
finance	10935	2021-02-19	Wellington Importadora	619.5
finance	10936	2021-02-19	Great Lakes Food Market	456
finance	10937	2021-02-21	Cactus Comidas para llevar	644.8
finance	10938	2021-02-21	QUICK-Stop	2731.875
finance	10939	2021-02-21	Magazzini Alimentari Riuniti	637.5
finance	10943	2021-02-24	B's Beverages	711
finance	10940	2021-02-24	Bon app'	360
finance	10941	2021-02-24	Save-a-lot Markets	4011.75
finance	10942	2021-02-24	Reggiani Caseifici	560
finance	10946	2021-02-26	Vaffeljernet	1407.5
finance	10945	2021-02-26	Morgenstern Gesundkost	245
finance	10944	2021-02-26	Bottom-Dollar Markets	1025.325
finance	10947	2021-02-28	B's Beverages	220
finance	10948	2021-02-28	Godos Cocina Típica	2362.25
finance	10949	2021-02-28	Bottom-Dollar Markets	4422
finance	10950	2021-03-08	Magazzini Alimentari Riuniti	110
finance	10951	2021-03-08	Richter Supermarkt	458.755
finance	10952	2021-03-08	Alfreds Futterkiste	471.2
finance	10953	2021-03-08	Around the Horn	4441.25
finance	10955	2021-03-10	Folk och fä HB	74.4
finance	10956	2021-03-10	Blauer See Delikatessen	677
finance	10954	2021-03-10	LINO-Delicateses	1659.535
finance	10957	2021-03-13	HILARION-Abastos	1762.7
finance	10958	2021-03-13	Océano Atlántico Ltda.	781
finance	10959	2021-03-13	Gourmet Lanchonetes	131.75
finance	10960	2021-03-15	HILARION-Abastos	265.35
finance	10961	2021-03-15	Queen Cozinha	1119.9
finance	10962	2021-03-15	QUICK-Stop	3584
finance	10963	2021-03-15	Furia Bacalhau e Frutos do Mar	57.8
finance	10966	2021-03-18	Chop-suey Chinese	1098.46
finance	10964	2021-03-18	Spécialités du monde	2052.5
finance	10965	2021-03-18	Old World Delicatessen	848
finance	10968	2021-03-25	Ernst Handel	1408
finance	10969	2021-03-25	Comércio Mineiro	108
finance	10967	2021-03-25	Toms Spezialitäten	910.4
finance	10973	2021-03-28	La corne d'abondance	291.55
finance	10972	2021-03-28	La corne d'abondance	251.5
finance	10971	2021-03-28	France restauration	1733.06
finance	10970	2021-03-28	Bólido Comidas preparadas	224
finance	10974	2021-03-30	Split Rail Beer & Ale	439
finance	10975	2021-03-30	Bottom-Dollar Markets	717.5
finance	10976	2021-03-30	HILARION-Abastos	912
finance	10977	2021-04-01	Folk och fä HB	2233
finance	10978	2021-04-01	Maison Dewey	1303.195
finance	10979	2021-04-01	Ernst Handel	4813.5
finance	10982	2021-04-04	Bottom-Dollar Markets	1014
finance	10983	2021-04-04	Save-a-lot Markets	720.9
finance	10980	2021-04-04	Folk och fä HB	248
finance	10981	2021-04-04	Hanari Carnes	15810
finance	10984	2021-04-11	Save-a-lot Markets	1809.75
finance	10985	2021-04-11	Hungry Owl All-Night Grocers	2023.38
finance	10986	2021-04-11	Océano Atlántico Ltda.	2220
finance	10987	2021-04-14	Eastern Connection	2772
finance	10988	2021-04-14	Rattlesnake Canyon Grocery	3574.8
finance	10989	2021-04-14	Que Delícia	1353.6
finance	10993	2021-04-16	Folk och fä HB	4895.4375
finance	10990	2021-04-16	Ernst Handel	4288.85
finance	10991	2021-04-16	QUICK-Stop	2296
finance	10992	2021-04-16	The Big Cheese	69.6
finance	10996	2021-04-19	QUICK-Stop	560
finance	10995	2021-04-19	Pericles Comidas clásicas	1196
finance	10994	2021-04-19	Vaffeljernet	940.5
finance	10997	2021-04-21	LILA-Supermercado	1885
finance	10998	2021-04-21	Wolski  Zajazd	686
finance	10999	2021-04-21	Ottilies Käseladen	1197.95
finance	11000	2021-04-29	Rattlesnake Canyon Grocery	903.75
finance	11001	2021-04-29	Folk och fä HB	2769
finance	11002	2021-04-29	Save-a-lot Markets	1811.1
finance	11003	2021-04-29	The Cracker Box	326
finance	11004	2021-05-01	Maison Dewey	295.38
finance	11005	2021-05-01	Wilman Kala	586
finance	11006	2021-05-01	Great Lakes Food Market	329.685
finance	11009	2021-05-04	Godos Cocina Típica	616.5
finance	11007	2021-05-04	Princesa Isabel Vinhos	2633.9
finance	11008	2021-05-04	Ernst Handel	4680.9
finance	11010	2021-05-06	Reggiani Caseifici	645
finance	11011	2021-05-06	Alfreds Futterkiste	933.5
finance	11012	2021-05-06	Frankenversand	2825.3
finance	11013	2021-05-06	Romero y tomillo	361
finance	11014	2021-05-08	LINO-Delicateses	243.18
finance	11015	2021-05-08	Santé Gourmet	622.35
finance	11016	2021-05-08	Around the Horn	491.5
finance	11018	2021-05-16	Lonesome Pine Restaurant	1575
finance	11017	2021-05-16	Ernst Handel	6750
finance	11019	2021-05-16	Rancho grande	76
finance	11023	2021-05-18	B's Beverages	1500
finance	11022	2021-05-18	Hanari Carnes	1402
finance	11021	2021-05-18	QUICK-Stop	6306.24
finance	11020	2021-05-18	Ottilies Käseladen	632.4
finance	11024	2021-05-21	Eastern Connection	1966.81
finance	11025	2021-05-21	Wartian Herkku	270
finance	11026	2021-05-21	Franchi S.p.A.	1030
finance	11027	2021-05-23	Bottom-Dollar Markets	877.7249999999999
finance	11028	2021-05-23	Königlich Essen	2160
finance	11029	2021-05-23	Chop-suey Chinese	1286.8
finance	11032	2021-05-26	White Clover Markets	8902.5
finance	11033	2021-05-26	Richter Supermarkt	3232.8
finance	11030	2021-05-26	Save-a-lot Markets	12615.05
finance	11031	2021-05-26	Save-a-lot Markets	2393.5
finance	11034	2021-06-02	Old World Delicatessen	539.4
finance	11035	2021-06-02	Suprêmes délices	1754.5
finance	11036	2021-06-02	Drachenblut Delikatessen	1692
finance	11037	2021-06-05	Godos Cocina Típica	60
finance	11038	2021-06-05	Suprêmes délices	732.6
finance	11039	2021-06-05	LINO-Delicateses	3090
finance	11043	2021-06-07	Spécialités du monde	210
finance	11040	2021-06-07	Great Lakes Food Market	200
finance	11041	2021-06-07	Chop-suey Chinese	1773
finance	11042	2021-06-07	Comércio Mineiro	405.75
finance	11045	2021-06-09	Bottom-Dollar Markets	1309.5
finance	11046	2021-06-09	Die Wandernde Kuh	1485.8
finance	11044	2021-06-09	Wolski  Zajazd	591.5999999999999
finance	11047	2021-06-12	Eastern Connection	817.875
finance	11048	2021-06-12	Bottom-Dollar Markets	525
finance	11049	2021-06-12	Gourmet Lanchonetes	273.6
finance	11050	2021-06-19	Folk och fä HB	810
finance	11051	2021-06-19	La maison d'Asie	36
finance	11052	2021-06-19	Hanari Carnes	1332
finance	11053	2021-06-19	Piccolo und mehr	3055
finance	11056	2021-06-22	Eastern Connection	3740
finance	11054	2021-06-22	Cactus Comidas para llevar	305
finance	11055	2021-06-22	HILARION-Abastos	1727.5
finance	11059	2021-06-24	Ricardo Adocicados	1838
finance	11058	2021-06-24	Blauer See Delikatessen	858
finance	11057	2021-06-24	North/South	45
finance	11060	2021-06-27	Franchi S.p.A.	266
finance	11061	2021-06-27	Great Lakes Food Market	510
finance	11062	2021-06-27	Reggiani Caseifici	406.4
finance	11063	2021-06-27	Hungry Owl All-Night Grocers	1342.95
finance	11066	2021-06-29	White Clover Markets	928.75
finance	11064	2021-06-29	Save-a-lot Markets	4330.400000000001
finance	11065	2021-06-29	LILA-Supermercado	189.42
finance	11068	2021-07-07	Queen Cozinha	2027.08
finance	11069	2021-07-07	Tortuga Restaurante	360
finance	11067	2021-07-07	Drachenblut Delikatessen	86.85000000000001
finance	11072	2021-07-09	Ernst Handel	5218
finance	11073	2021-07-09	Pericles Comidas clásicas	300
finance	11070	2021-07-09	Lehmanns Marktstand	1629.975
finance	11071	2021-07-09	LILA-Supermercado	484.5
finance	11075	2021-07-12	Richter Supermarkt	498.1
finance	11076	2021-07-12	Bon app'	792.75
finance	11074	2021-07-12	Simons bistro	232.085
finance	11077	2021-07-12	Rattlesnake Canyon Grocery	1255.7205
\.


--
-- Data for Name: structured_hr_employee_hr_records_sheet1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_hr_employee_hr_records_sheet1 (permission_scope_key, employee_id, full_name, gender, department, job_title, city, country, reportsto, hire_date, annual_salary, performance_rating, satisfaction_score, employment_status) FROM stdin;
hr	1	Nancy Davolio	Female	Sales	Sales Representative	New York	USA	8	2015-09-21T00:00:00	101905	3.2	4.6	Active
hr	2	Andrew Fuller	Male	Sales	Vice President Sales	New York	USA	\N	2013-06-22T00:00:00	76049	3.4	4.6	Active
hr	3	Janet Leverling	Female	Sales	Sales Representative	New York	USA	8	2013-02-08T00:00:00	104348	4.5	4.3	Active
hr	4	Margaret Peacock	Female	Sales	Sales Representative	New York	USA	8	2016-02-26T00:00:00	98698	3.8	3.5	Active
hr	5	Steven Buchanan	Male	Sales	Sales Manager	London	UK	2	2014-03-04T00:00:00	74328	3.5	4.4	Active
hr	6	Michael Suyama	Male	Sales	Sales Representative	London	UK	5	2014-01-16T00:00:00	96781	3.4	4.5	Active
hr	7	Robert King	Male	Sales	Sales Representative	London	UK	5	2013-12-13T00:00:00	95713	3.8	4.2	Active
hr	8	Laura Callahan	Female	Sales	Sales Manager	New York	USA	2	2013-08-05T00:00:00	78231	4.6	3.5	Active
hr	9	Anne Dodsworth	Female	Sales	Sales Representative	London	UK	5	2016-02-19T00:00:00	112810	3.3	4.1	Active
hr	10	Natalie Gardner	Female	IT	Software Engineer	London	UK	\N	2020-08-03T00:00:00	94118	2.8	3.4	Active
hr	11	Anna Hall	Female	HR	Recruiter	London	UK	12	2017-03-24T00:00:00	55695	4.3	3.8	Active
hr	12	Mike Miles	Male	HR	Recruiter	London	UK	\N	2020-07-27T00:00:00	132397	4	4.7	On Leave
hr	13	Kevin Pacheco	Male	Marketing	Marketing Specialist	London	UK	24	2017-01-21T00:00:00	56006	4.2	4.4	Active
hr	14	Christopher Henderson	Male	Sales	Sales Manager	London	UK	8	2019-05-14T00:00:00	86434	3.6	4.6	Active
hr	15	Tina Rogers	Female	Finance	Financial Analyst	London	UK	\N	2017-10-16T00:00:00	137841	3.2	4.8	Active
hr	16	Ian Cooper	Male	HR	HR Specialist	London	UK	12	2019-04-02T00:00:00	71417	3.7	3.2	On Leave
hr	17	Nicholas Herrera	Male	Marketing	Content Writer	London	UK	24	2020-03-22T00:00:00	57331	3.1	2.6	Active
hr	18	Elaine Fuller	Female	Finance	Financial Analyst	London	UK	15	2020-01-29T00:00:00	77653	4.8	3.9	Active
hr	19	Michael Williams	Male	Marketing	Content Writer	London	UK	24	2018-12-10T00:00:00	101856	4.7	4.1	Active
hr	20	Victoria Wyatt	Female	IT	Software Engineer	London	UK	10	2017-11-10T00:00:00	147647	3.9	3.2	On Leave
hr	21	Jody Flowers	Female	HR	Recruiter	London	UK	12	2018-05-21T00:00:00	97447	3	5	On Leave
hr	22	Christine Adams	Female	Sales	Account Executive	London	UK	5	2017-08-10T00:00:00	64371	2.9	2.9	Active
hr	23	Christopher Daniel	Male	Operations	Logistics Coordinator	London	UK	\N	2018-05-23T00:00:00	128104	5	3.8	On Leave
hr	24	Devin Schaefer	Male	Marketing	Marketing Specialist	London	UK	\N	2018-11-14T00:00:00	139353	4.7	4.4	Active
hr	25	Ryan Parsons	Male	Finance	Accountant	London	UK	15	2018-12-13T00:00:00	70730	3.6	4.9	Active
hr	26	Robert Morales	Male	HR	HR Specialist	New York	USA	12	2017-07-25T00:00:00	131959	3.2	4.1	On Leave
hr	27	Tommy Walter	Male	IT	System Administrator	New York	USA	10	2019-09-05T00:00:00	149943	2.9	4.9	On Leave
hr	28	Jonathan Wilkerson	Male	HR	Recruiter	New York	USA	12	2020-11-26T00:00:00	114042	2.5	4.8	Active
hr	29	Charles Mcgee	Male	Sales	Account Executive	New York	USA	5	2019-03-28T00:00:00	124364	4.9	2.7	Active
hr	30	Jeffrey Silva	Male	HR	HR Specialist	New York	USA	12	2020-01-30T00:00:00	66828	4.1	4.9	Active
hr	31	Yolanda Hicks	Female	HR	Recruiter	New York	USA	12	2017-10-10T00:00:00	77760	4.8	4.4	Active
hr	32	Shannon Hernandez	Female	Operations	Logistics Coordinator	New York	USA	23	2018-05-13T00:00:00	107422	4.7	3.6	Active
hr	33	Jay Brown	Male	Sales	Sales Manager	New York	USA	2	2020-03-31T00:00:00	52757	4	3.1	Active
hr	34	John King	Male	Sales	Business Development	New York	USA	5	2017-02-05T00:00:00	132719	2.6	2.7	Active
hr	35	Ashley Dyer	Female	Sales	Business Development	New York	USA	2	2019-04-09T00:00:00	81195	3.2	3.7	On Leave
hr	36	Gerald Carter	Male	Marketing	Content Writer	New York	USA	24	2018-05-07T00:00:00	81850	4.5	4.5	Active
hr	37	Troy Liu	Male	Sales	Business Development	New York	USA	2	2019-03-30T00:00:00	106498	3.4	3.5	Active
hr	38	Dr. Jordan Rodriguez	Male	Sales	Sales Manager	New York	USA	8	2019-07-17T00:00:00	145448	3.3	4.7	Active
\.


--
-- Data for Name: structured_resource_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_resource_columns (column_id, resource_id, column_name, data_type, safe_description, ordinal_position, metadata, is_active) FROM stdin;
ceb33123-7cef-4d0a-9fee-d86e99090d77	51a5e836-ff2b-4c28-8f5e-ba8ad01f3c0a	categoryid	integer	categoryID	1	{}	t
0cfc6a4c-8c44-4087-a61d-04105d6e2d2e	51a5e836-ff2b-4c28-8f5e-ba8ad01f3c0a	categoryname	text	categoryName	2	{}	t
74f20d6d-d60a-4676-b19b-f5e7c0b74775	51a5e836-ff2b-4c28-8f5e-ba8ad01f3c0a	description	text	description	3	{}	t
d62795c5-2c67-4fc6-9b0d-948da17cabe0	4cc74263-ea83-403d-8791-540271b04512	customerid	text	customerID	1	{}	t
f6a2dc16-9bce-4cc9-9d0f-2fc5355c3ba3	4cc74263-ea83-403d-8791-540271b04512	companyname	text	companyName	2	{}	t
562eb762-103d-4713-9f24-72a6521073c0	4cc74263-ea83-403d-8791-540271b04512	contactname	text	contactName	3	{}	t
8657787c-b613-4c7c-937a-75360951c5cf	4cc74263-ea83-403d-8791-540271b04512	contacttitle	text	contactTitle	4	{}	t
7ba50a5a-6f1e-4b55-a624-25bcdec70b71	4cc74263-ea83-403d-8791-540271b04512	city	text	city	5	{}	t
045fad09-8182-4df0-9ed6-df3ac082c479	4cc74263-ea83-403d-8791-540271b04512	country	text	country	6	{}	t
5598862f-61ed-46a0-8b37-69a747761bad	57071767-03e9-4858-ac09-b646326cda87	orderid	integer	orderID	1	{}	t
debbd776-7b37-4074-8d3a-515a27c2e95d	57071767-03e9-4858-ac09-b646326cda87	productid	integer	productID	2	{}	t
31167f4c-f6dc-493f-95cc-e9a631ad65b0	57071767-03e9-4858-ac09-b646326cda87	orderprice	decimal	orderPrice	3	{}	t
47457a33-c475-49ee-99f1-689e1fd7eb1a	57071767-03e9-4858-ac09-b646326cda87	quantity	integer	quantity	4	{}	t
abbae3d3-f0b4-4762-b744-206569352902	57071767-03e9-4858-ac09-b646326cda87	discount	decimal	discount	5	{}	t
aa87362c-2c02-45ef-9a0c-fd9ae61ad9f7	5c533b0e-a23a-406a-913e-7d17bc169610	orderid	integer	orderID	1	{}	t
93e71283-bd5c-4bfc-9eeb-4e0f4099d40c	5c533b0e-a23a-406a-913e-7d17bc169610	productid	integer	productID	2	{}	t
492c1e81-851c-4643-9629-8e411a6b4b69	5c533b0e-a23a-406a-913e-7d17bc169610	orderprice	decimal	orderPrice	3	{}	t
c884884c-33de-46b9-a260-04c0fb1527bc	5c533b0e-a23a-406a-913e-7d17bc169610	quantity	integer	quantity	4	{}	t
9e53c2d8-4e2b-4889-9e23-3dcc34f575c3	5c533b0e-a23a-406a-913e-7d17bc169610	discount	decimal	discount	5	{}	t
9bc6941a-6e07-4db0-81c6-c881e8dd737e	36700f13-2e13-40ce-a082-dafa68fc40e1	orderid	integer	orderID	1	{}	t
d80e80e9-fc01-47c6-8dff-9cbe54d4f8e8	36700f13-2e13-40ce-a082-dafa68fc40e1	productid	integer	productID	2	{}	t
95535d3c-6434-4fb7-9ff0-27dff7100805	36700f13-2e13-40ce-a082-dafa68fc40e1	orderprice	decimal	orderPrice	3	{}	t
a65d3f9f-86b8-4f57-9c15-70655fc1ac32	36700f13-2e13-40ce-a082-dafa68fc40e1	quantity	integer	quantity	4	{}	t
d25fdeed-3f3c-4946-8241-93fb8916c421	36700f13-2e13-40ce-a082-dafa68fc40e1	discount	decimal	discount	5	{}	t
797e7001-1919-456e-8105-0fe7802cc024	c49cfe61-f310-4381-9cf8-37f9e163e78c	orderid	integer	orderID	1	{}	t
7c96cc2a-8814-44e0-a7f8-de19c8c3b8f3	c49cfe61-f310-4381-9cf8-37f9e163e78c	productid	integer	productID	2	{}	t
6bdda449-f114-4e06-b31c-9e3a15c5407e	c49cfe61-f310-4381-9cf8-37f9e163e78c	orderprice	decimal	orderPrice	3	{}	t
907107d9-b227-43d1-99df-76127f82b8d1	c49cfe61-f310-4381-9cf8-37f9e163e78c	quantity	integer	quantity	4	{}	t
b70a710b-327a-4d29-ad77-c911dcd8b591	c49cfe61-f310-4381-9cf8-37f9e163e78c	discount	decimal	discount	5	{}	t
73137a31-0a59-485a-b003-f982b7faf419	3fdbc962-c003-4605-9106-f7ebbe8289a2	orderid	integer	orderID	1	{}	t
00a68779-5e3b-4eb3-8594-b83112e07914	3fdbc962-c003-4605-9106-f7ebbe8289a2	productid	integer	productID	2	{}	t
6dde08c5-bd1d-4044-aa70-a0ab44e67814	3fdbc962-c003-4605-9106-f7ebbe8289a2	orderprice	decimal	orderPrice	3	{}	t
851f04bd-bf75-4a04-be7e-c190ca781729	3fdbc962-c003-4605-9106-f7ebbe8289a2	quantity	integer	quantity	4	{}	t
d4818ed6-c31e-406c-990d-507418071dbe	3fdbc962-c003-4605-9106-f7ebbe8289a2	discount	decimal	discount	5	{}	t
ea4eedee-243b-4a98-b855-a593e27ebdee	ce54817b-91b5-49f1-9835-a2316946c04d	orderid	integer	orderID	1	{}	t
72706c9b-720f-4a6e-9dab-6e98fd082e4c	ce54817b-91b5-49f1-9835-a2316946c04d	customerid	text	customerID	2	{}	t
00e9a894-7e16-4180-b6c8-4b95258b6181	ce54817b-91b5-49f1-9835-a2316946c04d	employeeid	integer	employeeID	3	{}	t
cab41a7c-d35e-4c2d-92f8-90762a99be66	ce54817b-91b5-49f1-9835-a2316946c04d	orderdate	text	orderDate	4	{}	t
cc3e60e2-0019-43b4-8bac-a830a47620e7	ce54817b-91b5-49f1-9835-a2316946c04d	requireddate	text	requiredDate	5	{}	t
11ed3998-8329-496b-917b-d7f73562738a	ce54817b-91b5-49f1-9835-a2316946c04d	shippeddate	text	shippedDate	6	{}	t
37970e5d-6f5f-43a9-939b-2744929f6df5	ce54817b-91b5-49f1-9835-a2316946c04d	shipperid	integer	shipperID	7	{}	t
df4cd60e-da80-4d8c-8fd4-b00714cf4287	ce54817b-91b5-49f1-9835-a2316946c04d	freight	decimal	freight	8	{}	t
111c2a21-b62b-47e7-8dd1-8487cdff68a8	7054f078-3f7a-4548-93f3-629f3c5f2fc5	orderid	integer	orderID	1	{}	t
b84f6170-52f1-4034-ba0b-08df5834bb3e	7054f078-3f7a-4548-93f3-629f3c5f2fc5	customerid	text	customerID	2	{}	t
dcc376cf-2e63-4dd3-a0a6-74956394abfa	7054f078-3f7a-4548-93f3-629f3c5f2fc5	employeeid	integer	employeeID	3	{}	t
d79bf8b9-db0f-4f62-94ed-89822ae102f4	7054f078-3f7a-4548-93f3-629f3c5f2fc5	orderdate	text	orderDate	4	{}	t
352081e9-8c95-4724-987d-9d916c7e23af	7054f078-3f7a-4548-93f3-629f3c5f2fc5	requireddate	text	requiredDate	5	{}	t
757ad846-e6cd-44ac-8075-cd6f3d715411	7054f078-3f7a-4548-93f3-629f3c5f2fc5	shippeddate	text	shippedDate	6	{}	t
b7743d9b-b813-4d28-958a-f961e1ba03a4	7054f078-3f7a-4548-93f3-629f3c5f2fc5	shipperid	integer	shipperID	7	{}	t
cab1240c-16e1-4658-a3be-021f4d6e92d2	7054f078-3f7a-4548-93f3-629f3c5f2fc5	freight	decimal	freight	8	{}	t
6d22b844-5d03-4a28-be30-073fe19f5f7a	f87049f3-df06-40a8-bef0-432c077a9982	orderid	integer	orderID	1	{}	t
b76e3fec-d34f-4503-ab96-74b7f21044ce	f87049f3-df06-40a8-bef0-432c077a9982	customerid	text	customerID	2	{}	t
adabce44-90e2-4012-8738-f591619d6255	f87049f3-df06-40a8-bef0-432c077a9982	employeeid	integer	employeeID	3	{}	t
bcc8bc79-168d-4186-bb9e-061f418ecd59	f87049f3-df06-40a8-bef0-432c077a9982	orderdate	text	orderDate	4	{}	t
9468a8f8-1547-4ccd-8def-c9050d971f2f	f87049f3-df06-40a8-bef0-432c077a9982	requireddate	text	requiredDate	5	{}	t
01223df6-f66a-4dbd-a319-fe3608f91638	f87049f3-df06-40a8-bef0-432c077a9982	shippeddate	text	shippedDate	6	{}	t
42ed7c27-d5b9-41af-a6b0-e6efe53810f9	f87049f3-df06-40a8-bef0-432c077a9982	shipperid	integer	shipperID	7	{}	t
55b98d0c-6de1-4df3-9cc0-62fbdecc0c1b	f87049f3-df06-40a8-bef0-432c077a9982	freight	decimal	freight	8	{}	t
1b9406ec-ad0b-4a02-a373-6d1af61480b5	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	orderid	integer	orderID	1	{}	t
f801f101-6b1d-4f5d-9b97-efd78f15bf31	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	customerid	text	customerID	2	{}	t
7e6a6001-3a36-49e2-b29f-f6d75a9ad84d	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	employeeid	integer	employeeID	3	{}	t
df86d4da-ee5e-42d1-b5c8-f616bbce03e3	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	orderdate	text	orderDate	4	{}	t
55820374-9e6c-4bb0-a823-90c7677ec36f	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	requireddate	text	requiredDate	5	{}	t
139ac066-d99a-446e-afe4-fc9bd03764cd	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	shippeddate	text	shippedDate	6	{}	t
436702b7-86ad-4cde-914f-0a21d8fda08d	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	shipperid	integer	shipperID	7	{}	t
67b9c302-a64d-494d-a579-b993939fba4e	8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	freight	decimal	freight	8	{}	t
96939363-649c-4043-b682-8fb983a19ca6	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	orderid	integer	orderID	1	{}	t
204ac194-8822-4815-b604-ec98f7ae0915	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	customerid	text	customerID	2	{}	t
457c6f2e-cb0b-4762-a047-620ecfba6a2e	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	employeeid	integer	employeeID	3	{}	t
7b08bf6b-7efe-4680-b9e9-f25e8ebfeb8b	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	orderdate	text	orderDate	4	{}	t
e253ca37-8193-404e-941f-2326554a5260	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	requireddate	text	requiredDate	5	{}	t
61639611-3833-497a-b1a5-5c336e1d0732	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	shippeddate	text	shippedDate	6	{}	t
20996b3b-6f69-4dd9-8ddc-692530675205	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	shipperid	integer	shipperID	7	{}	t
00f3f404-5b30-4423-a270-28018d722bf0	ea4361d1-b6ed-47ae-95b6-8cafa967e10f	freight	decimal	freight	8	{}	t
c284c8f1-3953-41d3-a90b-7bd247162312	8c43dfe6-8125-4de7-837c-dc25531fbec3	productid	integer	productID	1	{}	t
a14590b6-e021-4f8a-9d1b-d62206fc8f66	8c43dfe6-8125-4de7-837c-dc25531fbec3	productname	text	productName	2	{}	t
4d31ebdf-96ed-4b5b-8f0e-ccf255da89fa	8c43dfe6-8125-4de7-837c-dc25531fbec3	quantityperunit	text	quantityPerUnit	3	{}	t
4be90358-c55f-4361-8321-03fe7f169666	8c43dfe6-8125-4de7-837c-dc25531fbec3	currentprice	decimal	currentPrice	4	{}	t
0de1200d-3bb1-434d-bf9f-62fa146ede47	8c43dfe6-8125-4de7-837c-dc25531fbec3	discontinued	integer	discontinued	5	{}	t
70e3eda6-6e77-48ca-aed6-6f9119c0f835	8c43dfe6-8125-4de7-837c-dc25531fbec3	categoryid	integer	categoryID	6	{}	t
35fcc240-8546-4128-be36-1906f8e8d6d2	32f8992f-20f7-4819-a782-9698de6a5a19	shipperid	integer	shipperID	1	{}	t
b2831cc0-6956-472d-87a5-c61f12668f4a	32f8992f-20f7-4819-a782-9698de6a5a19	companyname	text	companyName	2	{}	t
f9323eda-9f88-4b48-bab4-a297324abf43	5bbdc5fe-6b00-4256-84fd-9d18494167d7	transaction_id	integer	Transaction ID	1	{}	t
80b7d638-60be-49de-8455-e6b3040c4180	5bbdc5fe-6b00-4256-84fd-9d18494167d7	date	text	Date	2	{}	t
5a614d72-6faf-4499-9b56-d93a224d452e	5bbdc5fe-6b00-4256-84fd-9d18494167d7	account	text	Account	3	{}	t
5ef24ef7-331e-4955-a54f-6bebcb30844f	5bbdc5fe-6b00-4256-84fd-9d18494167d7	type	text	Type	4	{}	t
6c0478d8-4d3a-483d-ad69-0a16e0826519	5bbdc5fe-6b00-4256-84fd-9d18494167d7	category	text	Category	5	{}	t
ed97fc48-7093-410d-920a-bad60be031a6	5bbdc5fe-6b00-4256-84fd-9d18494167d7	description_merchant	text	Description / Merchant	6	{}	t
8ed66cb3-4962-4a40-b96c-0c4c6dec3bbd	5bbdc5fe-6b00-4256-84fd-9d18494167d7	amount	decimal	Amount	7	{}	t
c9a072f8-d260-4a58-8924-c8fe334d2e39	5bbdc5fe-6b00-4256-84fd-9d18494167d7	payment_method	text	Payment Method	8	{}	t
b314353a-5ef6-44dc-9fcb-aa4c3f5d9a7c	5bbdc5fe-6b00-4256-84fd-9d18494167d7	is_recurring	text	Is Recurring	9	{}	t
483eef51-3bf3-4474-a977-4759aa2acd45	14a868e0-0719-4964-bcf6-c00d512a62f4	transaction_id	integer	Transaction ID	1	{}	t
0bbb464f-bdcd-4a69-8666-c3403dcdb74d	14a868e0-0719-4964-bcf6-c00d512a62f4	date	text	Date	2	{}	t
d633f4ca-4272-4d1e-aa3c-a5d41aa4282f	14a868e0-0719-4964-bcf6-c00d512a62f4	description_merchant	text	Description / Merchant	3	{}	t
f97f4e4e-f6d6-4670-aec1-0ff2dd772450	14a868e0-0719-4964-bcf6-c00d512a62f4	amount	decimal	Amount	4	{}	t
575809e2-1877-41c2-b669-1243af9f3ed5	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	employee_id	integer	Employee ID	1	{}	t
88e4b4ba-e88b-4211-bb74-c2170c7f62bd	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	full_name	text	Full Name	2	{}	t
542ef89c-269d-4de3-ad5f-ee55b89d547f	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	gender	text	Gender	3	{}	t
2ce41395-a8db-450a-8305-2942f9fb9d4d	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	department	text	Department	4	{}	t
37329f99-4c7c-4bb2-a0d4-8e21432a97b0	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	job_title	text	Job Title	5	{}	t
177abdc2-61fd-49d7-8cf8-ac88cf676b06	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	city	text	City	6	{}	t
1cb6e623-698c-4d07-9e5b-303b9d818fc6	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	country	text	Country	7	{}	t
2b3b1f7d-bc96-4bc9-84ca-6591d5169298	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	reportsto	integer	ReportsTo	8	{}	t
ac9893e9-85fb-44b8-9182-0181a007b969	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	hire_date	text	Hire Date	9	{}	t
d5ab9941-c7f1-4b11-9833-e6109beafee2	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	annual_salary	integer	Annual Salary	10	{}	t
42cc29c6-bf44-4cd7-97be-5fbb1b967c7f	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	performance_rating	decimal	Performance Rating	11	{}	t
3a2a8c32-6619-4621-8e6a-b9fc80463e95	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	satisfaction_score	decimal	Satisfaction Score	12	{}	t
9a66a9e2-ef84-4209-9b58-13be132c34eb	9e4fc5d3-dfbb-4549-b890-2097144c1ce8	employment_status	text	Employment Status	13	{}	t
\.


--
-- Data for Name: structured_resource_scope_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_resource_scope_map (resource_id, permission_scope_key) FROM stdin;
51a5e836-ff2b-4c28-8f5e-ba8ad01f3c0a	file_server
4cc74263-ea83-403d-8791-540271b04512	file_server
57071767-03e9-4858-ac09-b646326cda87	file_server
5c533b0e-a23a-406a-913e-7d17bc169610	file_server
36700f13-2e13-40ce-a082-dafa68fc40e1	file_server
c49cfe61-f310-4381-9cf8-37f9e163e78c	file_server
3fdbc962-c003-4605-9106-f7ebbe8289a2	file_server
ce54817b-91b5-49f1-9835-a2316946c04d	file_server
7054f078-3f7a-4548-93f3-629f3c5f2fc5	file_server
f87049f3-df06-40a8-bef0-432c077a9982	file_server
8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	file_server
ea4361d1-b6ed-47ae-95b6-8cafa967e10f	file_server
8c43dfe6-8125-4de7-837c-dc25531fbec3	file_server
32f8992f-20f7-4819-a782-9698de6a5a19	file_server
5bbdc5fe-6b00-4256-84fd-9d18494167d7	finance
14a868e0-0719-4964-bcf6-c00d512a62f4	finance
9e4fc5d3-dfbb-4549-b890-2097144c1ce8	hr
\.


--
-- Data for Name: structured_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.structured_resources (resource_id, catalog_entry_id, resource_key, runtime_relation_name, display_name, permission_scope_key, metadata, is_active, created_at) FROM stdin;
51a5e836-ff2b-4c28-8f5e-ba8ad01f3c0a	ba5dfe8f-c4d4-40e3-afe3-5e7c11492a92	structured:file_server:categories	structured_file_server_categories	categories	file_server	{"row_count": 8, "sheet_name": null, "sheet_index": 0, "column_count": 3, "safe_location_path": "File Server/categories.csv"}	t	2026-07-20 17:59:16.167083+00
4cc74263-ea83-403d-8791-540271b04512	7a762c9b-462f-4a97-bbcd-8f36f6982bbf	structured:file_server:customers	structured_file_server_customers	customers	file_server	{"row_count": 91, "sheet_name": null, "sheet_index": 0, "column_count": 6, "safe_location_path": "File Server/customers.csv"}	t	2026-07-20 17:59:16.167083+00
57071767-03e9-4858-ac09-b646326cda87	11e8f90a-6452-4d77-9faf-b83db7354305	structured:file_server:order_details_2017	structured_file_server_order_details_2017	order_details - 2017	file_server	{"row_count": 324, "sheet_name": "2017", "sheet_index": 0, "column_count": 5, "safe_location_path": "File Server/order_details.xlsx"}	t	2026-07-20 17:59:16.167083+00
5c533b0e-a23a-406a-913e-7d17bc169610	11e8f90a-6452-4d77-9faf-b83db7354305	structured:file_server:order_details_2018	structured_file_server_order_details_2018	order_details - 2018	file_server	{"row_count": 391, "sheet_name": "2018", "sheet_index": 1, "column_count": 5, "safe_location_path": "File Server/order_details.xlsx"}	t	2026-07-20 17:59:16.167083+00
36700f13-2e13-40ce-a082-dafa68fc40e1	11e8f90a-6452-4d77-9faf-b83db7354305	structured:file_server:order_details_2019	structured_file_server_order_details_2019	order_details - 2019	file_server	{"row_count": 409, "sheet_name": "2019", "sheet_index": 2, "column_count": 5, "safe_location_path": "File Server/order_details.xlsx"}	t	2026-07-20 17:59:16.167083+00
c49cfe61-f310-4381-9cf8-37f9e163e78c	11e8f90a-6452-4d77-9faf-b83db7354305	structured:file_server:order_details_2020	structured_file_server_order_details_2020	order_details - 2020	file_server	{"row_count": 560, "sheet_name": "2020", "sheet_index": 3, "column_count": 5, "safe_location_path": "File Server/order_details.xlsx"}	t	2026-07-20 17:59:16.167083+00
3fdbc962-c003-4605-9106-f7ebbe8289a2	11e8f90a-6452-4d77-9faf-b83db7354305	structured:file_server:order_details_2021	structured_file_server_order_details_2021	order_details - 2021	file_server	{"row_count": 471, "sheet_name": "2021", "sheet_index": 4, "column_count": 5, "safe_location_path": "File Server/order_details.xlsx"}	t	2026-07-20 17:59:16.167083+00
ce54817b-91b5-49f1-9835-a2316946c04d	56cb791f-beea-459b-bbec-8fc06b0d98db	structured:file_server:orders_2017	structured_file_server_orders_2017	orders - 2017	file_server	{"row_count": 121, "sheet_name": "2017", "sheet_index": 0, "column_count": 8, "safe_location_path": "File Server/orders.xlsx"}	t	2026-07-20 17:59:16.167083+00
7054f078-3f7a-4548-93f3-629f3c5f2fc5	56cb791f-beea-459b-bbec-8fc06b0d98db	structured:file_server:orders_2018	structured_file_server_orders_2018	orders - 2018	file_server	{"row_count": 150, "sheet_name": "2018", "sheet_index": 1, "column_count": 8, "safe_location_path": "File Server/orders.xlsx"}	t	2026-07-20 17:59:16.167083+00
f87049f3-df06-40a8-bef0-432c077a9982	56cb791f-beea-459b-bbec-8fc06b0d98db	structured:file_server:orders_2019	structured_file_server_orders_2019	orders - 2019	file_server	{"row_count": 157, "sheet_name": "2019", "sheet_index": 2, "column_count": 8, "safe_location_path": "File Server/orders.xlsx"}	t	2026-07-20 17:59:16.167083+00
8f6deec5-775c-4ea5-aaa0-fc35d1b242e0	56cb791f-beea-459b-bbec-8fc06b0d98db	structured:file_server:orders_2020	structured_file_server_orders_2020	orders - 2020	file_server	{"row_count": 217, "sheet_name": "2020", "sheet_index": 3, "column_count": 8, "safe_location_path": "File Server/orders.xlsx"}	t	2026-07-20 17:59:16.167083+00
ea4361d1-b6ed-47ae-95b6-8cafa967e10f	56cb791f-beea-459b-bbec-8fc06b0d98db	structured:file_server:orders_2021	structured_file_server_orders_2021	orders - 2021	file_server	{"row_count": 185, "sheet_name": "2021", "sheet_index": 4, "column_count": 8, "safe_location_path": "File Server/orders.xlsx"}	t	2026-07-20 17:59:16.167083+00
8c43dfe6-8125-4de7-837c-dc25531fbec3	5bc5a890-222a-4b19-b967-13bfd3ef56b1	structured:file_server:products	structured_file_server_products	products	file_server	{"row_count": 77, "sheet_name": null, "sheet_index": 0, "column_count": 6, "safe_location_path": "File Server/products.csv"}	t	2026-07-20 17:59:16.167083+00
32f8992f-20f7-4819-a782-9698de6a5a19	0e6aebe1-9f03-41ac-ac95-340d50e59e09	structured:file_server:shippers	structured_file_server_shippers	shippers	file_server	{"row_count": 3, "sheet_name": null, "sheet_index": 0, "column_count": 2, "safe_location_path": "File Server/shippers.csv"}	t	2026-07-20 17:59:16.167083+00
5bbdc5fe-6b00-4256-84fd-9d18494167d7	bf89f1aa-5a08-4886-8735-adb2d1c53b96	structured:finance:company_expense_sheet1	structured_finance_company_expense_sheet1	Company Expense - Sheet1	finance	{"row_count": 1050, "sheet_name": "Sheet1", "sheet_index": 0, "column_count": 9, "safe_location_path": "Finance/Company Expense.xlsx"}	t	2026-07-20 17:59:16.167083+00
14a868e0-0719-4964-bcf6-c00d512a62f4	4b0bed98-c9fb-414f-88db-100824712611	structured:finance:company_revenue_sheet1	structured_finance_company_revenue_sheet1	Company Revenue - Sheet1	finance	{"row_count": 830, "sheet_name": "Sheet1", "sheet_index": 0, "column_count": 4, "safe_location_path": "Finance/Company Revenue.xlsx"}	t	2026-07-20 17:59:16.167083+00
9e4fc5d3-dfbb-4549-b890-2097144c1ce8	c9f40140-6e99-44e6-9a04-4a874489cac3	structured:hr:employee_hr_records_sheet1	structured_hr_employee_hr_records_sheet1	Employee HR Records - Sheet1	hr	{"row_count": 38, "sheet_name": "Sheet1", "sheet_index": 0, "column_count": 13, "safe_location_path": "HR/Employee HR Records.xlsx"}	t	2026-07-20 17:59:16.167083+00
\.


--
-- Name: app_groups app_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_groups
    ADD CONSTRAINT app_groups_pkey PRIMARY KEY (group_key);


--
-- Name: app_user_groups app_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user_groups
    ADD CONSTRAINT app_user_groups_pkey PRIMARY KEY (user_key, group_key);


--
-- Name: app_users app_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_email_key UNIQUE (email);


--
-- Name: app_users app_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_pkey PRIMARY KEY (user_key);


--
-- Name: approved_join_relationships approved_join_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_join_relationships
    ADD CONSTRAINT approved_join_relationships_pkey PRIMARY KEY (join_id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (event_id);


--
-- Name: catalog_entries catalog_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_entries
    ADD CONSTRAINT catalog_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: document_chunks document_chunks_catalog_entry_id_chunk_index_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_catalog_entry_id_chunk_index_key UNIQUE (catalog_entry_id, chunk_index);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (chunk_id);


--
-- Name: permission_scopes permission_scopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_scopes
    ADD CONSTRAINT permission_scopes_pkey PRIMARY KEY (scope_key);


--
-- Name: rag_chunk_embeddings rag_chunk_embeddings_chunk_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunk_embeddings
    ADD CONSTRAINT rag_chunk_embeddings_chunk_id_key UNIQUE (chunk_id);


--
-- Name: rag_chunk_embeddings rag_chunk_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunk_embeddings
    ADD CONSTRAINT rag_chunk_embeddings_pkey PRIMARY KEY (embedding_id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: source_catalog source_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_catalog
    ADD CONSTRAINT source_catalog_pkey PRIMARY KEY (source_id);


--
-- Name: structured_resource_columns structured_resource_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_columns
    ADD CONSTRAINT structured_resource_columns_pkey PRIMARY KEY (column_id);


--
-- Name: structured_resource_columns structured_resource_columns_resource_id_column_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_columns
    ADD CONSTRAINT structured_resource_columns_resource_id_column_name_key UNIQUE (resource_id, column_name);


--
-- Name: structured_resource_scope_map structured_resource_scope_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_scope_map
    ADD CONSTRAINT structured_resource_scope_map_pkey PRIMARY KEY (resource_id, permission_scope_key);


--
-- Name: structured_resources structured_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resources
    ADD CONSTRAINT structured_resources_pkey PRIMARY KEY (resource_id);


--
-- Name: structured_resources structured_resources_resource_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resources
    ADD CONSTRAINT structured_resources_resource_key_key UNIQUE (resource_key);


--
-- Name: structured_resources structured_resources_runtime_relation_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resources
    ADD CONSTRAINT structured_resources_runtime_relation_name_key UNIQUE (runtime_relation_name);


--
-- Name: app_user_groups app_user_groups_group_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user_groups
    ADD CONSTRAINT app_user_groups_group_key_fkey FOREIGN KEY (group_key) REFERENCES public.app_groups(group_key) ON DELETE CASCADE;


--
-- Name: app_user_groups app_user_groups_user_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user_groups
    ADD CONSTRAINT app_user_groups_user_key_fkey FOREIGN KEY (user_key) REFERENCES public.app_users(user_key) ON DELETE CASCADE;


--
-- Name: approved_join_relationships approved_join_relationships_left_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_join_relationships
    ADD CONSTRAINT approved_join_relationships_left_column_id_fkey FOREIGN KEY (left_column_id) REFERENCES public.structured_resource_columns(column_id) ON DELETE CASCADE;


--
-- Name: approved_join_relationships approved_join_relationships_left_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_join_relationships
    ADD CONSTRAINT approved_join_relationships_left_resource_id_fkey FOREIGN KEY (left_resource_id) REFERENCES public.structured_resources(resource_id) ON DELETE CASCADE;


--
-- Name: approved_join_relationships approved_join_relationships_right_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_join_relationships
    ADD CONSTRAINT approved_join_relationships_right_column_id_fkey FOREIGN KEY (right_column_id) REFERENCES public.structured_resource_columns(column_id) ON DELETE CASCADE;


--
-- Name: approved_join_relationships approved_join_relationships_right_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_join_relationships
    ADD CONSTRAINT approved_join_relationships_right_resource_id_fkey FOREIGN KEY (right_resource_id) REFERENCES public.structured_resources(resource_id) ON DELETE CASCADE;


--
-- Name: catalog_entries catalog_entries_permission_scope_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_entries
    ADD CONSTRAINT catalog_entries_permission_scope_key_fkey FOREIGN KEY (permission_scope_key) REFERENCES public.permission_scopes(scope_key);


--
-- Name: catalog_entries catalog_entries_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_entries
    ADD CONSTRAINT catalog_entries_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source_catalog(source_id) ON DELETE CASCADE;


--
-- Name: document_chunks document_chunks_catalog_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_catalog_entry_id_fkey FOREIGN KEY (catalog_entry_id) REFERENCES public.catalog_entries(entry_id) ON DELETE CASCADE;


--
-- Name: document_chunks document_chunks_permission_scope_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_permission_scope_key_fkey FOREIGN KEY (permission_scope_key) REFERENCES public.permission_scopes(scope_key);


--
-- Name: rag_chunk_embeddings rag_chunk_embeddings_chunk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_chunk_embeddings
    ADD CONSTRAINT rag_chunk_embeddings_chunk_id_fkey FOREIGN KEY (chunk_id) REFERENCES public.document_chunks(chunk_id) ON DELETE CASCADE;


--
-- Name: source_catalog source_catalog_permission_scope_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_catalog
    ADD CONSTRAINT source_catalog_permission_scope_key_fkey FOREIGN KEY (permission_scope_key) REFERENCES public.permission_scopes(scope_key);


--
-- Name: structured_resource_columns structured_resource_columns_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_columns
    ADD CONSTRAINT structured_resource_columns_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.structured_resources(resource_id) ON DELETE CASCADE;


--
-- Name: structured_resource_scope_map structured_resource_scope_map_permission_scope_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_scope_map
    ADD CONSTRAINT structured_resource_scope_map_permission_scope_key_fkey FOREIGN KEY (permission_scope_key) REFERENCES public.permission_scopes(scope_key);


--
-- Name: structured_resource_scope_map structured_resource_scope_map_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resource_scope_map
    ADD CONSTRAINT structured_resource_scope_map_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.structured_resources(resource_id) ON DELETE CASCADE;


--
-- Name: structured_resources structured_resources_catalog_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resources
    ADD CONSTRAINT structured_resources_catalog_entry_id_fkey FOREIGN KEY (catalog_entry_id) REFERENCES public.catalog_entries(entry_id) ON DELETE SET NULL;


--
-- Name: structured_resources structured_resources_permission_scope_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structured_resources
    ADD CONSTRAINT structured_resources_permission_scope_key_fkey FOREIGN KEY (permission_scope_key) REFERENCES public.permission_scopes(scope_key);


--
-- Name: approved_join_relationships; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approved_join_relationships ENABLE ROW LEVEL SECURITY;

--
-- Name: approved_join_relationships approved_joins_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY approved_joins_scope_read ON public.approved_join_relationships FOR SELECT TO restricted_runtime_reader USING ((is_active AND (validation_status = 'approved'::text) AND app_security.can_read_structured_resource(left_resource_id) AND app_security.can_read_structured_resource(right_resource_id)));


--
-- Name: catalog_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.catalog_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: catalog_entries catalog_entries_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY catalog_entries_scope_read ON public.catalog_entries FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_catalog_entry(entry_id));


--
-- Name: document_chunks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_chunks ENABLE ROW LEVEL SECURITY;

--
-- Name: document_chunks document_chunks_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_chunks_scope_read ON public.document_chunks FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_document_chunk(chunk_id));


--
-- Name: rag_chunk_embeddings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rag_chunk_embeddings ENABLE ROW LEVEL SECURITY;

--
-- Name: rag_chunk_embeddings rag_embeddings_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rag_embeddings_scope_read ON public.rag_chunk_embeddings FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_document_chunk(chunk_id));


--
-- Name: source_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.source_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: source_catalog source_catalog_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY source_catalog_scope_read ON public.source_catalog FOR SELECT TO restricted_runtime_reader USING ((is_active AND app_security.can_read_scope(permission_scope_key)));


--
-- Name: structured_resource_columns structured_columns_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_columns_scope_read ON public.structured_resource_columns FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_structured_resource(resource_id));


--
-- Name: structured_file_server_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_categories structured_file_server_categories_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_categories_scope_read ON public.structured_file_server_categories FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:categories'::text)));


--
-- Name: structured_file_server_customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_customers ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_customers structured_file_server_customers_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_customers_scope_read ON public.structured_file_server_customers FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:customers'::text)));


--
-- Name: structured_file_server_order_details_2017; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_order_details_2017 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_order_details_2017 structured_file_server_order_details_2017_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_order_details_2017_scope_read ON public.structured_file_server_order_details_2017 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:order_details_2017'::text)));


--
-- Name: structured_file_server_order_details_2018; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_order_details_2018 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_order_details_2018 structured_file_server_order_details_2018_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_order_details_2018_scope_read ON public.structured_file_server_order_details_2018 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:order_details_2018'::text)));


--
-- Name: structured_file_server_order_details_2019; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_order_details_2019 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_order_details_2019 structured_file_server_order_details_2019_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_order_details_2019_scope_read ON public.structured_file_server_order_details_2019 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:order_details_2019'::text)));


--
-- Name: structured_file_server_order_details_2020; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_order_details_2020 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_order_details_2020 structured_file_server_order_details_2020_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_order_details_2020_scope_read ON public.structured_file_server_order_details_2020 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:order_details_2020'::text)));


--
-- Name: structured_file_server_order_details_2021; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_order_details_2021 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_order_details_2021 structured_file_server_order_details_2021_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_order_details_2021_scope_read ON public.structured_file_server_order_details_2021 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:order_details_2021'::text)));


--
-- Name: structured_file_server_orders_2017; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_orders_2017 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_orders_2017 structured_file_server_orders_2017_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_orders_2017_scope_read ON public.structured_file_server_orders_2017 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:orders_2017'::text)));


--
-- Name: structured_file_server_orders_2018; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_orders_2018 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_orders_2018 structured_file_server_orders_2018_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_orders_2018_scope_read ON public.structured_file_server_orders_2018 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:orders_2018'::text)));


--
-- Name: structured_file_server_orders_2019; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_orders_2019 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_orders_2019 structured_file_server_orders_2019_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_orders_2019_scope_read ON public.structured_file_server_orders_2019 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:orders_2019'::text)));


--
-- Name: structured_file_server_orders_2020; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_orders_2020 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_orders_2020 structured_file_server_orders_2020_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_orders_2020_scope_read ON public.structured_file_server_orders_2020 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:orders_2020'::text)));


--
-- Name: structured_file_server_orders_2021; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_orders_2021 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_orders_2021 structured_file_server_orders_2021_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_orders_2021_scope_read ON public.structured_file_server_orders_2021 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:orders_2021'::text)));


--
-- Name: structured_file_server_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_products ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_products structured_file_server_products_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_products_scope_read ON public.structured_file_server_products FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:products'::text)));


--
-- Name: structured_file_server_shippers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_file_server_shippers ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_file_server_shippers structured_file_server_shippers_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_file_server_shippers_scope_read ON public.structured_file_server_shippers FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:file_server:shippers'::text)));


--
-- Name: structured_finance_company_expense_sheet1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_finance_company_expense_sheet1 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_finance_company_expense_sheet1 structured_finance_company_expense_sheet1_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_finance_company_expense_sheet1_scope_read ON public.structured_finance_company_expense_sheet1 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:finance:company_expense_sheet1'::text)));


--
-- Name: structured_finance_company_revenue_sheet1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_finance_company_revenue_sheet1 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_finance_company_revenue_sheet1 structured_finance_company_revenue_sheet1_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_finance_company_revenue_sheet1_scope_read ON public.structured_finance_company_revenue_sheet1 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:finance:company_revenue_sheet1'::text)));


--
-- Name: structured_hr_employee_hr_records_sheet1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_hr_employee_hr_records_sheet1 ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_hr_employee_hr_records_sheet1 structured_hr_employee_hr_records_sheet1_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_hr_employee_hr_records_sheet1_scope_read ON public.structured_hr_employee_hr_records_sheet1 FOR SELECT TO restricted_runtime_reader USING ((app_security.can_read_scope(permission_scope_key) OR app_security.can_read_resource_key('structured:hr:employee_hr_records_sheet1'::text)));


--
-- Name: structured_resource_columns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_resource_columns ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_resource_scope_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_resource_scope_map ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.structured_resources ENABLE ROW LEVEL SECURITY;

--
-- Name: structured_resources structured_resources_scope_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_resources_scope_read ON public.structured_resources FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_structured_resource(resource_id));


--
-- Name: structured_resource_scope_map structured_scope_map_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY structured_scope_map_read ON public.structured_resource_scope_map FOR SELECT TO restricted_runtime_reader USING (app_security.can_read_structured_resource(resource_id));


--
-- PostgreSQL database dump complete
--

\unrestrict ayGTck4BQzry0ebazzhyHNLBf72I6mLpdeISi1rwHfroxBXefoPubPwnzB8rys6

